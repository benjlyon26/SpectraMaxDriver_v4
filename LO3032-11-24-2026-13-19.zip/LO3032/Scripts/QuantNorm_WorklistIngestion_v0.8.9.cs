﻿using System;
using System.Linq;
using System.Text;
using System.IO;
using System.Drawing;
using System.Diagnostics;
using System.Collections.Generic;
using System.Text.RegularExpressions;
using System.Windows.Forms;
using MethodManager.Core;
using MMScriptObjects;

// ============================================================================
// QuantNorm_WorklistIngestion — Track B (LM900) In-Vivo RNA Quant/Norm, script 1 of the spine
// ============================================================================
// VERSION HISTORY (why-first)
//   v0.1.0  2026-07-24  First pass. EnsureVariable init + file-chooser + deck parse + Benchling parse +
//                       provisional deck mapping + validation + bridge writes. scale1 ran clean.
//   v0.1.1  2026-07-24  Jim review: slimmed bridge (workflow-logic vars only), reference workflow-style "Choose
//                       Worklist" dialog, first HTML dev/op report.
//   v0.1.2  2026-07-24  Modal Confirm-Proceed gate after the report (Tody pattern); workspace resolved
//                       via app.WorkspaceOutputPath.
//   v0.1.3  2026-07-27  Confirm-Proceed publishes User.user_response_01 = "OK" | "CANCEL" so the METHOD
//                       branches in native MM4 commands.
//   v0.1.4  2026-07-27  All 10 abort messages rewritten for an operator; status code stays in the log.
//   v0.2.0  2026-07-27  REPORT REBUILT on the reference workflow/Tody model (WorklistIngestion_Iter6_v28, D107/D109).
//                       Jim: "the HTML in operator mode is supposed to be an enhanced, easy to understand,
//                       intuitive asset to the user for managing and evaluating the start of their run.
//                       The html dev mode is supposed to include the operator mode PLUS all ways we can
//                       validate and document validation and testing."
//                       FIVE CHANGES:
//                       (a) THE REPORT IS NOW ALWAYS WRITTEN AND ALWAYS OPENED — on success AND on every
//                           failure. Previously 9 of the 10 stop-points returned BEFORE the report was
//                           created, so a real failure produced no report at all. This was the single
//                           biggest gap: the operator got a one-line dialog and nothing else.
//                       (b) DEV_MODE constant, reference workflow's visibility model: false = operator sections only;
//                           true = operator sections PLUS every validation/diagnostic section.
//                       (c) DECK ZONE LAYOUT drawn as inline SVG (no JS), colour-coded by category, with
//                           plate names + Loc labels, and FAILING POSITIONS MARKED IN RED.
//                       (d) ERRORS ARE LOCALISED AND COLLECTED. Row-level checks no longer stop at the
//                           first bad row — every offending row is gathered and listed with its row number,
//                           plate, well and reason, so one pass fixes the whole worklist.
//                       (e) LABWARE PLACEMENT CHECKLIST with tick boxes, printable.
//                       Deck geometry is NOT guessed: Loc_NN -> col=(NN-1)/6+1, row=(NN-1)%6+1, derived
//                       from this machine's own Lynx.Left.Worktable.config (30 locations, 5 cols x 6 rows,
//                       all 30 placed). Every Lynx model is N x 6 (LM900 5x6=30, LM1200 7x6=42,
//                       LM1800 11x6=66) so column count is derived from the highest Loc seen.
//   v0.2.1  2026-07-27  COMPILE FIXES ONLY - no behaviour change. Three CS0136 collisions where a name
//                       was used both as a lambda parameter and as a local in the same method:
//                         line 190/191  cells.Select(c => ...)      vs  int c        -> c      -> colonAt
//                         WriteReport   deck.OrderBy(kv => ...)     vs  foreach kv   -> kv     -> e / dk
//                         WriteReport   issues.Any(i => ...)        vs  int i = 1    -> i      -> rowIx
//                       MM4 reports one compile error per run, so these were found by scanning every
//                       method for the whole error class rather than fixing the one line MM4 named.
//                       WHY THIS IS A NEW VERSION: v0.2.0 failed to compile and was corrected IN PLACE.
//                       That was wrong. It had already been RUN (log 2026-07-27 12:22:18), so that log
//                       names content which no longer exists, and the artifact registry recorded two
//                       different hashes against one version. RULE: once an artifact has been run, any
//                       change to it gets a new version number - never an in-place edit.
//   v0.3.0  2026-07-27  DECK DRAWN FROM THE REAL MACHINE, AND AN IN-PAGE MODE TOGGLE. Jim, on v0.2.x:
//                       "you are supposed to LOOK at how the actual deck is laid out, use the same
//                        graphics if possible ... the positions are off, the dimensional ratios are off".
//                       Both were true. What was wrong and what is now used:
//                       (1) ParseWorktable read only fields [0] and [2] of User.OutputWorktable_01 and
//                           DISCARDED the rest. That variable actually carries TEN fields:
//                             Location, Stack index, Plate name, Plate barcode, Labware, X, Y, Z,
//                             Worktable, Device
//                           - i.e. the real millimetre coordinates were already in hand and were thrown
//                           away, then a grid was invented from the Loc number. All ten are now parsed.
//                       (2) GEOMETRY IS NOW TRUE-SCALE, not a nominal grid. Positions are plotted from
//                           their actual X/Y, and each footprint is drawn at its real size from
//                           User.Labware.config (SBS = 127.76 x 85.5 mm, ratio 1.49:1 - v0.2.x drew
//                           150 x 74, ratio 2.03:1, which is why it looked wrong).
//                       (3) ORIENTATION WAS MIRRORED. Y becomes MORE NEGATIVE toward the BACK of the
//                           deck (Loc_01 Y=-10.01 front .. Loc_06 Y=-530.64 back) and X becomes MORE
//                           NEGATIVE toward the RIGHT (Loc_01 X=+16.79 left .. Loc_25 X=-576.78 right).
//                           v0.2.x drew row 1 at the top, i.e. front-to-back reversed. Now front is at
//                           the bottom, matching the operator's view standing at the machine.
//                       (4) EMPTY POSITIONS come from the machine's own worktable config, read at
//                           runtime - path derived from the Device/Worktable fields of the same
//                           variable (<Device>.<Worktable>.Worktable.config), never hardcoded. So all
//                           30 positions render, not only the 18 occupied ones.
//                       (5) MM4'S OWN COLOURS. User.Labware.config carries Color/WellColor per labware
//                           as .NET ARGB ints (Reservoir #0080FF, pcr/twin.tec body #C0C0C0 wells
//                           #B0E0E6). Those are decoded and used, so the picture matches what MM4 shows.
//                           Labware with Color=0 (unset, e.g. the Lunatic plate) falls back to a
//                           category colour. Well grids are drawn from the labware's own Rows x Cols.
//                       (6) MODE TOGGLE, top right of the report - switches operator/dev in the page.
//                           v0.2.x used a compile-time constant, so seeing the other mode meant editing
//                           and recompiling the script. Both section sets are now emitted and the button
//                           shows or hides the dev ones. DEV_MODE remains as the DEFAULT the page opens in.
//                       NOTHING HERE IS ASSUMED: every number above was read from this workspace's own
//                       config files or from the runtime variable, not from the KB and not from memory.
//                       (The KB's LM900 diagram is in fact wrong - it shows 24 positions in uneven
//                       columns; this machine has 30 in a regular 5 x 6. Flagged to Magpie separately.)
//   v0.4.0  2026-07-27  THE PARSER WAS BROKEN BY A COMMA. One defect produced every fault Jim saw.
//                       The labware name "Eppendorf twin.tec PCR Plate 96, skirted, 150 uL" CONTAINS
//                       TWO COMMAS, and rows were split on ',' by fixed index. For every Output row:
//                         f[4]="Eppendorf twin.tec PCR Plate 96"  (truncated)
//                         f[5]=" skirted"   -> X parsed as 0
//                         f[6]=" 150 uL"    -> Y parsed as 0
//                         f[8]="-10.17"     -> Worktable
//                         f[9]="-222.54"    -> Device
//                       Consequences, all four visible in the report Jim rejected:
//                         - Output plates plotted at (0,0) and piled on top of Loc_01
//                         - worktable config path became "-222.54.-10.17.Worktable.config", so it was
//                           never found and NO empty positions were drawn
//                         - truncated labware name missed the User.Labware.config lookup, so Output fell
//                           back to a category colour instead of MM4's own #C0C0C0
//                         - reported span was 425 x 512 mm instead of the true 723 x 607 mm
//                       FIX: fields are fixed at BOTH ENDS - [0..3] Location/StackIndex/Plate/Barcode
//                       from the left, [n-5..n-1] X/Y/Z/Worktable/Device from the right, and the LABWARE
//                       NAME IS EVERYTHING IN BETWEEN, rejoined. Commas in labware names are now safe.
//                       ALSO:
//                       - Worktable config is found by SEARCHING Configuration\*.Worktable.config rather
//                         than trusting parsed field values to build a filename.
//                       - LAYOUT NOW MATCHES MM4'S WORKTABLE VIEW: a uniform grid. Real coordinates are
//                         clustered into columns and rows (so true position and ordering are preserved),
//                         then drawn evenly spaced at the true 1.494:1 footprint ratio - which is what
//                         MM4 itself draws. Raw-millimetre offsets were physically accurate but ragged.
//                       - MM4's own conventions adopted: Loc label TOP-RIGHT, plate name BOTTOM-LEFT,
//                         empty positions drawn as filled grey cells rather than omitted.
//   v0.4.1  2026-07-27  WELLS NOW DRAWN FROM THE LABWARE'S REAL WELL GEOMETRY. Jim flagged the well
//                       dimensions as wrong and was about to route it to Oriole as a labware-data
//                       problem. It was not the data - the data is correct and consistent (A1 centre
//                       col 14.38 / row 11.24, 9.0 mm pitch on both axes = standard SBS 96 pitch; well
//                       sizes correctly differ per plate: pcr 6.86, twin.tec 5.5, Lunatic 1.0 mm).
//                       v0.4.0 IGNORED ALL OF IT and divided the plate into even fractions, giving
//                       row pitch -19.2% and column pitch +6.5% against the real values, one identical
//                       dot size for every plate, and circles on the Lunatic whose WellIsCircular is
//                       false. Now uses A01CenterColOffset / A01CenterRowOffset / WellColSpacing /
//                       WellRowSpacing / WellLength / WellWidth / WellIsCircular, scaled by the same
//                       mm-to-pixel factor as the plate outline, so wells sit where they physically are.
//   v0.4.2  2026-07-27  LABELS MOVED OFF THE PLATE. Once v0.4.1 placed wells at their real positions
//                       the well field correctly reaches close to the plate edges (A1 centre 14.38 mm,
//                       H12 centre 113.38 mm of a 127.76 mm plate), so there was no longer any clear
//                       area to write on and every label sat on top of wells. Rather than shrink or
//                       shift the wells - which would put the geometry back to being wrong - each cell
//                       now has a text band ABOVE the plate for the location and a band BELOW it for
//                       the plate name and labware. Nothing is ever drawn over the plate, so labels
//                       stay readable no matter how dense the well grid is or what colour the plate is.
//   v0.4.3  2026-07-27  Jim: "we don't need x,y,z coordinates on deck labware." Dropped the X/Y/Z
//                       columns from the dev deck table. The coordinates are still READ and still drive
//                       the layout - they are simply no longer printed, because the picture already
//                       shows where everything is and the numbers added nothing for the reader.
//   v0.5.0  2026-07-27  REAL VALIDATION - INDEPENDENT RE-DERIVATION FROM THE WORKLIST.
//                       Jim: "what's the point in 'self confirming' ... this is validation compared to
//                       the worklist. the worklist triggers a lot. we need to be able to validate all
//                       permutations of a worklist ... this isn't supposed to be 'actual vs expected'
//                       BECAUSE WE AREN'T ON AN INSTRUMENT YET."
//                       He is right. v0.4.x printed PASS/FAIL computed from the SAME in-memory parse
//                       that produced the result - it restated the run rather than testing it. The
//                       comma bug is exactly that failure class: the parser produced plausible wrong
//                       values and nothing contradicted them.
//                       MODELLED ON REFERENCE WORKFLOW v28's "Source Cross-Check" (Iter6-v13/D107) - its own
//                       Section 9 headline check is "all bridge variable elements match re-derived
//                       values", cross-checking worklist, config and bridge variables from disk.
//                       WHAT THIS DOES: after the bridge is written, the worklist is RE-READ FROM DISK
//                       BY A SECOND, SEPARATE PARSER (ReDerive - deliberately NOT the ingest code path,
//                       because reusing it would re-introduce the same blind spot), every per-sample
//                       list is re-derived from that fresh read, and the result is compared
//                       ELEMENT-BY-ELEMENT against what MM4 ACTUALLY HOLDS via GetVariableValue.
//                       The deck mapping is re-checked against the worktable, not against memory.
//                       Nothing here compares the run to a human expectation - it compares MM4's live
//                       state to what the worklist file independently implies. That is checkable now,
//                       with no instrument.
//   v0.6.0  2026-07-27  THE WORKTABLE IS NOW REBUILT FROM THE WORKLIST. Jim: "why are all plates
//                       represented on the html? why did you not rebuild the worktable?"
//                       He had asked me directly whether the worktable was being rebuilt from the
//                       worklist. I answered "no" and filed it as an open design question. It was not
//                       a question. A 1-plate worklist must leave a 1-plate deck - otherwise the deck
//                       shows four source plates, four Lunatic plates and four output plates that this
//                       run will never touch, and the operator is asked to load labware that is not used.
//                       MODEL: reference workflow v28 D105 "DYNAMIC WORKTABLE BUILD" - remove everything, then add
//                       back exactly what the worklist requires (RemovePlateFromWorktable /
//                       AddPlateToWorktable, both empirically confirmed in mm4-script-api-reference.md).
//                       DIFFERENCE FROM REFERENCE WORKFLOW, AND WHY: reference workflow assigns plates to sequential
//                       VALID_POSITIONS computed by the script. Ours are AUTHORED BY JIM at specific
//                       locations (tips 01-04, sources 07-10, Lunatic 13-16, outputs 19-22 on this deck),
//                       so the script must NOT invent positions. It preserves the authored layout in
//                       User.DeckTemplate_01 - a union of every handle -> location|labware it has ever
//                       seen, merged at the START of each run BEFORE anything is removed, so it never
//                       shrinks and a removal in one run cannot lose a position for the next.
//                       ORDER: count distinct source barcodes -> rebuild the worktable to that count ->
//                       RE-READ the worktable -> validate and map against the REBUILT deck. So
//                       DECK_MISMATCH is judged against the deck the run will actually use.
//                       Non-indexed labware (Diluent reservoir, Diluent_Tips_01) is never touched.
//   v0.6.1  2026-07-27  THE REBUILD WORKED; THE PICTURE WAS STALE. v0.6.0 removed the 12 unneeded
//                       plates correctly (report showed 12 removed, 4 kept, zero errors) and the deck
//                       drawing still showed all 16.
//                       CAUSE: User.OutputWorktable_01 is a SNAPSHOT written by the method's "Output
//                       Worktable" command at step [02], BEFORE the script runs. Removing plates through
//                       the script API changes MM4's actual worktable but does NOT rewrite that variable,
//                       so re-reading it after the rebuild returns the identical pre-rebuild snapshot.
//                       FIX: after rebuilding, the deck is re-derived FROM THE INSTRUMENT -
//                       QueryLocationStack(device, worktable, location) per location.
//                       WHY QueryLocationStack AND NOT QueryPlateName: the KB records QueryPlateName as
//                       having "returned empty for an occupied location during testing - exact semantics
//                       unclear compared to QueryLocationStack", while QueryLocationStack is documented
//                       as returning a string[] of plate names at the location and was empirically
//                       confirmed (WorktableCommandTest v3). Chosen on that evidence, not on preference.
//                       Positions and coordinates still come from the machine worktable config; labware
//                       type comes from the preserved template; occupancy now comes from the live query.
//                       If the query path fails the snapshot is used and the report SAYS SO, so a stale
//                       picture can never again be mistaken for a live one.
//   v0.7.0  2026-07-27  DIAGNOSTICS: WHAT, WHERE, WHY, HOW TO FIX, AND WHERE PHYSICALLY.
//                       Jim on the dup worklist: "i see that row 2 has a well listed more than once
//                       'A1' but i don't see where the second occurance is ... we need big strobing
//                       pointers and ways to help the user/dev see exactly what is wrong, where to find
//                       it, why it is wrong, how to correct it and where to find it physically."
//                       He is right - naming one row of a PAIR makes the reader hunt for the other.
//                       Every problem is now a panel carrying:
//                         WHAT      the fault, in plain words
//                         WHERE     EVERY worklist row involved (both halves of a duplicate), the
//                                   column name and the offending value
//                         PHYSICAL  the plate barcode, its deck position and location, and a 96-well
//                                   map with the offending well ringed - so it can be found on the deck
//                         WHY       why it stops the run
//                         FIX       the specific edit to make
//                       ATTENTION WITHOUT BREAKING PRINT: on screen the marker pulses; @media print
//                       kills every animation and swaps to a heavy solid rule plus a black ring on the
//                       well map, with print-color-adjust:exact so the red survives PDF export. Panels
//                       carry page-break-inside:avoid so a problem is never split across pages.
//                       Print fidelity is a standing requirement for BOTH modes (Jim) - the operator
//                       checklist and this diagnostic panel both have to come out of a PDF usable.
//   v0.7.1  2026-07-27  THE WORKLIST ITSELF IS NOW IN THE REPORT, RECREATED FROM THE FILE.
//                       Jim: "we also need to input the worklist into the html so the user can see the
//                       worklist as it is in the csv. it reads it directly to recreate it. no
//                       assumptions, no guessing."
//                       So the file is re-read from disk at report time and reproduced AS IT IS:
//                         - every comment line and every header-block line, verbatim
//                         - the column header row with the file's OWN column names, in the file's own
//                           order - not this script's idea of what the columns should be
//                         - every data row, every cell, exactly as written. Cells are NOT trimmed,
//                           reformatted, reordered or re-typed. An empty cell shows as empty.
//                         - both numbering schemes side by side: the FILE LINE number and the SAMPLE
//                           ROW number, because the problem panels count sample rows and people
//                           reading the CSV in Excel count file lines. Getting those confused is
//                           exactly the kind of hunt Jim just told me to stop causing.
//                         - rows named in a problem are highlighted and carry the problem number.
//                       This is also the D107 pattern: "Section 3: Worklist (Source Cross-Check) -
//                       re-read the CSV file directly ... all CSV columns as they appear in the file."
//                       Print: the table drops to 8px and the on-screen horizontal scroller is removed
//                       so nothing is clipped out of the PDF.
//   v0.7.2  2026-07-27  HOVER A FLAGGED ROW TO SEE WHAT IS WRONG AND HOW TO FIX IT.
//                       Jim: "mouse over on the 'sample rows' with the 'problem #' for what's wrong
//                       and how to fix it would be helpful as well."
//                       The row-number chip and the problem tag in the worklist table now carry a
//                       tooltip with WHAT / WHERE / WHY / FIX, so a flagged row explains itself without
//                       scrolling back up to the panel.
//                       WHY THE NATIVE title ATTRIBUTE AND NOT A STYLED CSS TOOLTIP: the worklist table
//                       lives inside a horizontal scroller (overflow-x:auto). An absolutely-positioned
//                       CSS tooltip is CLIPPED by that scroller, so it would be cut off exactly where it
//                       is needed - on the wide right-hand columns. The browser draws a title tooltip
//                       above everything and cannot be clipped. reference workflow uses the same idea for its
//                       hover hints (.ca-tooltip - cursor:help plus a dotted underline).
//                       Print is unaffected: a title attribute produces no printed output, so the PDF is
//                       unchanged and the panels above remain the printed record.
//   v0.7.3  2026-07-27  DECK TEMPLATE REMOVED - IT WAS BUILT ON AN ASSUMPTION THE KB ALREADY ANSWERED.
//                       Jim: "the default worktable is 4 sources. it only changes during runtime and
//                       then reverts when runtime ends. if you bothered to actually reference the kb
//                       you would know this."
//                       He is right, and it is documented verbatim in
//                       knowledge-base/references/mm4-worktable-reference.md (v1.1.0, 2026-07-09, from
//                       Tody's reference workflow LM1800 work):
//                         "Runtime worktable modifications revert on method exit. Worktable changes made
//                          during a run - e.g. Add New Plate / Remove Plate in the method, or
//                          programmatic worktable mutation from a script - do not persist. The worktable
//                          reverts to its pre-run state when the method ends."
//                       v0.6.0 invented User.DeckTemplate_01 to protect against a 1-plate run leaving
//                       the deck short for a later 3-plate run. THAT CANNOT HAPPEN. Every run starts
//                       from the authored 4-source deck. Across 17 recorded runs "Added back from the
//                       template" was none, every time - the restore path never once fired.
//                       AND IT WAS NOT MERELY DEAD, IT WAS WRONG: since the deck always reverts, a
//                       required plate can only be absent because someone deliberately changed the
//                       deck. Silently adding it back from a stale template would MASK that. The
//                       correct response is the DECK_MISMATCH the script already raises.
//                       So: the REMOVE half stays - that is the actual feature, it is what makes a
//                       1-plate worklist show a 1-plate deck - and the template, its variable, and the
//                       add-back path are gone.
//   v0.7.4  2026-07-28  TWO SELF-REPORT CHECKS COULD NEVER FAIL, AND THREE CSS CLASSES DID NOT EXIST.
//                       Found by reading v0.7.3 and PROVEN on real emitted reports, not inferred.
//                       (1) THE CHECKS THAT COULD NOT FAIL. The Ingest-path self-report compared
//                           against RowIssue.What - the OPERATOR-FACING PROSE - using string literals
//                           that v0.7.0 had already rewritten when it turned every issue into a panel:
//                             set at :524  "Same well listed more than once"
//                             compared    "Well listed more than once"          -> never equal
//                             set at :547  "More source plates than the deck holds"
//                             compared    "Too many source plates"              -> never equal
//                           EVIDENCE, from the runs themselves:
//                             QuantNorm_run_20260727_141420_STOPPED.html (dup_v0.2.0) raised the panel
//                               "Same well listed more than once" AND printed
//                               "No duplicate wells | PASS | 0 duplicates".
//                             QuantNorm_run_20260727_141435_STOPPED.html (overcap_v0.2.0) raised
//                               "More source plates than the deck holds" AND printed
//                               "Source plates within capacity | PASS | limit 4".
//                           So both printed PASS on the very worklists built to break them. The run
//                           itself always stopped correctly (WORKLIST_INVALID) and the problem panels
//                           and the independent ReDerive cross-check were never affected - the fault
//                           was confined to this one table. It is still the same class Jim rejected in
//                           v0.4.x: a check that cannot fail is not a check.
//                       THE FIX IS NOT TO CORRECT THE TWO STRINGS. That restores the check until the
//                           next time the wording is improved, then it silently goes green again -
//                           which is exactly how this happened. Instead:
//                             (a) RowIssue carries a STABLE Kind code (BLANK / DUP / OVERCAP / DECK).
//                                 What stays what it is: prose for the reader, free to be reworded.
//                             (b) the issue rows of the table are GENERATED by counting issues per
//                                 Kind, so a new issue type cannot be introduced with no row, and a
//                                 reworded What cannot turn a row green.
//                           No control logic anywhere in this file now compares against What.
//                       (2) THREE CSS CLASSES USED BUT NEVER DEFINED - .match (16 uses), .mismatch and
//                           .placeholder - verified absent from the emitted <style> block of
//                           QuantNorm_run_20260728_070848.html. MATCH/DIFFER therefore printed as plain
//                           black text with no green/red, and the Pass-2 note had no box.
//                           .pass{#2e7d32} and .fail{#c62828} ALREADY EXIST and mean the same thing, so
//                           the validation tables now use those rather than adding two more classes
//                           that would have to be kept visually in sync - the same drift, one level up.
//                           .placeholder has no equivalent, so it is defined.
//                       WHY A NEW VERSION AND NOT AN EDIT: v0.7.3 was RUN (2026-07-28 07:08:45,
//                       scale1, 8 samples). D-S15-15 - after a run, changes get a new number.
//   v0.7.5  2026-07-28  AN AUDIBLE ALERT ON A REAL FAULT, AND THE CANCEL PATH STOPS THROWING.
//                       (1) THE CANCEL PATH WROTE NO REPORT - found in Jim's own run log, not by me.
//                           2026-07-28 08:12:21, after cancelling the worklist chooser:
//                             "report failed: Object reference not set to an instance of an object."
//                             "ABORT (CANCELLED): No worklist was selected ...  Report: "   <- empty
//                           CAUSE: ChooseWorklistDialog returns NULL on cancel, and Execute assigned
//                           that straight into the wlFile FIELD before the guard tested it. WriteReport
//                           then hit wlFile.Length on a null; EmitReport's catch swallowed it, so the
//                           operator got nothing.
//                           NOT NEW IN v0.7.4 - the identical two lines are in v0.7.3, and the same
//                           "report failed" line appears under v0.7.2 at 2026-07-27 14:11:29 on the same
//                           path. It has been live since at least v0.7.2 and was never noticed, because
//                           this is the one failure path nobody had exercised since the report became
//                           mandatory in v0.2.0.
//                           FIX: the dialog result is held in a LOCAL and the field is assigned only
//                           once it is known non-null, so wlFile is never null - it is "" or a path.
//                           This restores the property STATUS, the playbook and D-S15-16 all claim -
//                           that the report is written on every failure path. That claim was FALSE for
//                           1 of the 10 and the three documents need correcting, not just this code.
//                       (2) AUDIBLE ALERT (Jim's ask). On a genuine fault the script now plays a WAV
//                           through System.Media.SoundPlayer before the method's Show Message appears.
//                           WHY A PRE-RENDERED WAV AND NOT SPEECH AT RUNTIME: SoundPlayer lives in
//                           System.dll, which this script already depends on and which demonstrably
//                           compiles inside MM4. System.Speech does NOT, and MM4's script-compiler
//                           reference list could not be determined from its binaries - so synthesising
//                           at runtime would rest on an assumption. The phrase is rendered ONCE by
//                           RenderPhrase.exe and the script only ever plays a file.
//                           NOT ON CANCELLED. A cancel is the operator's own decision, not a fault, and
//                           does not deserve an alarm. ShouldSound() is the one place that decides.
//                           NEVER FATAL: every audio call is wrapped and swallowed. A missing or
//                           unreadable WAV means silence, never a failed run.
//                           BLOCKING, DELIBERATELY: PlaySync so the clip finishes before the method
//                           advances to Show Message, which keeps the ordering deterministic. The
//                           current clip is 3.05 s (mono 16-bit 22,050 Hz). It only ever runs on an
//                           abort, never on a normal run.
//                       WHAT IS STILL UNPROVEN AND MUST NOT BE CLAIMED: audio was verified on this
//                       machine as a standalone .NET program (AudioProbe: SoundPlayer play, looping
//                       play/stop, 2 installed voices, the phrase rendered to a real RIFF/WAVE). It has
//                       NOT been proven from inside MM4's script host, and nobody has confirmed sound
//                       actually left the speakers. Jim's run is what settles both.
//   v0.7.6  2026-07-28  THE VALIDATION SECTION CRIED WOLF ON A STOPPED RUN. Found by Jim's test round,
//                       not by my testing.
//                       WHAT HE SAW: dup and overcap stopped exactly as intended, and their reports
//                       nonetheless printed a red
//                         "DISAGREEMENTS FOUND (22 / 121 / 176 element(s), 0 parameter(s))"
//                       with two FAIL rows:
//                         "Row count re-derived ... equals User.TransferCount_01 | FAIL | 11 vs 0"
//                         "Every bridge list element matches the re-derived value | FAIL | 121 elements"
//                       Every number was arithmetically TRUE and the conclusion was WRONG. On a stopped
//                       run the bridge is DELIBERATELY never written, so MM4 holds empty lists by
//                       design; the cross-check compared re-derived-from-file against empty and called
//                       it a disagreement. A reader sees a validation failure on a run that behaved
//                       correctly - and could reasonably conclude the parser had mis-read the worklist.
//                       Same family as the v0.7.4 dead checks: a check asserting something untrue.
//                       ⚠ THE OBVIOUS FIX WAS WRONG, AND CHECKING IS WHAT CAUGHT IT. Keying this off
//                       the report's ok flag ("if the run failed, skip the cross-check") looked right
//                       and is NOT: the Confirm-Proceed cancel at :742 calls Fail AFTER the bridge is
//                       written at :715. On that path the run failed but the bridge is complete and the
//                       cross-check is entirely valid - suppressing it would have hidden real evidence.
//                       SO IT KEYS OFF ACTUAL STATE, NOT OUTCOME. Two flags, each set at the exact
//                       point the thing they describe becomes true:
//                         bridgeWritten - set after section 6 finishes writing the per-sample lists
//                         paramsWritten - set after the header-block scalars are pushed to MM4
//                       When the bridge was never written the section says so plainly, emits NO verdict
//                       and NO comparison rows, and still shows what the worklist DOES determine (the
//                       deck mapping) because that is derived from the file and remains useful. The
//                       run-parameter table still prints whenever those scalars were genuinely set,
//                       which on a WORKLIST_INVALID abort they were.
//                       Nothing about the passing path changes: a completed run reports exactly as before.
// ============================================================================

// v0.8.8: customer-neutral presentation release; execution logic is unchanged.
public class MMScriptExecutor : IMMScriptExecutor
{
    // =========================
    // DEV MODE  (reference workflow D109 visibility model)
    // =========================
    //   false = OPERATOR report  — header + status + run summary + deck layout + placement checklist
    //   true  = DEV report       — everything above PLUS parse detail, per-sample bridge table,
    //                              bridge variable read-back, validation matrix, raw deck parse.
    // The report is generated in BOTH modes and on BOTH outcomes.
    private static readonly bool DEV_MODE = true;

    // v0.8.4  2026-07-30  TWO CHANGES, ONE CAUSE — the published lists were the wrong SHAPE and
    //                     carried two conventions at once. Both are Jim rulings from S20.
    //
    //   (1) PLATE-MAJOR NAMES FOR THE METHOD (D-S20-06). Jim: "our commands are, primarily,
    //       plate/labware major. the command parameters can be well/channel variablized but that is
    //       usually via VI/VMDI/VO/etc outputs." Verified against the method — it references ZERO
    //       well-level variables; the only per-well item is a VO coming back OUT of a dispense.
    //       Up to v0.8.3 this script wrote SourcePlate_List_01 / QuantPlate_List_01 /
    //       OutputPlate_List_01 / TipBox_List_01 with ONE ELEMENT PER WORKLIST ROW — 168 copies of
    //       the same plate name on a 168-row run. That is a plate fact variablised at well
    //       granularity, and it is what broke the method's plate loops: a loop counting plates 1,2,3
    //       indexed a 168-element list whose first 60 entries were all plate 1, so it would have
    //       processed plate 1 three times and never touched plates 2 and 3. Those four names are now
    //       ONE ELEMENT PER PLATE SET. The row-level assignment the completed worklist genuinely
    //       needs moved to Row_* names that only scripts read.
    //
    //   (2) LEADING COMMA ON EVERY LIST (D-S20-05). Jim: "i would rather have no adjustment of the
    //       index if possible, so i would like to have any list be preceeded with a ',' to simplify
    //       any loop logic + parsing of lists." A base-1 counter — which matches the COUNT of
    //       labware — now indexes the first real element directly, everywhere, with no -1. v0.8.3
    //       used LeadingList() for per-plate lists and a bare join for per-row ones; that split is
    //       exactly what let a counter read the wrong element with nothing reporting it.
    //
    //   KNOCK-ON FIXES the change forced, each of which would otherwise have broken silently:
    //     - the independent re-derivation cross-check (the S15 feature that compares a second parse
    //       against MM4's live variables) drops the phantom before comparing, or A and B sit one
    //       apart and EVERY element reports as a disagreement;
    //     - the "computed later, empty by design" size check counts real elements, or n+1 != n fails
    //       on every run;
    //     - the paste-ready table now also prints the four plate-major lists.
    // v0.8.5  2026-07-30  THE STAMP VI — the worklist now decides which channels move.
    //                     Jim carried all-96-channels-at-2uL as a DELIBERATE temporary parameter:
    //                     "the 96 channels are a temp parameter until we get the worklist to VI wired
    //                     and working. that will determine full/partial transfers." This is that
    //                     wiring. Publishes User.StampVI_List_01 — one VI string per plate, occupied
    //                     wells carrying 2 uL (QUANT-002) and every other channel left EMPTY so it
    //                     does nothing. DASH-separated with a leading dash, because a VI string is
    //                     itself comma-delimited and can never be an element of a comma-separated
    //                     list; the leading dash keeps the base-1 rule (D-S20-05) intact.
    //                     ALSO ADDS WELL-FORMAT VALIDATION, which only became load-bearing now: a VI
    //                     addresses channels BY LABEL, so a label that does not resolve has no channel
    //                     and that well's 2 uL would never be dispensed — silently, on a green run,
    //                     one well short. Presence and duplication were already checked; the label
    //                     itself was not.
    //                     NEW NUMBER RATHER THAN A FOLD-IN: v0.8.4 is what the method's [4] was
    //                     pointed at, and this adds capability rather than fixing v0.8.4. Changing
    //                     content under a label already selected is how a version stops meaning one
    //                     thing. [4] needs repointing to v0.8.5.
    // v0.8.6  2026-07-31  THE STAMP IS AN OVER-ASPIRATE: 5 uL IN, 3 uL OUT — AND IT IS NOW TWO VIs.
    //                     Cory, relayed by Jim: "for the lunatic plate, we should probably aspirate
    //                     5uL from source and dispense 3uL into lunatic plate for reading. we have to
    //                     ensure there is no air transfer to well." The Lunatic reads through a small
    //                     optical window and an air bubble in it corrupts the read; dispensing LESS
    //                     than was aspirated leaves liquid in the tip so the trailing air never enters
    //                     the well.
    //                     ⚠ THIS FALSIFIES v0.8.5's OWN COMMENT, which said "THE SAME STRING SERVES
    //                     ASPIRATE AND DISPENSE ... there is no overage or carry factor in this
    //                     workflow." There IS an overage now, so that reasoning is struck below rather
    //                     than quietly deleted.
    //                     WHAT CHANGES: one constant becomes two, StampVI takes the volume as a
    //                     parameter, and the single User.StampVI_List_01 becomes the PAIR the method
    //                     already wires — Jim added the ListParsers and pointed both commands at them,
    //                     so THE METHOD'S NAMES ARE THE CONTRACT (D-S17-05, D-S20-08) and this script
    //                     adapts to them rather than the other way round:
    //                       User.Quant_Aspirate_VI_List_01  -> ListParser -> User.Quant_Aspirate_VI_01
    //                       User.Quant_Dispense_VI_List_01  -> ListParser -> User.Quant_Dispense_VI_01
    //                     ⚠ CORRECTED SAME DAY, BEFORE THIS VERSION EVER RAN. The paragraph below
    //                     originally said bare volumes were emitted and that whether a VI overrides
    //                     the command grid was "not established". Jim then established it: "the vi
    //                     will override all asp/disp parameters for fields that are available in the
    //                     vi deconvolution." The leading air gap IS such a field, so a bare volume
    //                     would have ZEROED the 5 uL gap rather than left it alone. The aspirate VI
    //                     now carries "5;5;0" explicitly. Kept as a correction, not overwritten,
    //                     because the reasoning that changed is the useful part.
    //                     ORIGINAL, NOW SUPERSEDED: BARE VOLUMES, NO AIR-GAP SUB-FIELDS. A VI field is <Volume>;<LeadingGap>;<TrailingGap> and omitted
    //                     sub-fields default to 0 (mm4-data-formats-reference.md:145-152, Jim-verified
    //                     2026-06-05). The Quant aspirate carries a 5 uL LEADING AIR GAP on all 96
    //                     channels in the command grid, which Jim keeps deliberately: "it normalizes
    //                     the interior pipette tip pressure before aspiration increasing small volume
    //                     aspiration accuracy."
    //                     ⚠ WHETHER A VI OVERRIDES THAT GRID SETTING IS NOT ESTABLISHED. Evidence from
    //                     the 2026-07-30 15:16 run, MM4's own log: the STATIC stamp aspirate printed
    //                     "Leading airgap parameters (96)" all at 5.0 uL, while the VI-DRIVEN diluent
    //                     aspirate printed NO airgap block at all — but those two also differ in how
    //                     many channels carry the gap (96 vs 1), so the comparison is confounded and
    //                     proves nothing on its own. Bare volumes are emitted because that is exactly
    //                     what the Sample and Diluent VIs already emit — one convention, not two — and
    //                     because MM4 PRINTS the per-channel gap every run, so the next run settles it
    //                     by reading rather than by arguing. If the stamp aspirate's airgap block is
    //                     absent or zero, the gap moves into the VI as "5;5;0" and this note is the
    //                     record of why.
    // v0.8.7  2026-10-07  Coordinated repair release; see CHANGELOG.md and README.md.
    // v0.8.9  2026-11-18  SPECTRAMAX / NO-SR710 VARIANT (Quant_Norm_SpectraMax_v0_3_0.met).
    //                     - Quant plate is a 96-well half-area UV plate read on a SpectraMax, not a
    //                       Lunatic plate. The stamp is no longer a neat 2-3 uL drop: the quant well is
    //                       pre-filled with QuantDiluentVolume (default 45 uL) and QuantSampleVolume
    //                       (default 5 uL) is dispensed into it and mixed -> 1:10. Both are header-
    //                       configurable; the dilution factor is DERIVED, never entered separately.
    //                     - New VI lists: User.QuantDiluent_Aspirate/Dispense_VI_List_01 and
    //                       User.QuantMix_VI_List_01, same masking (occupied wells only).
    //                     - Quant dispenses are EXACT (no over-stroke): these wells are read optically
    //                       and air pushed into them makes bubbles.
    //                     - No deck barcode reader: both scan gates are forced to "" (NOT BARCODED), so
    //                       quant and output plates get generated tracking IDs; only SOURCE barcodes are
    //                       typed by the operator. The dialog shows the modes but locks them.
    //                     - Reader configuration published for ReaderNormVI: ReaderModel,
    //                       ReaderPathlengthCm (no default - must be calibrated), ReaderLowSignalOD.
    //                     - Deck handles keep the Lunatic_ prefix in this revision (worktable unchanged).
    private const string SCRIPT_VERSION = "v0.8.9";

    // v0.8.9 — this variant has no SR710; the barcode-mode choice is fixed, not offered.
    // static readonly, not const: a const would fold the scanner branch away (CS0162/CS0429 under /warnaserror).
    private static readonly bool HAS_DECK_SCANNER = false;

    // ---- audible alert on a genuine fault ----
    // The WAV is a BUILD ARTIFACT, rendered once by RenderPhrase.exe and registered in
    // quant-norm-artifacts.tsv. The script only plays it. Set ALERT_SOUND false to silence everything.
    // static readonly, NOT const, and deliberately so: as a const the compiler folds !ALERT_SOUND to
    // false and the guard in ShouldSound becomes unreachable code (CS0162). Same form as DEV_MODE.
    private static readonly bool ALERT_SOUND = true;
    private const string ALERT_SOUND_DIR  = "Sounds";
    private const string ALERT_SOUND_FILE = "QuantNorm_alert.wav";
    // Abort codes that are the OPERATOR'S OWN CHOICE rather than a fault - these never sound.
    private static readonly string[] SILENT_CODES = new string[] { "CANCELLED" };

    // The run-parameter pairs, declared ONCE: the comparison table and the summary's "N parameters"
    // both read this array, so the count can never disagree with the rows actually checked.
    private static readonly string[][] PARAM_PAIRS = new string[][] {
        new string[]{ "InputScale", V_SCALE }, new string[]{ "ExtinctionCoefficientUsed", V_EXTCOEF },
        new string[]{ "TargetConcentration", V_TARGET }, new string[]{ "RequestedOutputVolume", V_OUTVOL },
        new string[]{ "A260AcceptanceLogic", V_ACCEPT } };
    private const int    DECK_ROWS = 6;              // every Lynx deck is N columns x 6 rows
    private const int    MAX_SOURCE_PLATES = 4;

    // The issue types the row scan can raise. THE SELF-REPORT TABLE IS GENERATED FROM THIS - one row
    // per entry, PASS/FAIL decided by counting issues whose Kind matches. Two consequences, and both
    // are the point of it existing:
    //   - a new issue type added to the scan without an entry here has no row, which is visible,
    //     rather than a row that silently reads PASS;
    //   - the operator-facing What text can be reworded freely without touching any check.
    // Columns: [0] Kind code  [1] check label  [2] detail when clean  [3] unit noun when not
    private static readonly string[][] ISSUE_KINDS = new string[][] {
        new string[] { "BLANK",   "No blank plate barcodes or wells", "every row has both",       "blank" },
        new string[] { "WELL", "Valid 1:1 well mappings", "all well labels and mappings valid", "well" },
        new string[] { "DUP",     "No duplicate wells",               "no plate/well pair repeats","duplicate" },
        new string[] { "OVERCAP", "Source plates within capacity",    "within the limit",          "plate over the limit" },
        new string[] { "DECK",    "All required deck positions loaded","all present",              "missing position" }
    };

    // ---- control / file / deck scalars ----
    const string V_ABORT   = "User.AbortMethod_01";
    const string V_STATUS  = "User.ScriptStatus_01";
    const string V_MSG     = "User.ScriptMessage_01";
    const string V_RUNID   = "User.RunID_01";
    const string V_COUNT   = "User.TransferCount_01";
    const string V_WLFILE  = "User.WorklistFile_01";
    const string V_REPORT  = "User.ReportPath_01";
    const string V_WORKTBL = "User.OutputWorktable_01";   // deck layout (exists; READ only)
    const string V_DILLOC  = "User.DiluentLoc_01";
    const string V_USERRESP = "User.user_response_01";    // Confirm-Proceed answer: "OK" | "CANCEL"

    // ---- v0.8.0 BARCODE MODE GATES (Jim, S18) ----------------------------------------------
    // The METHOD gates each optional scan section on these with Operator = NotEmpty:
    //     [33] If User.QuantBarcode_Perform_01  NotEmpty  ... [50] End If
    //     [53] If User.OutputBarcode_Perform_01 NotEmpty  ... [70] End If
    // ⚠ NotEmpty, NOT a True/False comparison. ANY non-empty value runs the scan; ONLY an empty
    // string skips it. Writing "False" here would be NON-EMPTY and would RUN the scan.
    //
    // So the value does double duty (Jim, S18): emptiness is the gate, and the text is the MODE
    // the validator pairs by. Three modes, matching the three real-world cases:
    //   ""         plate is NOT barcoded  -> scan skipped, paired by deck ROW, ID generated
    //   "CAPTURE"  barcoded, assigned as loaded -> scan runs, paired by deck ROW, scanned value kept
    //   "WORKLIST" barcoded AND designated by the worklist -> scan runs, paired BY BARCODE, and the
    //              plate may therefore sit in a DIFFERENT deck row from its source plate
    const string V_QPERFORM = "User.QuantBarcode_Perform_01";
    const string V_OPERFORM = "User.OutputBarcode_Perform_01";

    // v0.8.1 — the barcode validator's operator-resolution pair. Ingestion does not read these; it
    // BLANKS them, because both are per-RUN state and both are dangerous if inherited:
    //   BarcodeResolution_01 : a stale "RESCAN" makes the method jump back to the Rescan label on the
    //                          strength of a decision an operator made during a previous run.
    //   BarcodeAttempt_01    : a stale count starts this run already at or past the 3-attempt cap, so
    //                          the operator would be refused a re-scan they have not yet used.
    const string V_RESOLUTION = "User.BarcodeResolution_01";
    const string V_ATTEMPT    = "User.BarcodeAttempt_01";
    const string MODE_NONE     = "";
    const string MODE_CAPTURE  = "CAPTURE";
    const string MODE_WORKLIST = "WORKLIST";

    // ---- compute-param scalars ----
    const string V_SCALE    = "User.InputScale_01";
    const string V_EXTCOEF  = "User.ExtinctionCoefficient_01";
    const string V_TARGET   = "User.TargetConcentration_01";
    const string V_OUTVOL   = "User.RequestedOutputVolume_01";
    const string V_ACCEPT   = "User.A260AcceptanceLogic_01";

    // =====================================================================================
    //  v0.8.4 — THE TWO FAMILIES, AND WHY THEY ARE NOW SEPARATE NAMES
    // =====================================================================================
    // MM4 COMMANDS ARE PLATE/LABWARE MAJOR (Jim, S20). A command takes ONE plate; the per-well
    // variation inside it arrives through VI/VMDI and comes back through VO. It never arrives
    // through a method variable list. Verified against the method: it references ZERO well-level
    // variables — every command-driving variable is plate-level, and the only per-well item anywhere
    // is a VO coming back OUT of a dispense.
    //
    // Up to v0.8.3 this script published plate-level facts (plate name, tip box, deck location) as
    // PER-ROW lists — for a 168-row run, the same plate name written out 168 times. That is a plate
    // fact variablised at well granularity, and it is what broke the method's plate loops: a loop
    // counting plates 1,2,3 indexed a 168-element list whose first 60 entries are all plate 1, so it
    // processed plate 1 three times and never touched plates 2 and 3.
    //
    // So the names the METHOD reads are now PER PLATE, and the row-level bookkeeping — which the
    // completed worklist genuinely needs — moved to Row_* names that ONLY scripts touch and no
    // command ever sees.
    //
    // AND EVERY LIST NOW CARRIES A LEADING COMMA (Jim, D-S20-05): "i would rather have no adjustment
    // of the index if possible, so i would like to have any list be preceeded with a ',' to simplify
    // any loop logic + parsing of lists." A base-1 loop counter — which matches the COUNT of labware —
    // then indexes the first real element directly, with no -1 anywhere. v0.8.3 had two conventions
    // at once (per-plate lists led with a comma, per-row lists did not), and that split is precisely
    // what produced the indexing faults.
    // =====================================================================================

    // ---- PER-PLATE — what the METHOD reads. One element per plate set, leading comma. ----
    const string L_SRCPLATE = "User.SourcePlate_List_01";
    const string L_QPLATE   = "User.QuantPlate_List_01";
    const string L_OPLATE   = "User.OutputPlate_List_01";
    const string L_TIPBOX   = "User.TipBox_List_01";

    // ---- PER-ROW — script bookkeeping only. One element per worklist row, leading comma. ----
    const string L_SRCBC    = "User.SourcePlateBarcode_List_01";
    const string L_SRCWELL  = "User.SourceWell_List_01";
    const string L_QWELL    = "User.QuantWell_List_01";
    const string L_OWELL    = "User.OutputWell_List_01";
    const string L_QBC      = "User.QuantBarcode_List_01";
    const string L_OBC      = "User.OutputBarcode_List_01";
    // The row-level plate assignment. Barcode validation rewrites these from the actual scan, and the
    // completed worklist is built from them. NOTHING in the method reads them, by design.
    const string R_SRCPLATE = "User.Row_SourcePlate_List_01";
    const string R_SRCLOC   = "User.Row_SourceLoc_List_01";
    const string R_QPLATE   = "User.Row_QuantPlate_List_01";
    const string R_QLOC     = "User.Row_QuantLoc_List_01";
    const string R_OPLATE   = "User.Row_OutputPlate_List_01";
    const string R_OLOC     = "User.Row_OutputLoc_List_01";
    const string R_TIPBOX   = "User.Row_TipBox_List_01";

    // ---- PER-PLATE lists for the barcode deck scan (v0.7.7) ----
    // A deck scan is PER PLATE: the arm visits each plate position once. These are the lists the scan
    // loop and the validation script use, and they are the values Jim copies out of the report to
    // paste into MM4.
    //
    // ⚠ NOTE ON WHAT IS DELIBERATELY *NOT* HERE: there is no separate SourceLoc/QuantLoc/OutputLoc
    // per-plate list. Once those became per-plate they would be byte-identical to the three scan-
    // location lists below, and two names for one fact is a drift waiting to happen. The scan
    // location lists ARE the per-plate location lists. The method already reads them ([18]/[37]/[57]
    // and the plate-move loop), so nothing is missing — only the duplicate.
    const string P_EXPSRCBC = "User.ExpectedSourceBarcode_List_01";  // distinct source barcodes, first-seen order
    const string P_SRCLOC   = "User.ExpectedSourceLoc_List_01";      // deck Loc of each, same index
    const string P_QLOC     = "User.QuantScanLoc_List_01";           // where each quant plate is scanned
    const string P_OLOC     = "User.OutputScanLoc_List_01";          // where each output plate is scanned
    const string P_COUNT    = "User.ScanPlateCount_01";              // number of plate SETS this run uses
    // v0.8.5 — one VI string per plate for the 2 uL stamp, DASH-separated with a leading dash.
    // v0.8.6 — the PAIR the method wires. Names are the METHOD's, read from the .met.
    const string L_QVI_ASP  = "User.Quant_Aspirate_VI_List_01";
    const string L_QVI_DISP = "User.Quant_Dispense_VI_List_01";
    const string L_A260_1   = "User.A260_1_List_01";
    const string L_A260_2   = "User.A260_2_List_01";
    const string L_ACCA260  = "User.AcceptedA260_List_01";
    const string L_A280     = "User.A280_List_01";
    const string L_A230     = "User.A230_List_01";
    const string L_CALCCONC = "User.CalculatedConcentration_List_01";
    const string L_XFERVOL  = "User.TransferVolume_List_01";
    const string L_DILVOL   = "User.DiluentVolume_List_01";
    const string L_PURITY   = "User.PurityFlag_List_01";
    const string L_XFERSTAT = "User.TransferStatus_List_01";

    // deck handle prefixes
    const string HDL_SOURCE  = "Source_Standin_";
    const string HDL_LUNATIC = "Lunatic_";
    const string HDL_OUTPUT  = "Output_";
    const string HDL_SAMPTIP = "Sample_Tips_";
    const string HDL_DILTIP  = "Diluent_Tips_";
    const string HDL_DILUENT = "Diluent";

    static readonly string[] OWNED = new string[] {
        V_COUNT, V_WLFILE, V_SCALE, V_EXTCOEF, V_TARGET, V_OUTVOL, V_ACCEPT, V_DILLOC, V_USERRESP,
        L_SRCBC, L_SRCWELL, L_QWELL, L_OWELL, L_SRCPLATE, L_QPLATE, L_OPLATE, L_TIPBOX,
        R_SRCPLATE, R_SRCLOC, R_QPLATE, R_QLOC, R_OPLATE, R_OLOC, R_TIPBOX,
        L_QBC, L_OBC, L_A260_1, L_A260_2, L_ACCA260, L_A280, L_A230,
        L_CALCCONC, L_XFERVOL, L_DILVOL, L_PURITY, L_XFERSTAT,
        P_EXPSRCBC, P_SRCLOC, P_QLOC, P_OLOC, P_COUNT, L_QVI_ASP, L_QVI_DISP,
        L_QDIL_ASP, L_QDIL_DISP, L_QMIX,
        "User.QuantSampleVolume_01", "User.QuantDiluentVolume_01", "User.QuantDilutionFactor_01",
        "User.ReaderModel_01", "User.ReaderPathlengthCm_01", "User.ReaderLowSignalOD_01", "User.BlankMethod_01", "User.QuantPlateType_01",
        "User.BlankPlate1_01", "User.BlankPlate2_01", "User.BlankPlate3_01", "User.BlankPlate4_01", "User.ReaderPhase_01",
        "User.SpectraMaxBlankFile_01", "User.SpectraMaxRead1File_01", "User.SpectraMaxRead2File_01"
    };
    // v0.8.0 — the two mode gates are OWNED: blanked at the top of every run, then set from this
    // run's dialog choice. Jim asked for this directly and it closes a real hazard: MM4 variables
    // persist across runs (D-S14-03) and the gate is NotEmpty, so a value left over from a previous
    // run would make a scan RUN even when this run's operator chose to skip it.
    static readonly string[] OWNED_V080 = new string[] { V_QPERFORM, V_OPERFORM, V_RESOLUTION, V_ATTEMPT };

    // NOT owned by ingestion — the METHOD writes these during its scan loops. Ingestion blanks them
    // anyway, because Jim's new If gates moved each section's own clears INSIDE the gate:
    //   quant clears  [34]/[35] sit AFTER [33] If
    //   output clears [54]/[55] sit AFTER [53] If
    // so a SKIPPED scan never reaches its clear and would inherit the previous run's barcodes, which
    // the validator would then read as if they belonged to this run. (S17 defect class 4.)
    // The SOURCE pair is deliberately NOT in this list: its clears at [15]/[16] are outside any gate
    // and always run, so blanking them here would imply an ownership ingestion does not have.
    static readonly string[] GATED_SCAN_OUTPUTS = new string[] {
        "User.QuantBarcode_Scanned_List_01",  "User.QuantBarcode_Read_By_List_01",
        "User.OutputBarcode_Scanned_List_01", "User.OutputBarcode_Read_By_List_01"
    };

    static readonly string[] ALL = OWNED
        .Concat(OWNED_V080).Concat(GATED_SCAN_OUTPUTS)
        .Concat(new string[] { V_ABORT, V_STATUS, V_MSG, V_RUNID, V_REPORT }).ToArray();

    // ======================= run context (what the report draws on) =======================
    private string runId = "", wlFile = "", reportDir = "", wsRoot = "";
    // STATE, not outcome. Each is set at the exact moment the thing it describes becomes true,
    // so the report can never claim a comparison it had nothing to compare against. Deliberately
    // NOT derived from the ok/fail flag - see the v0.7.6 note: one failure path writes the bridge.
    private bool bridgeWritten = false;   // the per-sample lists are in MM4
    private bool paramsWritten = false;   // the header-block scalars are in MM4
    // What the alert actually did, recorded so the DEV report can show it. Until v0.7.7 a successful
    // play left NO trace anywhere, which is why diagnosing the 09:52 "no sound" runs needed forensic
    // timing of MM4 step boundaries instead of reading one line. A success that leaves no evidence
    // cannot be verified - same lesson as the checks that could never fail.
    private string alertLog = "not reached";
    // v0.8.0 — the operator's barcode-mode choice for this run, held so the report can state it.
    // "" = not barcoded · "CAPTURE" = barcoded, assigned as loaded · "WORKLIST" = worklist designates.
    private string quantMode = MODE_NONE, outputMode = MODE_CAPTURE;
    private Dictionary<string, string> deck = new Dictionary<string, string>();      // handle -> Loc
    private Dictionary<string, string> fileHeader = new Dictionary<string, string>();
    private List<string> colNames = new List<string>();
    private int dataRowCount = 0;
    private List<string> srcOrder = new List<string>();
    private List<RowIssue> issues = new List<RowIssue>();       // localised, collected
    private List<string> badLocs = new List<string>();          // deck positions implicated in a failure
    private List<Sample> samples = new List<Sample>();
    private string failCode = "", failMsg = "";
    private List<string> rebuildKept = new List<string>();
    private List<string> rebuildRemoved = new List<string>();
    private List<string> rebuildErrors = new List<string>();
    private int platesRequired = 0;
    private string deckSource = "method snapshot (User.OutputWorktable_01)";
    private Dictionary<int, List<int>> problemRowIndex = new Dictionary<int, List<int>>();
    private Dictionary<int, string> problemTip = new Dictionary<int, string>();

    private class Sample
    {
        public int RowNo; public string Id, Animal, Tissue, SrcBc, SrcWell, QWell, OWell;
        public string QBcDesig = "", OBcDesig = "";     // designated barcodes, WORKLIST mode only
        public string SrcPlate, SrcLoc, QPlate, QLoc, OPlate, OLoc, TipBox;
    }
    private class RowIssue
    {
        public int RowNo;                       // primary row (kept for ordering)
        // STABLE machine code for this issue type - BLANK / DUP / OVERCAP / DECK.
        // Everything that has to REASON about an issue reads Kind. Nothing reasons about What:
        // What is prose written for the operator and is expected to be reworded (v0.7.0 rewrote all
        // four), which is precisely what silently disabled two checks in v0.7.3.
        public string Kind = "";
        public string What = "", Detail = "";
        public List<int> Rows = new List<int>(); // EVERY row involved - both halves of a duplicate
        public string Column = "", Value = "", Plate = "", Well = "";
        public string Why = "", Fix = "";
        public string Handle = "", Loc = "";     // where to find it on the deck
    }

    // One deck position, as MM4 reports it. Field order of User.OutputWorktable_01:
    // Location, Stack index, Plate name, Plate barcode, Labware, X, Y, Z, Worktable, Device
    private class DeckPos
    {
        public string Loc = "", Plate = "", Barcode = "", Labware = "", Worktable = "", Device = "";
        public double X, Y, Z;
        public bool Occupied;
    }
    private class LabwareDef
    {
        public string Name = "";
        public double Length = 127.76, Width = 85.5;
        public int Rows, Cols;
        public string Body = "", Well = "";
        public double A1Col, A1Row, ColSpacing, RowSpacing, WellL, WellW;
        public bool Circular = true;
    }
    private List<DeckPos> deckPos = new List<DeckPos>();
    private Dictionary<string, LabwareDef> labware = new Dictionary<string, LabwareDef>();
    private string wtDevice = "Lynx", wtName = "Left";

    public void Execute(IMMApp app)
    {
        try { RunIngestion(app); }
        catch (Exception ex)
        {
            app.SetVariable(V_ABORT, "True");
            app.SetVariable(V_STATUS, "EXCEPTION");
            app.SetVariable(V_MSG, "Worklist ingestion stopped: " + ex.Message);
            Fail(app, "EXCEPTION", "Worklist ingestion stopped: " + ex.Message);
        }
    }

    private void RunIngestion(IMMApp app)
    {
        // ---- 1. INIT ----
        ResetRepairState(app);
        foreach (string v in ALL) EnsureVariable(app, v, "");
        foreach (string v in OWNED) app.SetVariable(v, "");
        // v0.8.0 — blank the mode gates and the gated scan outputs BEFORE anything can fail. If this
        // run aborts before the dialog sets them, both scans stay off rather than inheriting the last
        // run's setting. Blank-then-set, never set-over-stale.
        foreach (string v in OWNED_V080) app.SetVariable(v, "");
        foreach (string v in GATED_SCAN_OUTPUTS) app.SetVariable(v, "");
        runId = DateTime.Now.ToString("yyyyMMdd_HHmmss_fff");
        app.SetVariable("User.RunStartTimestamp_01", DateTime.Now.ToString("o"));
        app.SetVariable(V_ABORT, "False"); app.SetVariable(V_STATUS, "Running");
        app.SetVariable(V_MSG, "Worklist ingestion started"); app.SetVariable(V_RUNID, runId);

        // report folder resolved FIRST so a failure can still write a report
        reportDir = app.WorkspaceOutputPath;
        Qn.Require(!string.IsNullOrEmpty(reportDir), "The workspace output folder is not configured.");
        try { if (!Directory.Exists(reportDir)) Directory.CreateDirectory(reportDir); }
        catch (Exception ex) { throw new IOException("The workspace output folder is not writable; no run may proceed without its records.", ex); }
        app.SetVariable(V_REPORT, reportDir);

        // ---- 2. CHOOSE WORKLIST ----
        string wsDir; try { wsDir = new DirectoryInfo(app.WorkspaceOutputPath).Parent.FullName; } catch (Exception) { wsDir = ""; }
        wsRoot = wsDir;                       // held so the alert WAV can be found from the failure path
        // The result is kept in a LOCAL. wlFile is a field the report reads, and ChooseWorklistDialog
        // returns null on Cancel - assigning that to the field before this guard is what made
        // WriteReport throw and produced no report at all (see the v0.7.5 note above).
        string qMode, oMode;
        string chosen = ChooseWorklistDialog(wsDir, out qMode, out oMode);
        if (chosen == null) { Fail(app, "CANCELLED",
            "No worklist was selected, so the run has been stopped.\n\nStart the method again and choose a worklist."); return; }
        wlFile = chosen;
        app.SetVariable(V_WLFILE, wlFile);
        string snapshot = Path.Combine(reportDir, "QuantNorm_input_snapshot_" + runId + ".csv");
        File.Copy(wlFile, snapshot, false);
        app.SetVariable("User.InputSnapshotFile_01", snapshot);
        app.SetVariable("User.SourceWorklistHash_01", Qn.HashFile(snapshot));

        // v0.8.0 — publish the two mode gates. Emptiness is what the method's NotEmpty tests read;
        // the text is what the validator pairs by. Set only AFTER a worklist is confirmed, so a
        // cancelled dialog leaves both blank (both scans off) rather than half-configured.
        if (!HAS_DECK_SCANNER) { qMode = MODE_NONE; oMode = MODE_NONE; }   // v0.8.9 — nothing can scan them
        quantMode = qMode; outputMode = oMode;
        app.SetVariable(V_QPERFORM, quantMode);
        app.SetVariable(V_OPERFORM, outputMode);

        // ---- 3. DECK ----
        deck = ParseWorktable(SafeGet(app, V_WORKTBL));
        LoadEmptyPositions(wsDir); LoadLabware(wsDir);
        if (deck.Count == 0) { Fail(app, "NO_WORKTABLE",
            "The deck layout could not be read, so the run has been stopped.\n\nStart the method again from the first step. If this happens again, contact your application engineer."); return; }
        app.SetVariable(V_DILLOC, deck.ContainsKey(HDL_DILUENT) ? deck[HDL_DILUENT] : "");

        // ---- 4. PARSE WORKLIST ----
        List<string> lines;
        try { lines = Qn.ReadRecords(snapshot); }
        catch (Exception ex) { Fail(app, "READ_ERROR",
            "The worklist file could not be opened, so the run has been stopped.\n\nThe file may be open in another program, or may have been moved or renamed. Close it elsewhere and start the method again.\n\nDetails: " + ex.Message); return; }

        List<string> col = null;
        var rows = new List<string[]>();
        foreach (string raw in lines)
        {
            string line = raw.TrimEnd();
            if (line.Length == 0 || line.TrimStart().StartsWith("#")) continue;
            if (col == null)
            {
                string[] cells = Qn.Fields(line, ',');
                if (IsColumnHeader(cells)) { col = cells.Select(NormalizeCol).ToList(); colNames = cells.Select(c => c.Trim()).ToList(); continue; }
                int colonAt = line.IndexOf(':');
                if (colonAt > 0) fileHeader[NormalizeCol(line.Substring(0, colonAt))] = line.Substring(colonAt + 1).Trim();
                continue;
            }
            string[] dataFields = Qn.Fields(line, ',');
            Qn.Require(dataFields.Length == col.Count, "CSV row " + (rows.Count + 1) + " has " + dataFields.Length + " fields; expected " + col.Count + ".");
            rows.Add(dataFields);
        }
        dataRowCount = rows.Count;
        if (col == null) { Fail(app, "NO_HEADER_ROW",
            "This file does not look like a worklist - no column headings were found in it, so the run has been stopped.\n\nCheck that you selected the right file, then start the method again."); return; }
        if (rows.Count == 0) { Fail(app, "EMPTY_WORKLIST",
            "The worklist has column headings but does not list any samples, so the run has been stopped.\n\nCheck that you selected the right file, then start the method again."); return; }

        int iBc = Col(col, "SourcePlateBarcode"), iSw = Col(col, "SourceWell");
        int iQw = Col(col, "QuantificationWell"), iOw = Col(col, "OutputWell");
        // v0.8.2 — the DESIGNATED quant/output barcodes. Normally empty (Appendix B.1: "left empty"),
        // but in WORKLIST mode they are what the operator has to put on the plates, so the report has
        // to be able to show them. Read unconditionally; absence of the column is not an error.
        int iQbc = Col(col, "QuantificationPlateBarcode"), iObc = Col(col, "OutputPlateBarcode");
        int iId = Col(col, "ID"), iAnimal = Col(col, "AnimalID"), iTissue = Col(col, "TissueType");
        var miss = new List<string>();
        if (iBc < 0) miss.Add("SourcePlateBarcode"); if (iSw < 0) miss.Add("SourceWell");
        if (iQw < 0) miss.Add("QuantificationWell"); if (iOw < 0) miss.Add("OutputWell");
        if (miss.Count > 0) { Fail(app, "MISSING_COLUMNS",
            (miss.Count == 1 ? "The worklist is missing a column this method needs: " : "The worklist is missing columns this method needs: ")
            + string.Join(", ", miss) + ".\n\nCheck that you selected the right worklist, then start the method again."); return; }

        SetIfPresent(app, fileHeader, "InputScale", V_SCALE);
        SetIfPresent(app, fileHeader, "ExtinctionCoefficientUsed", V_EXTCOEF);
        SetIfPresent(app, fileHeader, "TargetConcentration", V_TARGET);
        SetIfPresent(app, fileHeader, "RequestedOutputVolume", V_OUTVOL);
        SetIfPresent(app, fileHeader, "A260AcceptanceLogic", V_ACCEPT);
        Qn.Require(col.Distinct().Count() == col.Count, "Duplicate worklist column headings are not supported.");
        SetIfPresent(app, fileHeader, "Site", "User.Site_01");
        SetIfPresent(app, fileHeader, "DiluentIdentity", "User.DiluentIdentity_01");
        SetIfPresent(app, fileHeader, "OperatorID", "User.OperatorID_01");
        SetIfPresent(app, fileHeader, "WorklistVersion", "User.WorklistVersion_01");
        SetIfPresent(app, fileHeader, "OutputWellCapacity(uL)", "User.OutputWellCapacity_01");
        SetIfPresent(app, fileHeader, "TipWorkingCapacity(uL)", "User.TipWorkingCapacity_01");
        // This method's authored configuration uses 150 uL output wells and DDX-96-200F tips.
        // These are explicit limits for this package, not a claim about other Lynx workspaces.
        if (SafeGet(app, "User.OutputWellCapacity_01").Length == 0) app.SetVariable("User.OutputWellCapacity_01", "150");
        if (SafeGet(app, "User.TipWorkingCapacity_01").Length == 0) app.SetVariable("User.TipWorkingCapacity_01", "200");
        ApplyQuantAndReaderConfig(app, fileHeader);   // v0.8.9 — SpectraMax quant plate + reader settings
        ValidateHeaderNumbers(app);
        paramsWritten = true;      // the scalars are now genuinely in MM4, so comparing them is valid

        // ---- 4b. REBUILD THE WORKTABLE TO MATCH THIS WORKLIST ----
        // Count distinct source barcodes first (light pre-pass), rebuild, then re-read the deck so
        // everything below validates against the deck this run will actually use.
        var preOrder = new List<string>();
        foreach (string[] pr in rows)
        {
            string pbc = Cell(pr, iBc);
            if (pbc.Length > 0 && !preOrder.Contains(pbc)) preOrder.Add(pbc);
        }
        string scale = SafeGet(app, V_SCALE); int declaredScale;
        if (scale.Length == 0) { scale = preOrder.Count.ToString(); app.SetVariable(V_SCALE, scale); }
        Qn.Require(int.TryParse(scale, out declaredScale) && declaredScale == preOrder.Count,
            "InputScale must equal the distinct source plate count (" + preOrder.Count + ").");
        platesRequired = Math.Min(preOrder.Count, MAX_SOURCE_PLATES);
        RebuildWorktable(app, platesRequired);
        deck = RefreshDeckFromInstrument(app, wsDir);
        Qn.Require(rebuildErrors.Count == 0, "Worktable removal failed: " + string.Join("; ", rebuildErrors.ToArray()));
        // Validate modeled consumables; physical fill/tip availability still requires the operator check.
        Qn.Require(deck.ContainsKey(HDL_DILUENT) && deck.ContainsKey(HDL_DILTIP + "01"),
            "The Diluent reservoir and Diluent_Tips_01 must be present in the worktable.");

        // ---- 5. MAP + VALIDATE — collect EVERY bad row, do not stop at the first ----
        var firstRowFor = new Dictionary<string, int>();
        var overCapacityPlates = new List<string>();
        for (int r = 0; r < rows.Count; r++)
        {
            string[] row = rows[r];
            int rowNo = r + 1;
            string bc = Cell(row, iBc), sw = Cell(row, iSw);

            if (bc.Length == 0 || sw.Length == 0)
            {
                var issB = new RowIssue { RowNo = rowNo, Kind = "BLANK", What = "Blank plate barcode or well",
                    Column = bc.Length == 0 ? "SourcePlateBarcode" : "SourceWell",
                    Value = "(empty)", Plate = bc, Well = sw,
                    Detail = "Sample row " + rowNo + " has " + (bc.Length == 0 ? "no plate barcode" : "no source well"),
                    Why = "Without both a plate barcode and a well the run cannot tell which physical well to aspirate from.",
                    Fix = "Open the worklist at sample row " + rowNo + " and fill in the missing value, or delete the row if it is a stray blank." };
                issB.Rows.Add(rowNo); issues.Add(issB); continue;
            }

            // v0.8.5 — WELL FORMAT. Added with the stamp VI, because that is what makes an
            // unparseable well matter: a VI addresses channels BY WELL LABEL, so a label that does
            // not resolve has no channel and its 2 uL would simply never be dispensed — silently,
            // with a green run and one well short. Presence and duplication were already checked
            // here; the label itself was not.
            if (ChannelOf(sw) < 1)
            {
                var issW = new RowIssue { RowNo = rowNo, Kind = "WELL", What = "Source well is not a 96-well position",
                    Column = "SourceWell", Value = sw, Plate = bc, Well = sw,
                    Detail = "Sample row " + rowNo + " has SourceWell \"" + sw + "\", which is not between A1 and H12.",
                    Why = "The stamp volume is placed on a channel derived from the well label (A01 is channel 1, "
                        + "A02 is 2, B01 is 13, H12 is 96). A label that does not resolve has no channel, so that "
                        + "well would be skipped with nothing at run time saying so.",
                    Fix = "Open the worklist at sample row " + rowNo + " and correct SourceWell to a position "
                        + "between A1 and H12. FORMAT-002 fixes this workflow at 96-well." };
                issW.Rows.Add(rowNo); issues.Add(issW); continue;
            }

            string qw = Cell(row, iQw), ow = Cell(row, iOw);
            Qn.SafeToken(bc, "Source plate barcode");
            if (Cell(row, iQbc).Length > 0) Qn.SafeToken(Cell(row, iQbc), "Quantification barcode");
            if (Cell(row, iObc).Length > 0) Qn.SafeToken(Cell(row, iObc), "Output barcode");
            if (Qn.Well(qw).Length == 0 || Qn.Well(ow).Length == 0 ||
                Qn.Well(sw) != Qn.Well(qw) || Qn.Well(sw) != Qn.Well(ow))
            {
                var mapped = new RowIssue { RowNo = rowNo, Kind = "WELL", What = "Unsupported well mapping",
                    Plate = bc, Well = sw, Column = "QuantificationWell / OutputWell", Value = qw + " / " + ow,
                    Detail = "Source, quantification and output must name the same valid 96-well position.",
                    Why = "The current VI method does not re-array wells.", Fix = "Use matching A1-H12 positions." };
                mapped.Rows.Add(rowNo); issues.Add(mapped); continue;
            }
            string pairKey = bc + "|" + Qn.Well(sw);
            if (firstRowFor.ContainsKey(pairKey))
            {
                int firstAt = firstRowFor[pairKey];
                var iss = new RowIssue { RowNo = rowNo, Kind = "DUP", What = "Same well listed more than once",
                    Column = "SourceWell", Value = sw, Plate = bc, Well = sw,
                    Detail = "Plate " + bc + ", well " + sw + " appears on sample rows " + firstAt + " and " + rowNo,
                    Why = "Each source well is aspirated once. Two rows pointing at the same well would draw from it twice, "
                        + "so the second transfer would take less material than intended - or none.",
                    Fix = "Open the worklist and look at sample rows " + firstAt + " and " + rowNo + ". Either correct the "
                        + "SourceWell on one of them, or delete whichever row is the accidental copy." };
                iss.Rows.Add(firstAt); iss.Rows.Add(rowNo);
                int pidx = srcOrder.IndexOf(bc);
                if (pidx >= 0 && pidx < MAX_SOURCE_PLATES)
                { iss.Handle = HDL_SOURCE + (pidx + 1).ToString("D2"); iss.Loc = deck.ContainsKey(iss.Handle) ? deck[iss.Handle] : ""; }
                issues.Add(iss); continue;
            }
            firstRowFor[pairKey] = rowNo;

            if (!srcOrder.Contains(bc)) srcOrder.Add(bc);
            int si = srcOrder.IndexOf(bc);
            if (si >= MAX_SOURCE_PLATES)
            {
                // report ONCE per offending plate, not once per row
                if (!overCapacityPlates.Contains(bc))
                {
                    overCapacityPlates.Add(bc);
                    var issO = new RowIssue { RowNo = rowNo, Kind = "OVERCAP", What = "More source plates than the deck holds",
                        Column = "SourcePlateBarcode", Value = bc, Plate = bc,
                        Detail = "Plate " + bc + " is source plate number " + (si + 1) + "; this method runs at most " + MAX_SOURCE_PLATES,
                        Why = "The deck carries " + MAX_SOURCE_PLATES + " source positions, each with its own quantification and output plate. "
                            + "A fifth source plate has nowhere to go.",
                        Fix = "Split the worklist so no single run uses more than " + MAX_SOURCE_PLATES
                            + " source plates, then run them one after another." };
                    issO.Rows.Add(rowNo); issues.Add(issO);
                }
                continue;
            }

            string ix = (si + 1).ToString("D2");
            string sH = HDL_SOURCE + ix, qH = HDL_LUNATIC + ix, oH = HDL_OUTPUT + ix, tH = HDL_SAMPTIP + ix;
            bool deckOk = true;
            foreach (string h in new[] { sH, qH, oH, tH })
                if (!deck.ContainsKey(h))
                {
                    deckOk = false;
                    if (!badLocs.Contains(h))
                    {
                        badLocs.Add(h);
                        var issD = new RowIssue { RowNo = rowNo, Kind = "DECK", What = "Deck position not loaded",
                            Column = "SourcePlateBarcode", Value = bc, Plate = bc, Handle = h,
                            Loc = deck.ContainsKey(h) ? deck[h] : "",
                            Detail = "The worklist needs '" + h + "', which is not on the worktable (first needed at sample row " + rowNo + ")",
                            Why = "The run maps each source plate to a fixed set of deck positions. If one is missing there is nowhere to put the plate.",
                            Fix = "Load '" + h + "' onto the deck, or reduce the worklist to the number of source plates the deck currently carries." };
                        issD.Rows.Add(rowNo); issues.Add(issD);
                    }
                }
            if (!deckOk) continue;

            samples.Add(new Sample {
                RowNo = rowNo,
                Id = iId >= 0 ? Cell(row, iId) : rowNo.ToString(),
                Animal = iAnimal >= 0 ? Cell(row, iAnimal) : "", Tissue = iTissue >= 0 ? Cell(row, iTissue) : "",
                SrcBc = bc, SrcWell = sw, QWell = Cell(row, iQw), OWell = Cell(row, iOw),
                QBcDesig = Cell(row, iQbc), OBcDesig = Cell(row, iObc),
                SrcPlate = sH, SrcLoc = deck[sH], QPlate = qH, QLoc = deck[qH],
                OPlate = oH, OLoc = deck[oH], TipBox = deck.ContainsKey(tH) ? tH : ""
            });
        }

        if (issues.Count > 0)
        {
            string plural = issues.Count == 1 ? "1 problem was" : issues.Count + " problems were";
            Fail(app, "WORKLIST_INVALID",
                plural + " found in the worklist, so the run has been stopped.\n\n" +
                "The report that has just opened lists every one of them by row, with what to correct.\n\n" +
                "Correct the worklist, then start the method again.");
            return;
        }

        // ---- 6. SET THE BRIDGE ----
        int n = samples.Count;
        // n empty elements, and the leading comma makes n+1 fields so element 1 is the first real row.
        string empties = new string(',', n);
        app.SetVariable(V_COUNT, n.ToString());

        // PER-ROW — script bookkeeping. Pick() now emits the leading comma (D-S20-05).
        app.SetVariable(L_SRCBC, Pick(s => s.SrcBc));   app.SetVariable(L_SRCWELL, Pick(s => s.SrcWell));
        app.SetVariable(L_QWELL, Pick(s => s.QWell));   app.SetVariable(L_OWELL, Pick(s => s.OWell));
        app.SetVariable(R_SRCPLATE, Pick(s => s.SrcPlate)); app.SetVariable(R_SRCLOC, Pick(s => s.SrcLoc));
        app.SetVariable(R_QPLATE, Pick(s => s.QPlate)); app.SetVariable(R_QLOC, Pick(s => s.QLoc));
        app.SetVariable(R_OPLATE, Pick(s => s.OPlate)); app.SetVariable(R_OLOC, Pick(s => s.OLoc));
        app.SetVariable(R_TIPBOX, Pick(s => s.TipBox));
        foreach (string v in new[] { L_QBC, L_OBC, L_A260_1, L_A260_2, L_ACCA260, L_A280, L_A230,
                                     L_CALCCONC, L_XFERVOL, L_DILVOL, L_PURITY, L_XFERSTAT })
            app.SetVariable(v, empties);
        // PER-PLATE lists for the deck scan. srcOrder is the distinct source barcodes in first-seen
        // order, which is the order the worklist implies and therefore the order the arm will scan in.
        // MM4's list convention (KB d2-barcode-scanning-reference) is a LEADING DELIMITER so that a
        // loop counter starting at 1 indexes the first real value - these are written in that form so
        // they can be pasted straight in without editing.
        var expBc = new List<string>(); var expSl = new List<string>();
        var expQl = new List<string>(); var expOl = new List<string>();
        // v0.8.4 — the PLATE-MAJOR handle lists the method's loops consume. One element per plate
        // set, in plate-set order, so a base-1 counter reads plate k at index k. These are simply
        // <prefix>_kk: the handle is fixed by the plate SET, not by the scan. What the scan decides
        // is which ROWS belong to which set, and that is the Row_* family above.
        var pSrcPlate = new List<string>(); var pQPlate = new List<string>();
        var pOPlate = new List<string>();   var pTipBox = new List<string>();
        for (int i = 0; i < srcOrder.Count && i < MAX_SOURCE_PLATES; i++)
        {
            string ix = (i + 1).ToString("D2");
            expBc.Add(srcOrder[i]);
            expSl.Add(Loc(HDL_SOURCE + ix));
            expQl.Add(Loc(HDL_LUNATIC + ix));
            expOl.Add(Loc(HDL_OUTPUT + ix));
            pSrcPlate.Add(HDL_SOURCE + ix);
            pQPlate.Add(HDL_LUNATIC + ix);
            pOPlate.Add(HDL_OUTPUT + ix);
            pTipBox.Add(HDL_SAMPTIP + ix);
        }
        app.SetVariable(P_EXPSRCBC, LeadingList(expBc));
        app.SetVariable(P_SRCLOC,   LeadingList(expSl));
        app.SetVariable(P_QLOC,     LeadingList(expQl));
        app.SetVariable(P_OLOC,     LeadingList(expOl));
        app.SetVariable(P_COUNT,    expBc.Count.ToString());
        // v0.8.5 — THE STAMP VI, one per plate, in plate-set order. Rows are grouped by the plate
        // handle that was just assigned, so the grouping cannot drift from the handle lists above.
        // v0.8.6 — TWO lists: 5 uL per active channel on the aspirate, 3 uL on the dispense. Same
        // channel set in both (the wells that hold sample); only the volume differs, which is the
        // whole point of an over-aspirate.
        var stampAsp = new List<string>(); var stampDisp = new List<string>();
        var qdilAsp = new List<string>(); var qdilDisp = new List<string>(); var qmix = new List<string>();
        for (int k = 0; k < srcOrder.Count && k < MAX_SOURCE_PLATES; k++)
        {
            string handle = HDL_SOURCE + (k + 1).ToString("D2");
            var rowsOfPlate = new List<Sample>();
            for (int i = 0; i < samples.Count; i++)
                if (samples[i].SrcPlate == handle) rowsOfPlate.Add(samples[i]);
            stampAsp.Add(StampVI(rowsOfPlate, STAMP_ASPIRATE_UL, true));
            stampDisp.Add(StampVI(rowsOfPlate, STAMP_DISPENSE_UL));
            // v0.8.9 — quant-plate diluent pre-fill and the post-stamp mix, same occupied-well mask
            qdilAsp.Add(StampVI(rowsOfPlate, QDIL_UL, true));
            qdilDisp.Add(StampVI(rowsOfPlate, QDIL_UL));
            qmix.Add(StampVI(rowsOfPlate, QUANT_MIX_UL));
        }
        app.SetVariable(L_QVI_ASP,  LeadingDashList(stampAsp));
        app.SetVariable(L_QVI_DISP, LeadingDashList(stampDisp));
        app.SetVariable(L_QDIL_ASP,  LeadingDashList(qdilAsp));
        app.SetVariable(L_QDIL_DISP, LeadingDashList(qdilDisp));
        app.SetVariable(L_QMIX,      LeadingDashList(qmix));

        app.SetVariable(L_SRCPLATE, LeadingList(pSrcPlate));
        app.SetVariable(L_QPLATE,   LeadingList(pQPlate));
        app.SetVariable(L_OPLATE,   LeadingList(pOPlate));
        app.SetVariable(L_TIPBOX,   LeadingList(pTipBox));

        bridgeWritten = true;      // set LAST, once every list is actually in MM4 - this is what the
                                   // cross-check keys off, so it must not be true a moment early

        SeedRepairLists(app, n, srcOrder.Count);
        // ---- 7. REPORT + CONFIRM ----
        string summary = "Ready to run: " + n + " samples across " + srcOrder.Count + " source plate(s).";
        app.SetVariable(V_STATUS, "OK"); app.SetVariable(V_MSG, summary);
        string reportPath = EmitReport(app, true);
        Qn.Require(reportPath.Length > 0 && File.Exists(reportPath), "The preflight report could not be written.");

        DialogResult proceed = MessageBox.Show(
            summary + "\n\nThe run report has opened in your browser. Check the deck layout and the labware "
            + "checklist against the deck, then:\n\n     OK = start the run          Cancel = stop",
            "QuantNorm - confirm the deck is ready", MessageBoxButtons.OKCancel, MessageBoxIcon.Question);

        app.SetVariable(V_USERRESP, proceed == DialogResult.OK ? "OK" : "CANCEL");
        if (proceed != DialogResult.OK)
        {
            Fail(app, "CANCELLED",
                "You selected Cancel, so the run has been stopped.\n\nNothing has been moved and no labware has been used. Start the method again when you are ready.");
            return;
        }

        app.OutputMsg("[QuantNorm ingestion " + SCRIPT_VERSION + "] " + summary
            + "  Report: " + reportPath
            + "\n  TransferVolume/DiluentVolume left EMPTY (computed after the Lunatic read).", false);
    }

    // ---------------- failure path: sets vars, ALWAYS writes + opens the report ----------------
    private void Fail(IMMApp app, string code, string operatorMsg)
    {
        failCode = code; failMsg = operatorMsg;
        app.SetVariable(V_ABORT, "True"); app.SetVariable(V_STATUS, code); app.SetVariable(V_MSG, operatorMsg);
        // ORDER CHANGED IN v0.7.7, deliberately: the alert now runs BEFORE the report is written, so
        // that what it did can be recorded IN the report (Jim: log it in the dev side of the HTML).
        // Side effect, and an improvement: the operator hears the alert first and the report opens
        // immediately after, rather than the sound trailing a report that is already on screen.
        PlayAlert(app, code);
        string path = EmitReport(app, false);
        app.OutputMsg("[QuantNorm ingestion " + SCRIPT_VERSION + "] ABORT (" + code + "): "
            + operatorMsg.Replace("\n", " ") + "  Report: " + path
            + "  Alert: " + alertLog, true);
    }

    // Does this abort deserve an audible alert? A fault does; the operator's own cancel does not.
    // Single decision point so the policy is one line to read and one line to change.
    private static bool ShouldSound(string code)
    {
        if (!ALERT_SOUND) return false;
        foreach (string s in SILENT_CODES)
            if (string.Equals(code, s, StringComparison.OrdinalIgnoreCase)) return false;
        return true;
    }

    // Plays the pre-rendered alert. EVERY failure here is swallowed on purpose: no missing file,
    // locked device, absent sound card or unreadable WAV may ever turn into a failed method. The
    // worst case is silence, and it is noted in the run log.
    private void PlayAlert(IMMApp app, string code)
    {
        if (!ShouldSound(code)) { alertLog = "no alert for " + code + " (operator's own choice, not a fault)"; return; }
        string wav = "";
        var sw = System.Diagnostics.Stopwatch.StartNew();
        try
        {
            if (wsRoot.Length == 0) { alertLog = "workspace path unknown - no alert attempted"; return; }
            wav = Path.Combine(Path.Combine(wsRoot, ALERT_SOUND_DIR), ALERT_SOUND_FILE);
            if (!File.Exists(wav))
            {
                alertLog = "FILE NOT FOUND: " + wav;
                try { app.OutputMsg("[QuantNorm ingestion " + SCRIPT_VERSION + "] alert sound not found: " + wav, false); }
                catch (Exception) { }
                return;
            }
            using (System.Media.SoundPlayer sp = new System.Media.SoundPlayer(wav))
            {
                sp.Load();          // throws here rather than mid-play if the file is not usable PCM
                sp.PlaySync();      // finish before the method advances to Show Message
            }
            sw.Stop();
            // The ELAPSED TIME is the evidence. PlaySync blocks for the length of the clip, so a value
            // near the clip length means the audio stack accepted and played it; a few milliseconds
            // means it returned without playing. NOTE what this can and cannot tell you: it proves the
            // clip was played, NOT that it was audible - on 2026-07-28 all three "silent" runs blocked
            // the full 2.7 s and the real cause was the machine volume being turned down.
            alertLog = "played " + Path.GetFileName(wav) + " - blocked " + sw.ElapsedMilliseconds
                     + " ms (a value near the clip length means it reached the audio device; it does "
                     + "NOT prove it was audible - check the volume if nothing was heard)";
        }
        catch (Exception ex)
        {
            alertLog = "FAILED after " + sw.ElapsedMilliseconds + " ms: " + ex.Message;
            try { app.OutputMsg("[QuantNorm ingestion " + SCRIPT_VERSION + "] alert sound failed ("
                + wav + "): " + ex.Message + " - continuing, this does not affect the run.", false); }
            catch (Exception) { }
        }
    }

    private string EmitReport(IMMApp app, bool ok)
    {
        string path = "";
        try
        {
            path = WriteReport(app, ok);
            app.SetVariable(V_REPORT, path);
            try { Process.Start(new ProcessStartInfo(path) { UseShellExecute = true }); } catch (Exception) { }
        }
        catch (Exception ex) { app.OutputMsg("[QuantNorm ingestion " + SCRIPT_VERSION + "] report failed: " + ex.Message, true); }
        return path;
    }

    // ---------------- helpers ----------------
    // v0.8.4 — LEADING COMMA, per D-S20-05. Every list this script publishes now starts with the
    // delimiter, so a base-1 loop counter (which matches the COUNT of labware) indexes the first real
    // element directly and no -1 correction is needed anywhere. Previously this returned a bare
    // "a,b,c" while the per-plate lists used LeadingList() — two conventions in one script, which is
    // what let a plate counter silently read the wrong element.
    private string Pick(Func<Sample, string> f) { return "," + string.Join(",", samples.Select(f)); }

    // MM4 list form with a LEADING delimiter, per the KB's d2-barcode-scanning convention: a Begin Loop
    // that starts its counter at 1 indexes the first real value only if index 0 is empty. Writing the
    // list this way means what the report shows can be pasted into MM4 verbatim.
    // =====================================================================================
    //  THE STAMP VI  (v0.8.5) — the worklist decides which channels move, not a fixed 96.
    // =====================================================================================
    // WHY THIS EXISTS. The Quant stamp ran with all 96 channels enabled at 2 uL, which Jim carried
    // DELIBERATELY as a temporary parameter: "the 96 channels are a temp parameter until we get the
    // worklist to VI wired and working. that will determine full/partial transfers." This is that
    // wiring. On a partial plate — the live 3-plate run had 60, 96 and 12 rows — a fixed 96 dips tips
    // into empty source wells and stamps air into the matching quantification wells. The worklist
    // already knows exactly which wells hold sample, so it can say so.
    //
    // ONE VI PER PLATE. A VI addresses the 96 channels of ONE plate, and the method's stamp loop runs
    // once per plate, so the natural unit is per plate — the same shape as everything else the method
    // consumes.
    //
    // 2 uL IS FIXED BY THE SPEC, NOT CHOSEN HERE. QUANT-002: "stamp 2 uL from each well of the Source
    // Plate to the corresponding well of the Quantification Plate." No header field carries a stamp
    // volume (DATA-002 lists the run-metadata block and it is not among them), so there is nothing to
    // read and nothing to default — it is a constant, and the report prints it as one.
    //
    // ⚠ STRUCK v0.8.6 — this paragraph is WRONG and is kept struck rather than deleted so the
    // reasoning that changed is visible:
    //   ~~"THE SAME STRING SERVES ASPIRATE AND DISPENSE. 2 uL comes out of the source well and 2 uL
    //     goes into the quantification well; there is no overage or carry factor in this workflow."~~
    // There IS an overage. Cory: aspirate 5 uL, dispense 3 uL, so no air is transferred into the
    // Lunatic read well. That makes the stamp a PARTIAL TRANSFER — which is precisely the case
    // D-S20-08 says a dispense VI exists for — so it takes TWO strings, not one.
    //
    // ⚠ 2 uL WAS FIXED BY QUANT-002 AND 3 uL IS NOT. The spec SHALLs "stamp 2 uL from each well of the
    // Source Plate to the corresponding well of the Quantification Plate", and Appendix A describes the
    // Lunatic as reading "using 2 uL sample volume". Delivering 3 uL is a DEVIATION and is recorded as
    // one — it is either documented as such or confirmed with the customer. That decision is Jim's, and this
    // script does not pretend the spec says something it does not.
    // v0.8.9 — SpectraMax variant: the stamp goes INTO a pre-filled well, so aspirate and dispense are
    // the same sample volume, exact (no over-stroke into an optical well). Run-configurable through
    // the worklist header (QuantSampleVolume(uL) / QuantDiluentVolume(uL)); these are the defaults.
    private const double QUANT_SAMPLE_DEFAULT_UL  = 5.0;
    private const double QUANT_DILUENT_DEFAULT_UL = 45.0;
    private const double QUANT_MIX_UL             = 20.0;   // mix stroke, below the 50 uL well content
    private const double QUANT_WELL_MAX_UL        = 150.0;  // half-area UV plate working volume ceiling
    private static double STAMP_ASPIRATE_UL = QUANT_SAMPLE_DEFAULT_UL;
    private static double STAMP_DISPENSE_UL = QUANT_SAMPLE_DEFAULT_UL;
    private static double QDIL_UL           = QUANT_DILUENT_DEFAULT_UL;
    const string L_QDIL_ASP  = "User.QuantDiluent_Aspirate_VI_List_01";
    const string L_QDIL_DISP = "User.QuantDiluent_Dispense_VI_List_01";
    const string L_QMIX      = "User.QuantMix_VI_List_01";

    // ---- AIR GAPS CARRIED IN THE VI, AND WHY THEY HAVE TO BE ----------------------------------
    // Jim, 2026-07-31, and this is the rule that decides it: "the vi will override all asp/disp
    // parameters for fields that are available in the vi deconvolution."
    // A VI field is <Volume>;<LeadingGap>;<TrailingGap> and OMITTED sub-fields default to 0
    // (mm4-data-formats-reference.md:145-152). Both gaps are therefore "available in the
    // deconvolution", so a BARE volume does not leave the command grid alone — it overrides the grid
    // with ZERO. The Quant aspirate carries a 5 uL leading air gap on all 96 channels in the grid,
    // and Jim keeps it deliberately: "it normalizes the interior pipette tip pressure before
    // aspiration increasing small volume aspiration accuracy." Emitting a bare 5 would have silently
    // removed it — on the one command Cory told us must not push air into the read well.
    // So the aspirate VI carries the gap explicitly and reproduces the grid exactly: 5;5;0.
    // The DISPENSE carries no gap: its command has no leadingAirGap parameter at all, and there is
    // nothing to preserve, so it stays a bare volume like every other dispense VI on this build.
    private const double STAMP_ASP_LEAD_GAP_UL  = 5.0;
    private const double STAMP_ASP_TRAIL_GAP_UL = 0.0;

    // Row-major, placed BY WELL LABEL: channel = 12*row + col + 1, so A01=1, A02=2, B01=13, H12=96.
    // This is KB canon and it is a CORRECTION — mm4-data-formats-reference.md said column-major until
    // v1.4.0, checked there against four independent sources including two production scripts. Getting
    // it wrong transposes every volume on the plate, so the channel is always derived from the LABEL
    // and never from the worklist's row order, which may be anything.
    private static int ChannelOf(string well)
    { return Qn.Channel(well); }
    private const int VI_ROWS = 8, VI_COLS = 12;

    // string[97]: index 0 is the header, 1..96 are the per-well data fields. A well with no sample is
    // left EMPTY, not "0" — that is what DD's own production precedent emits
    // (IFF_Norming_Demo/Scripts/Norm_DaughterPlate.cs clears the array and joins, so unfilled entries
    // render as empty between the commas) and an empty field means that channel does nothing.
    // A bare volume is equivalent to "<vol>;0;0" — the leading/trailing air-gap sub-fields default to
    // 0 [Jim-verified 2026-06-05, mm4-data-formats-reference.md:152] — so no air gaps are written
    // unless they are non-zero, and none are non-zero here.
    private static string StampVI(List<Sample> plateRows, double volUl)
    { return StampVI(plateRows, volUl, false); }

    // withGaps=true emits "<vol>;<lead>;<trail>" instead of a bare volume. Used for the ASPIRATE only.
    private static string StampVI(List<Sample> plateRows, double volUl, bool withGaps)
    {
        var g = new string[VI_ROWS * VI_COLS + 1];
        g[0] = "VI;" + VI_COLS + ";" + VI_ROWS;
        var ci = System.Globalization.CultureInfo.InvariantCulture;
        string vol = volUl.ToString("0.##", ci);
        if (withGaps)
            vol = vol + ";" + STAMP_ASP_LEAD_GAP_UL.ToString("0.##", ci)
                      + ";" + STAMP_ASP_TRAIL_GAP_UL.ToString("0.##", ci);
        for (int i = 0; i < plateRows.Count; i++)
        {
            int ch = ChannelOf(plateRows[i].SrcWell);
            if (ch >= 1) g[ch] = vol;      // < 1 cannot reach here: the row check above stops the run
        }
        return string.Join(",", g);
    }

    // A VI string is itself COMMA-delimited, so it can never be an element of a comma-separated list.
    // DD's production precedent uses a DASH between per-plate VI strings, and the leading dash is the
    // same convention as every other list here (D-S20-05): a base-1 counter reads plate k at index k
    // with no adjustment. In the method: ListParser on this variable with delimiter "-".
    private static string LeadingDashList(List<string> items)
    { return items.Count == 0 ? "" : "-" + string.Join("-", items.ToArray()); }

    private static string LeadingList(List<string> items)
    { return items.Count == 0 ? "" : "," + string.Join(",", items.ToArray()); }

    // The inverse of the leading-comma convention: take a published list back to its real elements.
    // ⚠ Removes ONLY the phantom at index 0. An empty element anywhere else is MEANINGFUL — it is a
    // row or a position that produced no value — and dropping those was a real bug in an earlier
    // sibling script (a scan that read nothing collapsed the list and the operator was pointed at the
    // wrong problem).
    private static List<string> DropLeadingPhantom(string raw)
    {
        var outp = new List<string>();
        if (raw == null || raw.Length == 0) return outp;
        string[] parts = raw.Split(',');
        int start = (parts.Length > 0 && parts[0].Length == 0) ? 1 : 0;
        for (int i = start; i < parts.Length; i++) outp.Add(parts[i]);
        return outp;
    }

    static void EnsureVariable(IMMApp app, string name, string def)
    { try { app.GetVariableValue(name); } catch (Exception) { app.SetVariable(name, def); } }

    static string SafeGet(IMMApp app, string name)
    { try { return app.GetVariableValue(name); } catch (Exception) { return ""; } }

    // v0.8.0 — the dialog now also collects the two barcode MODES, because the operator is the only
    // one who knows what is physically on the plates in front of them. Returns the worklist path, or
    // null on Cancel; the two modes come back through out-params.
    //
    // Index -> value is FIXED and must stay aligned with MODE_OPTION_TEXT below:
    //   0 -> ""          not barcoded
    //   1 -> "CAPTURE"   barcoded, assigned as loaded
    //   2 -> "WORKLIST"  barcoded and designated by the worklist
    static readonly string[] MODE_VALUES = new string[] { MODE_NONE, MODE_CAPTURE, MODE_WORKLIST };
    static readonly string[] MODE_OPTION_TEXT = new string[] {
        "Not barcoded  -  use the plate in the same deck row, generate a tracking ID",
        "Barcoded  -  whichever plate is loaded in the row; scan it and record the barcode",
        "Barcoded  -  the worklist says which plate; scan and verify (may sit in another row)"
    };

    static string ChooseWorklistDialog(string workspaceDir, out string quantMode, out string outputMode)
    {
        // Defaults if the dialog is cancelled or closed: BOTH OFF. A cancelled dialog aborts the run
        // anyway, but leaving them off means a half-configured run can never scan against stale state.
        quantMode = MODE_NONE; outputMode = MODE_NONE;

        string selected = null;
        var full = new List<string>();
        Form f = new Form();
        f.Text = "Choose Worklist - RNA Quantification / Normalization";
        f.Size = new Size(700, 320); f.FormBorderStyle = FormBorderStyle.FixedDialog;
        f.StartPosition = FormStartPosition.CenterScreen; f.MaximizeBox = false; f.MinimizeBox = false;

        Label info = new Label();
        info.Text = "Choose the worklist (CSV) for this RNA quantification/normalization run.\n" +
                    "Only worklists inside the current workspace (and its subfolders) are listed.";
        info.Location = new Point(12, 10); info.Size = new Size(660, 34); f.Controls.Add(info);

        Label lroot = new Label();
        lroot.Text = "Workspace: " + workspaceDir;
        lroot.Location = new Point(12, 48); lroot.Size = new Size(660, 20); f.Controls.Add(lroot);

        Label lw = new Label(); lw.Text = "Worklist:"; lw.Location = new Point(12, 80); lw.Size = new Size(100, 20); f.Controls.Add(lw);
        ComboBox cmb = new ComboBox(); cmb.DropDownStyle = ComboBoxStyle.DropDownList;
        cmb.Location = new Point(118, 78); cmb.Size = new Size(552, 24); f.Controls.Add(cmb);
        try {
            if (Directory.Exists(workspaceDir))
                foreach (string pth in Directory.GetFiles(workspaceDir, "*.csv", SearchOption.AllDirectories))
                { full.Add(pth); cmb.Items.Add(pth.Substring(workspaceDir.Length).TrimStart('\\', '/')); }
        } catch (Exception) { }
        if (cmb.Items.Count > 0) cmb.SelectedIndex = 0;

        Label lhdr = new Label();
        lhdr.Text = "Plate barcodes for this run - set these to match what is actually on the plates:";
        lhdr.Location = new Point(12, 112); lhdr.Size = new Size(660, 20); f.Controls.Add(lhdr);

        Label lq = new Label(); lq.Text = "Lunatic plates:"; lq.Location = new Point(12, 142); lq.Size = new Size(100, 20); f.Controls.Add(lq);
        ComboBox cq = new ComboBox(); cq.DropDownStyle = ComboBoxStyle.DropDownList;
        cq.Location = new Point(118, 140); cq.Size = new Size(552, 24); f.Controls.Add(cq);
        foreach (string t in MODE_OPTION_TEXT) cq.Items.Add(t);
        cq.SelectedIndex = 0;                      // Lunatic plates are not barcoded (Jim, S18)

        Label lo = new Label(); lo.Text = "Output plates:"; lo.Location = new Point(12, 176); lo.Size = new Size(100, 20); f.Controls.Add(lo);
        ComboBox co = new ComboBox(); co.DropDownStyle = ComboBoxStyle.DropDownList;
        co.Location = new Point(118, 174); co.Size = new Size(552, 24); f.Controls.Add(co);
        foreach (string t in MODE_OPTION_TEXT) co.Items.Add(t);
        co.SelectedIndex = 1;                      // output scan ON by default (Jim, S18)
        if (!HAS_DECK_SCANNER) { lq.Text = "Quant plates:"; cq.SelectedIndex = 0; co.SelectedIndex = 0; cq.Enabled = false; co.Enabled = false; }

        Label lnote = new Label();
        lnote.Text = HAS_DECK_SCANNER
            ? "A plate that is not barcoded is never scanned. The run uses the plate in the same deck row as\n" +
              "its source plate, and records a generated tracking ID in the completed worklist instead."
            : "This system has no deck barcode reader. You will TYPE each source plate barcode when prompted.\n" +
              "Quant and output plates use the plate in the same deck row and get a generated tracking ID.";
        lnote.Location = new Point(12, 208); lnote.Size = new Size(660, 36); f.Controls.Add(lnote);

        Button ok = new Button(); ok.Text = "OK"; ok.Location = new Point(496, 250); ok.Size = new Size(84, 28); ok.DialogResult = DialogResult.OK; f.Controls.Add(ok);
        Button cancel = new Button(); cancel.Text = "Cancel"; cancel.Location = new Point(586, 250); cancel.Size = new Size(84, 28); cancel.DialogResult = DialogResult.Cancel; f.Controls.Add(cancel);
        f.AcceptButton = ok; f.CancelButton = cancel;

        if (f.ShowDialog() == DialogResult.OK && cmb.SelectedIndex >= 0 && cmb.SelectedIndex < full.Count)
        {
            selected = full[cmb.SelectedIndex];
            if (cq.SelectedIndex >= 0 && cq.SelectedIndex < MODE_VALUES.Length) quantMode  = MODE_VALUES[cq.SelectedIndex];
            if (co.SelectedIndex >= 0 && co.SelectedIndex < MODE_VALUES.Length) outputMode = MODE_VALUES[co.SelectedIndex];
        }
        f.Dispose();
        return selected;
    }

    // Parses ALL TEN fields of User.OutputWorktable_01:
    //   Location, Stack index, Plate name, Plate barcode, Labware, X, Y, Z, Worktable, Device
    // v0.2.x used only [0] and [2] and invented the geometry; the real coordinates were always here.
    private Dictionary<string, string> ParseWorktable(string layout)
    {
        var map = new Dictionary<string, string>();
        deckPos.Clear();
        if (string.IsNullOrEmpty(layout)) return map;
        foreach (string row in layout.Split('|'))
        {
            string[] f = row.Split(',');
            if (f.Length < 10) continue;                       // 4 left + labware + 5 right
            if (f[0].Trim().Equals("Location", StringComparison.OrdinalIgnoreCase)) continue;
            // Fixed at BOTH ENDS. The labware name may itself contain commas
            // ("Eppendorf twin.tec PCR Plate 96, skirted, 150 uL"), so it is whatever lies between
            // the 4 leading fields and the 5 trailing ones, rejoined with the commas put back.
            int n = f.Length;
            var d = new DeckPos { Occupied = true };
            d.Loc     = f[0].Trim();
            d.Plate   = f[2].Trim();
            d.Barcode = f[3].Trim();
            d.Labware = string.Join(",", f.Skip(4).Take(n - 9).ToArray()).Trim();
            d.X = Num(f[n - 5]); d.Y = Num(f[n - 4]); d.Z = Num(f[n - 3]);
            d.Worktable = f[n - 2].Trim();
            d.Device    = f[n - 1].Trim();
            if (d.Worktable.Length > 0) wtName = d.Worktable;
            if (d.Device.Length > 0) wtDevice = d.Device;
            deckPos.Add(d);
            if (d.Plate.Length > 0 && !map.ContainsKey(d.Plate)) map[d.Plate] = d.Loc;
        }
        return map;
    }

    static double Num(string s)
    { double v; return double.TryParse((s ?? "").Trim(), System.Globalization.NumberStyles.Any,
        System.Globalization.CultureInfo.InvariantCulture, out v) ? v : 0; }

    // The runtime variable lists only OCCUPIED positions. The machine's own worktable config lists
    // every position with its real coordinates. Path is derived from the Device/Worktable fields
    // above - never hardcoded - so this follows the machine rather than an assumption about it.
    private void LoadEmptyPositions(string workspaceDir)
    {
        try
        {
            string cfgDir = Path.Combine(workspaceDir, "Configuration");
            if (!Directory.Exists(cfgDir)) return;
            // Prefer the file matching this worktable, but never depend on parsed values to build a
            // filename - if the preferred name is absent, take whatever *.Worktable.config is there.
            string preferred = Path.Combine(cfgDir, wtDevice + "." + wtName + ".Worktable.config");
            string path = File.Exists(preferred) ? preferred : null;
            if (path == null)
            {
                string[] cands = Directory.GetFiles(cfgDir, "*.Worktable.config");
                foreach (string cnd in cands)
                    if (Path.GetFileName(cnd).IndexOf(".ToolFilter.", StringComparison.OrdinalIgnoreCase) < 0)
                    { path = cnd; break; }
            }
            if (path == null) return;
            string raw = File.ReadAllText(path);
            var have = new HashSet<string>(deckPos.Select(d => d.Loc));
            foreach (Match m in Regex.Matches(raw, @"<MMLocation>(.*?)</MMLocation>", RegexOptions.Singleline))
            {
                string b = m.Groups[1].Value;
                string nm = One(b, "Name");
                if (!nm.StartsWith("Loc_") || have.Contains(nm)) continue;
                deckPos.Add(new DeckPos { Loc = nm, Occupied = false,
                    X = Num(One(b, "XPos")), Y = Num(One(b, "YPos")), Z = Num(One(b, "ZPos")) });
            }
        }
        catch (Exception) { }
    }

    // Labware footprints, well grids and MM4's OWN colours (Color/WellColor are .NET ARGB ints).
    // TWO SOURCES, because MM4 itself uses two:
    //   1. <workspace>\User.Labware.config              - plates, per workspace
    //   2. %ProgramData%\MethodManager4\Labware\*.config - tips and tipboxes, MACHINE-WIDE
    // There is exactly ONE active ProgramData\Labware set on a host; it is NOT per workspace.
    // (KB: mm4-install-topology-reference.md - "Machine-wide (all-users): Labware defs"; and
    //  mm4-first-install-sop-reference.md Part 4 - DDI/DDX Tip/TipboxType files live there.)
    // v0.3.0 read only source 1, so DDX-96-200F was never found and the tip boxes rendered with a
    // made-up colour instead of MM4's own #6666FF body / #B0E0E6 wells.
    private void LoadLabware(string workspaceDir)
    {
        LoadLabwareFile(Path.Combine(workspaceDir, "User.Labware.config"));
        try
        {
            string pd = Path.Combine(Path.Combine(
                Environment.GetFolderPath(Environment.SpecialFolder.CommonApplicationData),
                "MethodManager4"), "Labware");
            if (Directory.Exists(pd))
                foreach (string cfg in Directory.GetFiles(pd, "*.config"))
                    LoadLabwareFile(cfg);
        }
        catch (Exception) { }
    }

    private void LoadLabwareFile(string path)
    {
        try
        {
            if (!File.Exists(path)) return;
            string raw = File.ReadAllText(path);
            foreach (Match m in Regex.Matches(raw, @"<MMLabware>(.*?)</MMLabware>", RegexOptions.Singleline))
            {
                string b = m.Groups[1].Value;
                var d = new LabwareDef();
                d.Name = One(b, "Name");
                if (d.Name.Length == 0) continue;
                double L = Num(One(b, "Length")), W = Num(One(b, "Width"));
                if (L > 0) d.Length = L; if (W > 0) d.Width = W;
                d.Rows = (int)Num(One(b, "Rows")); d.Cols = (int)Num(One(b, "Cols"));
                d.Body = Argb(One(b, "Color")); d.Well = Argb(One(b, "WellColor"));
                d.A1Col = Num(One(b, "A01CenterColOffset")); d.A1Row = Num(One(b, "A01CenterRowOffset"));
                d.ColSpacing = Num(One(b, "WellColSpacing")); d.RowSpacing = Num(One(b, "WellRowSpacing"));
                d.WellL = Num(One(b, "WellLength")); d.WellW = Num(One(b, "WellWidth"));
                d.Circular = !One(b, "WellIsCircular").Equals("false", StringComparison.OrdinalIgnoreCase);
                labware[d.Name] = d;
            }
        }
        catch (Exception) { }
    }

    static string One(string block, string tag)
    { Match m = Regex.Match(block, "<" + tag + ">([^<]*)</" + tag + ">"); return m.Success ? m.Groups[1].Value.Trim() : ""; }

    // MM4 stores a colour EITHER as a .NET ARGB integer (e.g. -4144960) OR as a .NET named colour
    // (e.g. "AliceBlue") - both forms appear in the live config files. Handle both; 0 means unset.
    static string Argb(string raw)
    {
        string t = (raw ?? "").Trim();
        if (t.Length == 0) return "";
        long n;
        if (long.TryParse(t, System.Globalization.NumberStyles.Any,
                          System.Globalization.CultureInfo.InvariantCulture, out n))
        {
            if (n == 0) return "";
            long u = n & 0xFFFFFFFFL;
            return "#" + ((u >> 16) & 255).ToString("X2") + ((u >> 8) & 255).ToString("X2") + (u & 255).ToString("X2");
        }
        try
        {
            Color c = Color.FromName(t);
            if (c.IsKnownColor || c.A != 0)
                return "#" + c.R.ToString("X2") + c.G.ToString("X2") + c.B.ToString("X2");
        }
        catch (Exception) { }
        return "";
    }

    static string NormalizeCol(string s)
    { return s == null ? "" : s.Trim().Replace("µ", "u").Replace("μ", "u").Replace(" ", "").ToLowerInvariant(); }
    static int Col(List<string> header, string name)
    { string w = NormalizeCol(name); for (int i = 0; i < header.Count; i++) if (header[i] == w) return i; return -1; }
    static bool IsColumnHeader(string[] cells)
    {
        if (cells.Length < 2) return false;
        foreach (string c in cells) { string nc = NormalizeCol(c); if (nc == "sourceplatebarcode" || nc == "sourcewell") return true; }
        return false;
    }
    static string Cell(string[] row, int i) { return (i >= 0 && i < row.Length) ? row[i].Trim() : ""; }
    static void SetIfPresent(IMMApp app, Dictionary<string, string> h, string key, string varName)
    { string k = NormalizeCol(key); if (h.ContainsKey(k)) app.SetVariable(varName, h[k]); }
    static string Hdr(Dictionary<string, string> h, string key) { string k = NormalizeCol(key); return h.ContainsKey(k) ? h[k] : ""; }
    static string E(string s)
    { return (s ?? "").Replace("&", "&amp;").Replace("<", "&lt;").Replace(">", "&gt;"); }

    // Loc_NN -> (col,row). Verified against this machine's Lynx.Left.Worktable.config:
    // 30 locations, 5 cols x 6 rows, all placed; NN = (col-1)*6 + row.
    static bool LocRC(string loc, out int colNo, out int rowNo)
    {
        colNo = 0; rowNo = 0;
        if (loc == null) return false;
        string digits = new string(loc.Where(char.IsDigit).ToArray());
        int nn; if (!int.TryParse(digits, out nn) || nn < 1) return false;
        colNo = (nn - 1) / DECK_ROWS + 1; rowNo = (nn - 1) % DECK_ROWS + 1; return true;
    }

    // v0.8.3 — WHAT TO PUT ON THE PLATES, and which plate goes with which.
    //
    // WHY THIS EXISTS. Jim, S18: "i don't know what barcodes to use when testing other than the source
    // barcode so i just make it up." He was right to raise it, and "make it up" is CORRECT in some
    // modes and WRONG in others — with nothing on screen to tell him which. Barcodes are matched
    // EXACT, including case (D-S18-16), so in a worklist-designated mode a typo or a case difference
    // fails the run, and the operator previously had no way to know the required string. A mode that
    // cannot be operated is not a feature.
    //
    // IT STATES THE PAIRING, NOT THE ROWS (D-S18-12, Jim: "keep the source placement freedom").
    // Ingestion runs BEFORE the source scan, so which deck row each plate set will occupy is genuinely
    // unknown here — and D-S16-10 deliberately lets the operator load source plates in any order.
    // Prescribing rows would repeal that as a side effect of a reporting choice. So this says which
    // three plates belong together and leaves the row to the operator.
    private void EmitBarcodeLabelGuidance(StringBuilder h)
    {
        if (srcOrder.Count == 0) return;

        h.Append("<h2>Plate barcodes for this run</h2>\n");
        h.Append("<p>Each row below is one plate <b>set</b>. Load a set's three plates in the <b>same deck row</b> "
               + "&mdash; which row is your choice, and the scan works out where you put them.</p>\n");

        h.Append("<table><tr><th>Set</th><th>Source plate<br><span class='sub'>scanned, must match</span></th>"
               + "<th>Quantification (Lunatic)</th><th>Output plate</th></tr>\n");
        for (int i = 0; i < srcOrder.Count; i++)
        {
            string sbc = srcOrder[i];
            string qbc = "", obc = "";
            foreach (Sample s in samples)
                if (s.SrcBc == sbc)
                { if (qbc.Length == 0) qbc = s.QBcDesig; if (obc.Length == 0) obc = s.OBcDesig; }

            h.Append("<tr><td>").Append(i + 1).Append("</td><td class='mono'>").Append(E(sbc)).Append("</td>");
            h.Append("<td>").Append(LabelCell(quantMode, qbc)).Append("</td>");
            h.Append("<td>").Append(LabelCell(outputMode, obc)).Append("</td></tr>\n");
        }
        h.Append("</table>\n");

        h.Append("<p class='sub'><b>Barcodes are compared exactly, including upper and lower case.</b> "
               + "Where a barcode is shown above it must be entered or applied character-for-character. "
               + "Where this run does not compare a barcode, that is stated in the cell and anything you use "
               + "is accepted &mdash; but it is still recorded in the completed worklist.</p>\n");
    }

    // One cell of the guidance table. The wording differs per mode because what the operator must DO
    // differs per mode, and the difference is the whole point of the table.
    private string LabelCell(string mode, string designated)
    {
        if (mode == MODE_WORKLIST)
        {
            if (designated.Length > 0)
                return "<span class='mono'><b>" + E(designated) + "</b></span><br><span class='sub'>required &mdash; "
                     + "this exact string, exact case</span>";
            return "<span class='sub'><b>the worklist designates these, but this row names none.</b> "
                 + "The run will stop at the barcode check.</span>";
        }
        if (mode == MODE_CAPTURE)
            return "<span class='sub'>barcoded, but <b>not</b> specified by the worklist &mdash; whatever is on the "
                 + "plate is recorded. Any value is accepted.</span>";
        return "<span class='sub'>not barcoded &mdash; <b>no label needed</b>. A tracking ID is generated and written "
             + "into the completed worklist.</span>";
    }

    static string CategoryOf(string plate)
    {
        if (plate.StartsWith(HDL_SAMPTIP) || plate.StartsWith(HDL_DILTIP)) return "tips";
        if (plate.StartsWith(HDL_SOURCE)) return "source";
        if (plate.StartsWith(HDL_LUNATIC)) return "quant";
        if (plate.StartsWith(HDL_OUTPUT)) return "output";
        if (plate.StartsWith(HDL_DILUENT)) return "diluent";
        return "other";
    }
    static string ColourOf(string cat)
    {
        switch (cat)
        {
            case "tips":    return "#7b5ea7";
            case "source":  return "#67c46c";
            case "quant":   return "#4a9bd1";
            case "output":  return "#e8a838";
            case "diluent": return "#5bc0be";
            default:        return "#b0b0b0";
        }
    }
    static string LabelOf(string cat)
    {
        switch (cat)
        {
            case "tips":    return "Tips";
            case "source":  return "Source";
            case "quant":   return "Quantification";
            case "output":  return "Output";
            case "diluent": return "Diluent";
            default:        return "Other";
        }
    }

    // =========================================================================
    //  REPORT
    // =========================================================================
    private string WriteReport(IMMApp app, bool ok)
    {
        // DEFENCE IN DEPTH. Execute no longer assigns a null wlFile (that was the actual cause of the
        // 08:12 crash), but the report is the one artifact that must survive EVERY failure path, so it
        // does not get to depend on a caller behaving. wlFile is read as .Length in four places below
        // and in EmitValidation / EmitWorklistAsRead; normalising once here covers all of them.
        // Proven by RegressCancel.exe, which injects wlFile = null directly and expects a report anyway.
        if (wlFile == null) wlFile = "";
        var h = new StringBuilder();
        string title = "QuantNorm run report " + runId;
        h.Append("<!doctype html><html><head><meta charset='utf-8'><title>").Append(E(title)).Append("</title>\n<style>\n");
        h.Append("*{box-sizing:border-box;margin:0;padding:0}\n");
        h.Append("body{font-family:Segoe UI,Tahoma,sans-serif;font-size:13px;color:#222;background:#f5f5f5;padding:20px}\n");
        h.Append(".container{max-width:1400px;margin:0 auto;background:#fff;border:1px solid #ccc;border-radius:4px;padding:24px}\n");
        h.Append("h1{font-size:21px;margin-bottom:2px}\n");
        h.Append(".sub{color:#666;font-size:12px;margin-bottom:16px}\n");
        h.Append("h2{font-size:16px;margin:22px 0 8px;padding-bottom:4px;border-bottom:2px solid #0078d4;color:#0078d4}\n");
        h.Append("h3{font-size:14px;margin:14px 0 6px;color:#444}\n");
        h.Append("table{border-collapse:collapse;width:100%;margin-bottom:12px}\n");
        h.Append("th,td{border:1px solid #ccc;padding:4px 8px;text-align:left;font-size:12px}\n");
        h.Append("th{background:#e8e8e8;font-weight:600}\n");
        h.Append(".mono{font-family:Consolas,Courier New,monospace;font-size:11px}\n");
        h.Append(".kv{width:auto}.kv th{width:210px;text-align:right;background:#e8f0fe}\n");
        h.Append(".banner-ok{background:#2e7d32;color:#fff;padding:14px 18px;border-radius:4px;margin-bottom:6px;font-size:17px;font-weight:bold}\n");
        h.Append(".banner-stop{background:#c62828;color:#fff;padding:14px 18px;border-radius:4px;margin-bottom:6px;font-size:17px;font-weight:bold}\n");
        h.Append(".banner-msg{background:#fff;border:1px solid #ddd;border-left:5px solid #c62828;padding:12px 16px;margin-bottom:18px;white-space:pre-wrap;font-size:13px}\n");
        h.Append(".banner-msg.ok{border-left-color:#2e7d32}\n");
        h.Append(".dev-banner{background:#ff9800;color:#fff;font-weight:bold;text-align:center;padding:10px;border-radius:4px;margin-bottom:16px;letter-spacing:1px}\n");
        h.Append(".op-section{margin:16px 0;padding:18px;border:2px solid #0078d4;border-radius:6px;background:#fafcff}\n");
        h.Append(".op-section h2{margin-top:0}\n");
        h.Append(".issue-table th{background:#f2dede}\n");
        h.Append(".prob{border:2px solid #c62828;border-left:10px solid #c62828;border-radius:5px;margin:16px 0;padding:0;page-break-inside:avoid;background:#fffafa}\n");
        h.Append(".prob-hd{background:#c62828;color:#fff;padding:9px 14px;font-weight:bold;font-size:14px;display:flex;justify-content:space-between;align-items:center}\n");
        h.Append(".prob-bd{padding:12px 14px;display:flex;gap:20px;align-items:flex-start;flex-wrap:wrap}\n");
        h.Append(".prob-txt{flex:1 1 420px;min-width:320px}\n");
        h.Append(".prob-txt dl{margin:0}\n");
        h.Append(".prob-txt dt{font-weight:bold;color:#c62828;font-size:11px;letter-spacing:.06em;margin-top:9px}\n");
        h.Append(".prob-txt dd{margin:2px 0 0 0}\n");
        h.Append(".ping{display:inline-block;background:#c62828;color:#fff;border-radius:3px;padding:1px 7px;font-weight:bold;font-family:Consolas,monospace;animation:pulse 1.1s ease-in-out infinite}\n");
        h.Append("@keyframes pulse{0%,100%{opacity:1}50%{opacity:.35}}\n");
        h.Append(".wellmap{border-collapse:collapse}\n");
        h.Append(".wellmap td{border:none;padding:0;width:15px;height:15px;text-align:center}\n");
        h.Append(".wellmap .lbl{font:9px Segoe UI,sans-serif;color:#777}\n");
        h.Append(".wellmap i{display:block;width:11px;height:11px;border-radius:50%;background:#e4e4e4;margin:1px auto}\n");
        h.Append(".wellmap i.hit{background:#c62828;box-shadow:0 0 0 3px rgba(198,40,40,.35);animation:pulse 1.1s ease-in-out infinite}\n");
        h.Append(".wl-wrap{overflow-x:auto;border:1px solid #ddd;border-radius:3px}\n");
        h.Append("table.wl{font-size:11px;white-space:nowrap;margin:0}\n");
        h.Append("table.wl th{position:sticky;top:0;background:#e8e8e8}\n");
        h.Append("table.wl td,table.wl th{padding:2px 6px}\n");
        h.Append("tr.wl-bad td{background:#fdecea;font-weight:600}\n");
        h.Append("tr.wl-bad td:first-child{box-shadow:inset 4px 0 0 #c62828}\n");
        h.Append(".wl-tag{background:#c62828;color:#fff;border-radius:3px;padding:0 6px;font-size:10px;font-weight:bold}\n");
        h.Append(".hint{cursor:help}\n");
        h.Append(".wl-tag.hint{border-bottom:1px dotted #fff}\n");
        h.Append(".issue-table td.row-no{font-weight:bold;text-align:center;width:70px;background:#fdf3f3}\n");
        h.Append(".legend{margin:10px 0;font-size:12px}\n");
        h.Append(".legend span{display:inline-block;margin-right:18px}\n");
        h.Append(".sw{display:inline-block;width:14px;height:14px;vertical-align:middle;margin-right:5px;border:1px solid #999}\n");
        h.Append(".grid-wrap{overflow-x:auto;margin:12px 0}\n");
        h.Append(".chk{width:22px;text-align:center}\n");
        h.Append(".chk input{width:15px;height:15px}\n");
        h.Append(".pass{color:#2e7d32;font-weight:bold}.fail{color:#c62828;font-weight:bold}\n");
        h.Append(".placeholder{border:1px dashed #999;border-left:5px solid #999;background:#fafafa;");
        h.Append("padding:10px 14px;margin:10px 0;color:#555;page-break-inside:avoid}\n");
        h.Append(".muted{color:#888}\n");
        h.Append("details{margin:8px 0}summary{cursor:pointer;font-weight:600;color:#0078d4;padding:4px 0}\n");
        h.Append(".foot{margin-top:22px;font-size:11px;color:#888;text-align:center}\n");
        h.Append(".topbar{display:flex;justify-content:space-between;align-items:flex-start;gap:16px}\n");
        h.Append("#modebtn{flex:0 0 auto;cursor:pointer;border:1px solid #0078d4;background:#fff;color:#0078d4;");
        h.Append("font:600 12px Segoe UI,sans-serif;padding:7px 14px;border-radius:16px;white-space:nowrap}\n");
        h.Append("#modebtn:hover{background:#0078d4;color:#fff}\n");
        h.Append("body.dev #modebtn{background:#ff9800;border-color:#ff9800;color:#fff}\n");
        h.Append(".dev-only{display:none}body.dev .dev-only{display:block}\n");
        h.Append("body.dev .dev-banner{display:block}.dev-banner{display:none}\n");
        h.Append("@media print{@page{size:letter landscape;margin:.5in}\n");
        h.Append("body{background:#fff;padding:0;font-size:11px}.container{border:none;padding:0;max-width:none}\n");
        h.Append("th{background:#e8e8e8!important;-webkit-print-color-adjust:exact;print-color-adjust:exact}\n");
        h.Append(".banner-ok,.banner-stop,.dev-banner,.sw,svg rect{-webkit-print-color-adjust:exact;print-color-adjust:exact}\n");
        h.Append(".op-section{border:none;background:none;padding:0}\n");
        h.Append("details{display:block}details>summary{display:none}\n");
        h.Append("#modebtn{display:none}\n");
        h.Append("*{animation:none!important}\n");
        h.Append(".prob{page-break-inside:avoid;border-left-width:8px;-webkit-print-color-adjust:exact;print-color-adjust:exact}\n");
        h.Append(".prob-hd,.ping,.wellmap i.hit{-webkit-print-color-adjust:exact;print-color-adjust:exact}\n");
        h.Append(".wellmap i.hit{box-shadow:none;outline:2px solid #000;outline-offset:1px}\n");
        h.Append(".prob-bd{display:block}\n");
        h.Append(".wl-wrap{overflow:visible;border:none}\n");
        h.Append("table.wl{font-size:8px;white-space:normal;table-layout:fixed;width:100%}\n");
        h.Append("table.wl th{position:static}\n");
        h.Append("table.wl td,table.wl th{padding:1px 2px;word-break:break-word}\n");
        h.Append("tr.wl-bad td,.wl-tag{-webkit-print-color-adjust:exact;print-color-adjust:exact}\n");
        h.Append("table{page-break-inside:avoid}h2{page-break-after:avoid}}\n");
        h.Append("</style></head><body class='").Append(DEV_MODE ? "dev" : "op").Append("'><div class='container'>\n");

        h.Append("<div class='dev-banner'>DEV MODE - validation and diagnostic sections are shown</div>\n");

        h.Append("<div class='topbar'><div>\n");
        h.Append("<h1>RNA Quantification / Normalization - run report</h1>\n");
        h.Append("<div class='sub'>Worklist ingestion ").Append(SCRIPT_VERSION)
         .Append(" &middot; Run ").Append(E(runId))
         .Append(" &middot; ").Append(DateTime.Now.ToString("dddd d MMMM yyyy, HH:mm:ss")).Append("</div>\n");
        h.Append("</div>\n<button id='modebtn' onclick=\"document.body.classList.toggle('dev');");
        h.Append("this.textContent=document.body.classList.contains('dev')?'Dev mode - switch to Operator':'Operator mode - switch to Dev';\">");
        h.Append(DEV_MODE ? "Dev mode - switch to Operator" : "Operator mode - switch to Dev").Append("</button>\n</div>\n");

        // ---------- status banner ----------
        if (ok)
        {
            h.Append("<div class='banner-ok'>READY TO RUN</div>\n");
            h.Append("<div class='banner-msg ok'>").Append(E(
                samples.Count + " samples across " + srcOrder.Count + " source plate(s).\n"
                + "Check the deck against the layout and checklist below, then select OK on the confirmation box to start."))
             .Append("</div>\n");
        }
        else
        {
            h.Append("<div class='banner-stop'>RUN STOPPED - ").Append(E(FriendlyCode(failCode))).Append("</div>\n");
            h.Append("<div class='banner-msg'>").Append(E(failMsg)).Append("</div>\n");
        }

        // ---------- OPERATOR SECTION ----------
        h.Append("<div class='op-section'>\n<h2>Run summary</h2>\n");
        h.Append("<table class='kv'>\n");
        Kv(h, "Worklist", wlFile.Length > 0 ? Path.GetFileName(wlFile) : "(none selected)");
        Kv(h, "Samples", ok ? samples.Count.ToString() : (dataRowCount > 0 ? dataRowCount + " rows read" : "-"));
        Kv(h, "Source plates", srcOrder.Count > 0 ? srcOrder.Count + " (" + string.Join(", ", srcOrder) + ")" : "-");
        Kv(h, "Target concentration", Hdr(fileHeader, "TargetConcentration"));
        Kv(h, "Requested output volume", Hdr(fileHeader, "RequestedOutputVolume"));
        Kv(h, "Extinction coefficient", Hdr(fileHeader, "ExtinctionCoefficientUsed"));
        Kv(h, "Site", Hdr(fileHeader, "Site"));
        Kv(h, "Operator", Hdr(fileHeader, "OperatorID"));
        h.Append("</table>\n");

        // ---------- localised issues ----------
        if (issues.Count > 0)
        {
            h.Append("<h2>What needs correcting</h2>\n");
            h.Append("<p>Row numbers count <strong>sample rows</strong> - the data rows only, not lines in the file "
                   + "(the header block and any # comment lines are not counted).</p>\n");
            int pn = 0;
            problemRowIndex.Clear(); problemTip.Clear();
            foreach (RowIssue ri in issues)
            {
                pn++;
                foreach (int rw in ri.Rows)
                {
                    if (!problemRowIndex.ContainsKey(rw)) problemRowIndex[rw] = new List<int>();
                    if (!problemRowIndex[rw].Contains(pn)) problemRowIndex[rw].Add(pn);
                }
                problemTip[pn] = BuildTip(pn, ri);
            }
            pn = 0;
            foreach (RowIssue ri in issues) { pn++; EmitProblem(h, ri, pn, issues.Count); }
        }

        // ---------- deck ----------
        EmitWorklistAsRead(h);
        if (platesRequired > 0) EmitRebuild(h);
        h.Append("<h2>Deck layout</h2>\n");
        h.Append("<p class='muted'>Source of this layout: ").Append(E(deckSource)).Append("</p>\n");
        if (deck.Count == 0)
            h.Append("<p class='muted'>The deck layout could not be read, so it cannot be shown.</p>\n");
        else
        {
            h.Append("<div class='legend'>");
            foreach (string cat in new[] { "tips", "source", "quant", "output", "diluent" })
                h.Append("<span><i class='sw' style='background:").Append(ColourOf(cat)).Append("'></i>").Append(LabelOf(cat)).Append("</span>");
            h.Append("<span><i class='sw' style='background:#fff'></i>Empty</span>");
            if (badLocs.Count > 0) h.Append("<span><i class='sw' style='background:#f2dede;border:2px solid #c62828'></i>Missing / problem</span>");
            h.Append("</div>\n");
            h.Append(DeckSvg());
        }

        // ---------- placement checklist ----------
        if (deck.Count > 0)
        {
            h.Append("<h2>Labware placement checklist</h2>\n");
            h.Append("<p>Tick each position as you confirm it on the deck.</p>\n");
            h.Append("<table><tr><th class='chk'>&#10003;</th><th>Position</th><th>Labware</th><th>Category</th></tr>\n");
            var ordered = deck.OrderBy(e => LocSort(e.Value)).ToList();
            foreach (var kv in ordered)
            {
                string cat = CategoryOf(kv.Key);
                h.Append("<tr><td class='chk'><input type='checkbox'></td><td class='mono'>").Append(E(kv.Value))
                 .Append("</td><td>").Append(E(kv.Key)).Append("</td><td><i class='sw' style='background:")
                 .Append(ColourOf(cat)).Append("'></i>").Append(LabelOf(cat)).Append("</td></tr>\n");
            }
            h.Append("</table>\n");
        }

        EmitBarcodeLabelGuidance(h);
        h.Append("</div>\n"); // /op-section

        // ---------- DEV SECTIONS ----------
        {
            h.Append("<div class='dev-only'>\n");
            EmitBarcodeHandoff(h);
            EmitValidation(h, app);
            h.Append("<h2>Ingest-path self-report</h2>\n");
            h.Append("<p class='muted'>These are the ingest path reporting on itself. They are NOT independent - the cross-check above is what actually tests the run.</p>\n");
            h.Append("<table><tr><th>Check</th><th>Result</th><th>Detail</th></tr>\n");
            Chk(h, "Worklist selected", wlFile.Length > 0, wlFile.Length > 0 ? Path.GetFileName(wlFile) : "no file chosen");
            Chk(h, "Deck layout readable", deck.Count > 0, deck.Count + " positions occupied");
            Chk(h, "Column header row found", colNames.Count > 0, colNames.Count + " columns");
            Chk(h, "Data rows present", dataRowCount > 0, dataRowCount + " rows");
            Chk(h, "Required columns present", failCode != "MISSING_COLUMNS", "SourcePlateBarcode, SourceWell, QuantificationWell, OutputWell");
            EmitIssueChecks(h);
            Chk(h, "Bridge written", ok, ok ? samples.Count + " samples" : "not reached");
            h.Append("</table>\n");

            h.Append("<h2>Worklist file header</h2>\n");
            if (fileHeader.Count == 0) h.Append("<p class='muted'>No header lines were read.</p>\n");
            else { h.Append("<table class='kv'>\n"); foreach (var kv in fileHeader) Kv(h, kv.Key, kv.Value); h.Append("</table>\n"); }

            h.Append("<h2>Deck parse (handle &rarr; location)</h2>\n<table><tr><th>Labware name</th><th>Location</th><th>Category</th></tr>\n");
            foreach (var dk in deck.OrderBy(e => LocSort(e.Value)))
                h.Append("<tr><td>").Append(E(dk.Key)).Append("</td><td class='mono'>").Append(E(dk.Value))
                 .Append("</td><td>").Append(LabelOf(CategoryOf(dk.Key))).Append("</td></tr>\n");
            h.Append("</table>\n");

            if (samples.Count > 0)
            {
                h.Append("<h2>Per-sample bridge (parsed)</h2>\n");
                h.Append("<p class='muted'>TransferVolume and DiluentVolume are deliberately empty - they are computed after the Lunatic read.</p>\n");
                h.Append("<table><tr><th>#</th><th>Row</th><th>ID</th><th>Animal</th><th>Tissue</th><th>Src barcode</th><th>Src well</th>")
                 .Append("<th>Src plate</th><th>Src loc</th><th>Quant well</th><th>Quant plate</th><th>Quant loc</th>")
                 .Append("<th>Out well</th><th>Out plate</th><th>Out loc</th><th>Tip box</th></tr>\n");
                int rowIx = 1;
                foreach (Sample s in samples)
                    h.Append("<tr><td>").Append(rowIx++).Append("</td><td>").Append(s.RowNo)
                     .Append("</td><td>").Append(E(s.Id)).Append("</td><td>").Append(E(s.Animal))
                     .Append("</td><td>").Append(E(s.Tissue)).Append("</td><td>").Append(E(s.SrcBc))
                     .Append("</td><td>").Append(E(s.SrcWell)).Append("</td><td>").Append(E(s.SrcPlate))
                     .Append("</td><td class='mono'>").Append(E(s.SrcLoc)).Append("</td><td>").Append(E(s.QWell))
                     .Append("</td><td>").Append(E(s.QPlate)).Append("</td><td class='mono'>").Append(E(s.QLoc))
                     .Append("</td><td>").Append(E(s.OWell)).Append("</td><td>").Append(E(s.OPlate))
                     .Append("</td><td class='mono'>").Append(E(s.OLoc)).Append("</td><td>").Append(E(s.TipBox))
                     .Append("</td></tr>\n");
                h.Append("</table>\n");
            }

            h.Append("<h2>Bridge variables as written to MM4</h2>\n");
            h.Append("<p class='muted'>Read back from MM4 after writing - this is what the next method step will see.</p>\n");
            h.Append("<table><tr><th>Variable</th><th>Value</th></tr>\n");
            foreach (string v in ALL)
            {
                string val = SafeGet(app, v);
                h.Append("<tr><td class='mono'>").Append(E(v)).Append("</td><td class='mono'>")
                 .Append(val.Length == 0 ? "<span class='muted'>(empty)</span>" : E(val.Length > 400 ? val.Substring(0, 400) + " ..." : val))
                 .Append("</td></tr>\n");
            }
            h.Append("</table>\n");

            if (colNames.Count > 0)
            {
                h.Append("<details><summary>Worklist columns as found (").Append(colNames.Count).Append(")</summary><p class='mono'>")
                 .Append(E(string.Join(" | ", colNames))).Append("</p></details>\n");
            }

            // deck positions with their real coordinates - the data the picture is drawn from
            h.Append("<h2>Deck positions as reported by MM4</h2>\n");
            h.Append("<p class='muted'>Straight from User.OutputWorktable_01 and the machine worktable config.</p>\n");
            h.Append("<table><tr><th>Location</th><th>Plate</th><th>Labware</th><th>Barcode</th><th>State</th></tr>\n");
            foreach (DeckPos dp in deckPos.OrderBy(z => z.Loc))
                h.Append("<tr><td class='mono'>").Append(E(dp.Loc)).Append("</td><td>").Append(E(dp.Plate))
                 .Append("</td><td>").Append(E(dp.Labware))
                 .Append("</td><td class='mono'>").Append(dp.Barcode.Length > 0 ? E(dp.Barcode) : "<span class='muted'>-</span>")
                 .Append("</td><td>").Append(dp.Occupied ? "loaded" : "<span class='muted'>empty</span>").Append("</td></tr>\n");
            h.Append("</table>\n");

            h.Append("</div>\n"); // /dev-only
        }

        h.Append("<p class='foot'>QuantNorm_WorklistIngestion ").Append(SCRIPT_VERSION)
         .Append(" - use the button top right to switch between operator and dev views")
         .Append(" &middot; generated ").Append(DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")).Append("</p>\n");
        h.Append("</div></body></html>");

        string file = Path.Combine(reportDir, "QuantNorm_run_" + runId + (ok ? "" : "_STOPPED") + ".html");
        File.WriteAllText(file, h.ToString(), Encoding.UTF8);
        return file;
    }

    // One self-report row per issue type, PASS/FAIL decided by COUNTING issues whose stable Kind code
    // matches - never by comparing the operator-facing What text, which is what v0.7.3 did and why
    // "No duplicate wells" and "Source plates within capacity" printed PASS on the dup and overcap
    // worklists. Kept as its own method so it can be exercised directly against the compiled assembly
    // without MM4 - the fix is tested by running THIS code, not a copy of it.
    private void EmitIssueChecks(StringBuilder h)
    {
        foreach (string[] ik in ISSUE_KINDS)
        {
            int nk = issues.Count(isu => isu.Kind == ik[0]);
            string dtl = nk == 0 ? ik[2] : nk + " " + ik[3] + (nk == 1 ? "" : "s");
            if (ik[0] == "OVERCAP") dtl += " (max " + MAX_SOURCE_PLATES + " source plates)";
            if (ik[0] == "DECK" && badLocs.Count > 0) dtl += ": " + string.Join(", ", badLocs);
            Chk(h, ik[1], nk == 0, dtl);
        }
    }

    private static void Kv(StringBuilder h, string k, string v)
    { h.Append("<tr><th>").Append(E(k)).Append("</th><td>").Append(v.Length == 0 ? "<span class='muted'>-</span>" : E(v)).Append("</td></tr>\n"); }

    private static void Chk(StringBuilder h, string name, bool pass, string detail)
    { h.Append("<tr><td>").Append(E(name)).Append("</td><td class='").Append(pass ? "pass'>PASS" : "fail'>FAIL")
       .Append("</td><td class='muted'>").Append(E(detail)).Append("</td></tr>\n"); }

    private static int LocSort(string loc)
    { string d = new string((loc ?? "").Where(char.IsDigit).ToArray()); int n; return int.TryParse(d, out n) ? n : 9999; }

    private static string FriendlyCode(string code)
    {
        switch (code)
        {
            case "CANCELLED":        return "cancelled";
            case "NO_WORKTABLE":     return "deck layout unavailable";
            case "READ_ERROR":       return "worklist could not be opened";
            case "NO_HEADER_ROW":    return "not a worklist file";
            case "EMPTY_WORKLIST":   return "no samples in the worklist";
            case "MISSING_COLUMNS":  return "worklist missing a required column";
            case "WORKLIST_INVALID": return "worklist needs correcting";
            default:                 return code.ToLowerInvariant().Replace('_', ' ');
        }
    }

    // Deck drawn the way MM4'S OWN Worktable View draws it: a UNIFORM grid.
    // Real coordinates are clustered into columns and rows (so true position and ordering come from the
    // machine, not from the Loc number), then laid out evenly. Cell aspect is the true SBS footprint
    // ratio 127.76 : 85.5 = 1.494 : 1.
    //   columns ordered by DESCENDING X  - X gets more negative toward the RIGHT of the deck
    //   rows    ordered by DESCENDING Y  - Y gets more negative toward the BACK, so front ends at the bottom
    private string DeckSvg()
    {
        if (deckPos.Count == 0) return "<p class='muted'>No deck positions to draw.</p>";

        List<double> cols = Cluster(deckPos.Select(q => q.X).ToList(), 40.0);   // descending = left..right
        List<double> rows = Cluster(deckPos.Select(q => q.Y).ToList(), 40.0);   // descending = front..back

        double cellW = 152, cellH = cellW * 85.5 / 127.76;      // plate area, true 1.494:1 footprint
        double hdrH = 14, ftrH = 24;                            // label bands - never drawn over
        double slotH = hdrH + cellH + ftrH;
        double gapX = 14, gapY = 8;
        int mL = 14, mT = 22, mR = 14, mB = 26;
        int svgW = (int)(mL + cols.Count * cellW + (cols.Count - 1) * gapX + mR);
        int svgH = (int)(mT + rows.Count * slotH + (rows.Count - 1) * gapY + mB);

        var badPlates = new HashSet<string>(badLocs);
        var sb = new StringBuilder();
        sb.Append("<div class='grid-wrap'><svg width='").Append(svgW).Append("' height='").Append(svgH)
          .Append("' viewBox='0 0 ").Append(svgW).Append(" ").Append(svgH).Append("' xmlns='http://www.w3.org/2000/svg'>\n");
        sb.Append("<style>.loc{font:10px Segoe UI,sans-serif}.pl{font:600 11px Segoe UI,sans-serif}")
          .Append(".lw{font:8px Segoe UI,sans-serif}.ax{font:600 10px Segoe UI,sans-serif;fill:#888}</style>\n");

        foreach (DeckPos d in deckPos)
        {
            int ci = Nearest(cols, d.X), ri = Nearest(rows, d.Y);
            if (ci < 0 || ri < 0) continue;
            double x = mL + ci * (cellW + gapX);
            double slotY = mT + (rows.Count - 1 - ri) * (slotH + gapY);   // front (ri=0) -> bottom
            double y = slotY + hdrH;                                      // plate sits below its header band

            LabwareDef lw = labware.ContainsKey(d.Labware) ? labware[d.Labware] : null;
            bool bad = d.Occupied && badPlates.Contains(d.Plate);
            string body = !d.Occupied ? "#d9d9d9"
                        : (lw != null && lw.Body.Length > 0) ? lw.Body : "#e8d9b0";  // unset in MM4 -> neutral
            string edge = bad ? "#c62828" : "#3a3a3a";

            sb.Append("<rect x='").Append(F(x)).Append("' y='").Append(F(y)).Append("' width='").Append(F(cellW))
              .Append("' height='").Append(F(cellH)).Append("' fill='").Append(body)
              .Append("' stroke='").Append(edge).Append("' stroke-width='").Append(bad ? "3" : "1.2").Append("'/>\n");

            if (d.Occupied && lw != null && lw.Rows > 0 && lw.Cols > 0 && lw.Rows * lw.Cols <= 400)
            {
                string wc = lw.Well.Length > 0 ? lw.Well : "#ffffff";
                // millimetre -> pixel, using the SAME factor as the plate outline so wells sit where
                // they physically are on the plate rather than on an invented even division.
                double sx = cellW / (lw.Length > 0 ? lw.Length : 127.76);
                double sy = cellH / (lw.Width  > 0 ? lw.Width  : 85.5);
                bool haveGeom = lw.ColSpacing > 0 && lw.RowSpacing > 0;
                double a1c = haveGeom ? lw.A1Col : (lw.Length / (lw.Cols + 1));
                double a1r = haveGeom ? lw.A1Row : (lw.Width / (lw.Rows + 1));
                double cs = haveGeom ? lw.ColSpacing : (lw.Length - 2 * a1c) / Math.Max(1, lw.Cols - 1);
                double rs = haveGeom ? lw.RowSpacing : (lw.Width - 2 * a1r) / Math.Max(1, lw.Rows - 1);
                double wlp = Math.Max(1.0, (lw.WellL > 0 ? lw.WellL : cs * 0.75) * sx / 2.0);
                double wwp = Math.Max(1.0, (lw.WellW > 0 ? lw.WellW : rs * 0.75) * sy / 2.0);
                for (int rr = 0; rr < lw.Rows; rr++)
                    for (int cc = 0; cc < lw.Cols; cc++)
                    {
                        double wx = x + (a1c + cs * cc) * sx, wy = y + (a1r + rs * rr) * sy;
                        if (lw.Circular)
                            sb.Append("<ellipse cx='").Append(F(wx)).Append("' cy='").Append(F(wy))
                              .Append("' rx='").Append(F(wlp)).Append("' ry='").Append(F(wwp))
                              .Append("' fill='").Append(wc).Append("' stroke='#8f8f8f' stroke-width='0.35'/>\n");
                        else
                            sb.Append("<rect x='").Append(F(wx - wlp)).Append("' y='").Append(F(wy - wwp))
                              .Append("' width='").Append(F(wlp * 2)).Append("' height='").Append(F(wwp * 2))
                              .Append("' fill='").Append(wc).Append("' stroke='#8f8f8f' stroke-width='0.35'/>\n");
                    }
            }

            // Labels live in the bands ABOVE and BELOW the plate - never over the wells.
            sb.Append("<text class='loc' text-anchor='end' x='").Append(F(x + cellW)).Append("' y='").Append(F(slotY + 10))
              .Append("' fill='").Append(d.Occupied ? "#333" : "#999").Append("'>").Append(d.Loc).Append("</text>\n");
            if (d.Occupied)
            {
                sb.Append("<text class='pl' x='").Append(F(x)).Append("' y='").Append(F(y + cellH + 12))
                  .Append("' fill='#1a1a1a'>").Append(E(Clip(d.Plate, 24))).Append("</text>\n");
                sb.Append("<text class='lw' x='").Append(F(x)).Append("' y='").Append(F(y + cellH + 21))
                  .Append("' fill='#666'>").Append(E(Clip(d.Labware, 34))).Append("</text>\n");
            }
        }

        sb.Append("<text class='ax' x='").Append(mL).Append("' y='").Append(mT - 10).Append("'>BACK</text>\n");
        sb.Append("<text class='ax' x='").Append(mL).Append("' y='").Append(svgH - 8).Append("'>FRONT - operator side</text>\n");
        sb.Append("<text class='ax' text-anchor='end' x='").Append(svgW - mR).Append("' y='").Append(svgH - 8)
          .Append("'>").Append(cols.Count).Append(" x ").Append(rows.Count).Append(" positions</text>\n");
        sb.Append("</svg></div>\n");

        if (badLocs.Count > 0)
            sb.Append("<p><strong>Not on the deck:</strong> ").Append(E(string.Join(", ", badLocs)))
              .Append(" - the worklist needs ").Append(badLocs.Count == 1 ? "this position" : "these positions")
              .Append(", but ").Append(badLocs.Count == 1 ? "it is" : "they are").Append(" not loaded.</p>\n");
        return sb.ToString();
    }

    // ======================================================================================
    //  VALIDATION - PASS 1 (reference workflow/Tody D107 "Source Cross-Check" model)
    // ======================================================================================
    //  DESIGN PRINCIPLE, verbatim from the D107 handoff that specified Tody's report:
    //    "The validation report MUST re-read source files independently. Do NOT use the
    //     script's in-memory parsed data for source columns. The whole point is to compare
    //     what's on disk vs. what the script produced."
    //  So ReDerive below is a SECOND, SELF-CONTAINED parser. It shares no state and no column
    //  matching with the ingest path on purpose - reusing that code would reproduce its blind
    //  spots and the comparison would agree with itself, which is what Jim rejected in v0.4.x.
    //
    //  Three columns per row, per D107:
    //     A SOURCE        - re-derived from the worklist file on disk
    //     B SCRIPT OUTPUT - read back out of MM4 with GetVariableValue
    //     C MATCH         - green / red
    //
    //  No instrument is needed for any of this: it asks whether MM4's live state follows from
    //  the worklist, which is answerable the moment the bridge is written.
    // ======================================================================================

    private class ReDerived
    {
        public Dictionary<string, List<string>> Lists = new Dictionary<string, List<string>>();
        public Dictionary<string, string> Scalars = new Dictionary<string, string>();
        public List<string> PlateOrder = new List<string>();
        public Dictionary<string, List<string>> WellsByPlate = new Dictionary<string, List<string>>();
        public int Rows;
        public string Error = "";
    }

    // Independent re-read + re-derivation. Deliberately does NOT call ParseWorktable, Col or the
    // ingest loop.
    private ReDerived ReDerive(string worklistPath, Dictionary<string, string> deckMap)
    {
        var rd = new ReDerived();
        try
        {
            string[] raw = Qn.ReadRecords(worklistPath).ToArray();
            List<string> hdr = null;
            var bodyRows = new List<string[]>();
            foreach (string line0 in raw)
            {
                string line = line0.TrimEnd();
                if (line.Length == 0 || line.TrimStart().StartsWith("#")) continue;
                string[] cells = Qn.Fields(line, ',');
                if (hdr == null)
                {
                    bool looksHeader = false;
                    foreach (string c in cells)
                    { string k = Key(c); if (k == "sourceplatebarcode" || k == "sourcewell") { looksHeader = true; break; } }
                    if (looksHeader) { hdr = new List<string>(); foreach (string c in cells) hdr.Add(Key(c)); continue; }
                    int ci = line.IndexOf(':');
                    if (ci > 0) rd.Scalars[Key(line.Substring(0, ci))] = line.Substring(ci + 1).Trim();
                    continue;
                }
                bodyRows.Add(cells);
            }
            if (hdr == null) { rd.Error = "no column header row found on re-read"; return rd; }

            int cBc = hdr.IndexOf("sourceplatebarcode"), cSw = hdr.IndexOf("sourcewell");
            int cQw = hdr.IndexOf("quantificationwell"), cOw = hdr.IndexOf("outputwell");
            if (cBc < 0 || cSw < 0 || cQw < 0 || cOw < 0) { rd.Error = "required columns absent on re-read"; return rd; }

            var Lbc = new List<string>(); var Lsw = new List<string>(); var Lqw = new List<string>(); var Low = new List<string>();
            var Lsp = new List<string>(); var Lsl = new List<string>(); var Lqp = new List<string>(); var Lql = new List<string>();
            var Lop = new List<string>(); var Lol = new List<string>(); var Ltb = new List<string>();
            var seenPair = new HashSet<string>();

            foreach (string[] r in bodyRows)
            {
                string bc = At(r, cBc), sw = At(r, cSw);
                if (bc.Length == 0 || sw.Length == 0) continue;
                if (!seenPair.Add(bc + "|" + Qn.Well(sw))) continue;
                if (!rd.PlateOrder.Contains(bc)) rd.PlateOrder.Add(bc);
                int idx = rd.PlateOrder.IndexOf(bc);
                if (idx >= MAX_SOURCE_PLATES) continue;
                string ix = (idx + 1).ToString("D2");
                string sH = HDL_SOURCE + ix, qH = HDL_LUNATIC + ix, oH = HDL_OUTPUT + ix, tH = HDL_SAMPTIP + ix;
                if (!deckMap.ContainsKey(sH) || !deckMap.ContainsKey(qH) || !deckMap.ContainsKey(oH)) continue;

                if (!rd.WellsByPlate.ContainsKey(bc)) rd.WellsByPlate[bc] = new List<string>();
                rd.WellsByPlate[bc].Add(sw);

                Lbc.Add(bc); Lsw.Add(sw); Lqw.Add(At(r, cQw)); Low.Add(At(r, cOw));
                Lsp.Add(sH); Lsl.Add(deckMap[sH]);
                Lqp.Add(qH); Lql.Add(deckMap[qH]);
                Lop.Add(oH); Lol.Add(deckMap[oH]);
                Ltb.Add(deckMap.ContainsKey(tH) ? tH : "");
            }
            rd.Rows = Lbc.Count;
            // v0.8.4 — the independent re-derivation still compares the PER-ROW lists, because those
            // are the ones with one element per worklist row to compare. The per-plate handle lists
            // are checked separately below: they are <prefix>_kk by construction, so re-deriving them
            // would be re-deriving a constant and would prove nothing.
            rd.Lists[L_SRCBC] = Lbc; rd.Lists[L_SRCWELL] = Lsw; rd.Lists[L_QWELL] = Lqw; rd.Lists[L_OWELL] = Low;
            rd.Lists[R_SRCPLATE] = Lsp; rd.Lists[R_SRCLOC] = Lsl;
            rd.Lists[R_QPLATE] = Lqp; rd.Lists[R_QLOC] = Lql;
            rd.Lists[R_OPLATE] = Lop; rd.Lists[R_OLOC] = Lol; rd.Lists[R_TIPBOX] = Ltb;
        }
        catch (Exception ex) { rd.Error = ex.Message; }
        return rd;
    }

    // MUST normalise identically to the ingest path's NormalizeCol, or the two parsers disagree on a
    // header spelled with a micro sign and the cross-check reports a false mismatch.
    // \u00B5 = MICRO SIGN, \u03BC = GREEK SMALL LETTER MU - both occur in real worklist headers.
    static string Key(string s)
    { return (s ?? "").Trim().Replace("\u00B5", "u").Replace("\u03BC", "u").Replace(" ", "").ToLowerInvariant(); }
    static string At(string[] a, int i) { return (i >= 0 && i < a.Length) ? a[i].Trim() : ""; }

    private void EmitValidation(StringBuilder h, IMMApp app)
    {
        h.Append("<h2>Validation - Pass 1: worklist cross-check</h2>\n");
        h.Append("<p>The worklist has been <strong>re-read from disk by a separate parser</strong> and every bridge list ");
        h.Append("re-derived from that fresh read, then compared element-by-element against what MM4 actually holds. ");
        h.Append("<strong>Column A</strong> is the worklist on disk, <strong>column B</strong> is MM4's live state, ");
        h.Append("<strong>column C</strong> is whether they agree. Nothing is compared against a human expectation, so this needs no instrument.</p>\n");

        if (wlFile.Length == 0) { h.Append("<p class='muted'>No worklist was selected - nothing to cross-check.</p>\n"); return; }
        ReDerived rd = ReDerive(wlFile, deck);
        if (rd.Error.Length > 0)
        { h.Append("<p class='fail'>Cross-check could not run: ").Append(E(rd.Error)).Append("</p>\n"); return; }

        // THE RUN STOPPED BEFORE THE BRIDGE EXISTED. There is nothing to compare against, and saying
        // so is the honest answer - v0.7.5 instead compared the worklist against empty variables and
        // printed a red DISAGREEMENTS FOUND on runs that had behaved exactly as intended.
        if (!bridgeWritten)
        {
            h.Append("<div class='placeholder'><strong>Not applicable for this run.</strong><br>")
             .Append("The run was stopped before the bridge was written, so MM4 holds no per-sample lists ")
             .Append("to compare the worklist against. <strong>This is not a validation failure</strong> - ")
             .Append("it is the correct outcome for a run that stopped, and the reason is in the banner at ")
             .Append("the top of this report.</div>\n");
            h.Append("<p class='muted'>What the worklist itself implies is still shown below, because that ")
             .Append("is derived from the file and the deck and is useful when working out what to correct.</p>\n");
            if (paramsWritten) EmitParamCheck(h, app, rd);   // these WERE set, so comparing them is real
            EmitDeckIntent(h, rd);
            return;
        }

        int totalMismatch = 0, totalCompared = 0;
        var lists = new string[] { L_SRCBC, L_SRCWELL, L_QWELL, L_OWELL, R_SRCPLATE, R_SRCLOC,
                                   R_QPLATE, R_QLOC, R_OPLATE, R_OLOC, R_TIPBOX };
        h.Append("<h3>Per-sample bridge lists</h3>\n");
        h.Append("<table><tr><th>Bridge variable</th><th>A - re-derived from worklist</th>");
        h.Append("<th>B - held by MM4</th><th>Elements compared</th><th>C - match</th><th>First disagreement</th></tr>\n");
        foreach (string v in lists)
        {
            List<string> a = rd.Lists.ContainsKey(v) ? rd.Lists[v] : new List<string>();
            string bRaw = SafeGet(app, v);
            // v0.8.4 — every published list now leads with the delimiter, so element 0 is the phantom
            // that makes a base-1 counter work. It must come off before comparing, or A and B are
            // offset by one and EVERY element reports as a disagreement. The re-derived list A holds
            // real rows only.
            List<string> b = DropLeadingPhantom(bRaw);
            int n = Math.Max(a.Count, b.Count), bad = 0; string first = "";
            for (int i = 0; i < n; i++)
            {
                string av = i < a.Count ? a[i] : "(missing)", bv = i < b.Count ? b[i] : "(missing)";
                if (av != bv) { bad++; if (first.Length == 0) first = "element " + (i + 1) + ": A=" + av + " / B=" + bv; }
            }
            totalMismatch += bad; totalCompared += n;
            h.Append("<tr><td class='mono'>").Append(E(v)).Append("</td><td>").Append(a.Count);
            h.Append("</td><td>").Append(b.Count).Append("</td><td>").Append(n);
            // .pass / .fail, NOT .match / .mismatch - the latter two were never defined in the style
            // block, so MATCH and DIFFER printed as plain black text with no green/red signal.
            h.Append("</td><td class='").Append(bad == 0 ? "pass'>MATCH" : "fail'>" + bad + " DIFFER");
            h.Append("</td><td class='mono'>").Append(first.Length == 0 ? "-" : E(first)).Append("</td></tr>\n");
        }
        h.Append("</table>\n");

        int scalarBad = EmitParamCheck(h, app, rd);

        EmitDeckIntent(h, rd);

        int declared = 0; int.TryParse(SafeGet(app, V_COUNT), out declared);
        var emptyByDesign = new string[] { L_QBC, L_OBC, L_A260_1, L_A260_2, L_ACCA260, L_A280, L_A230,
                                           L_CALCCONC, L_XFERVOL, L_DILVOL, L_PURITY, L_XFERSTAT };
        int ebdBad = 0;
        foreach (string v in emptyByDesign)
        {
            // v0.8.4 — count the REAL elements. These lists are seeded as n empties behind a leading
            // comma, so a raw Split gives n+1 and the size check would fail on every run.
            List<string> real = DropLeadingPhantom(SafeGet(app, v));
            int cnt = real.Count;
            bool blankAll = true;
            foreach (string piece in real) if (piece.Trim().Length > 0) { blankAll = false; break; }
            if (cnt != declared || !blankAll) ebdBad++;
        }

        bool cRows = rd.Rows == declared;
        bool cLists = totalMismatch == 0;
        bool cScalars = scalarBad == 0;
        bool cEmpty = ebdBad == 0;
        bool cPlates = rd.PlateOrder.Count <= MAX_SOURCE_PLATES;
        bool cDeck = true;
        foreach (string v in new string[] { L_SRCPLATE, L_QPLATE, L_OPLATE })
        {
            string val = SafeGet(app, v);
            if (val.Length == 0) continue;
            foreach (string hd in val.Split(',')) if (hd.Length > 0 && !deck.ContainsKey(hd)) { cDeck = false; break; }
        }
        bool all = cRows && cLists && cScalars && cEmpty && cPlates && cDeck;

        h.Append("<h3>Validation summary</h3>\n");
        h.Append(all ? "<p class='pass' style='font-size:16px'>ALL CROSS-CHECKS PASSED</p>\n"
                     : "<p class='fail' style='font-size:16px'>DISAGREEMENTS FOUND (" + totalMismatch + " element(s), " + scalarBad + " parameter(s))</p>\n");
        h.Append("<table><tr><th>Check</th><th>Result</th><th>Detail</th></tr>\n");
        Chk(h, "Row count re-derived from the worklist equals User.TransferCount_01", cRows, rd.Rows + " re-derived vs " + declared + " declared");
        Chk(h, "Every bridge list element matches the re-derived value", cLists, totalCompared + " elements compared across " + lists.Length + " lists");
        Chk(h, "Run parameters match the worklist header block", cScalars, PARAM_PAIRS.Length + " parameters");
        Chk(h, "Lists computed later are present, correctly sized and empty", cEmpty, emptyByDesign.Length + " lists x " + declared + " elements");
        Chk(h, "Source plate count within capacity", cPlates, rd.PlateOrder.Count + " of " + MAX_SOURCE_PLATES);
        Chk(h, "Every deck handle written to the bridge exists on the worktable", cDeck, deck.Count + " positions loaded");
        h.Append("</table>\n");

        h.Append("<h3>Not covered by this pass</h3>\n<ul>");
        h.Append("<li>Anything needing the instrument - barcode scanning, plate movement, pipetting.</li>");
        h.Append("<li>Whether the worklist itself is <em>correct</em>. This proves MM4's state follows from the file; it cannot tell you the file is right.</li>");
        h.Append("<li>Volumes and readings - computed after the Lunatic read, deliberately empty here (checked above only for size and emptiness).</li>");
        h.Append("</ul>\n");
        h.Append("<div class='placeholder'><strong>Pass 2 - post-run</strong><br>Scanned barcodes, barcode reconciliation, dispensed volumes, transfer status and timing. Populated by the Output section once it is built.</div>\n");
    }

    // Extracted in v0.7.6 so the stopped-run path and the completed-run path emit the SAME tables from
    // the SAME code. Two copies would drift, and a drifted copy is exactly what produced the v0.7.4
    // checks that could never fail.
    private int EmitParamCheck(StringBuilder h, IMMApp app, ReDerived rd)
    {
        h.Append("<h3>Run parameters - traced to the worklist header block</h3>\n");
        h.Append("<table><tr><th>Bridge variable</th><th>A - worklist header line</th><th>B - held by MM4</th><th>C - match</th></tr>\n");
        int scalarBad = 0;
        foreach (string[] pr in PARAM_PAIRS)
        {
            string k = Key(pr[0]);
            string a = rd.Scalars.ContainsKey(k) ? rd.Scalars[k] : "";
            string b = SafeGet(app, pr[1]);
            bool okv = a == b; if (!okv) scalarBad++;
            h.Append("<tr><td class='mono'>").Append(E(pr[1])).Append("</td><td>");
            h.Append(a.Length > 0 ? E(a) : "<span class='muted'>absent from file</span>").Append("</td><td>");
            h.Append(b.Length > 0 ? E(b) : "<span class='muted'>empty</span>").Append("</td><td class='");
            h.Append(okv ? "pass'>MATCH" : "fail'>DIFFER").Append("</td></tr>\n");
        }
        h.Append("</table>\n");
        return scalarBad;
    }

    private void EmitDeckIntent(StringBuilder h, ReDerived rd)
    {
        h.Append("<h3>What this worklist determines on the deck</h3>\n");
        h.Append("<p class='muted'>Distinct source barcodes drive HOW MANY deck positions the run uses, and the "
               + "locations come from the worktable rather than from memory. <strong>The pairing of a particular "
               + "barcode to a particular position below is PROVISIONAL</strong> - it is listed in worklist "
               + "first-seen order purely so the table has an order. The operator loads in any order and the "
               + "barcode scan establishes the real mapping, which is then written back over these values.</p>\n");
        h.Append("<table><tr><th>#</th><th>Source barcode</th><th>Wells used</th><th>Source position</th>");
        h.Append("<th>Quantification position</th><th>Output position</th><th>Tips</th></tr>\n");
        for (int i = 0; i < rd.PlateOrder.Count && i < MAX_SOURCE_PLATES; i++)
        {
            string bc = rd.PlateOrder[i], ix = (i + 1).ToString("D2");
            int wc = rd.WellsByPlate.ContainsKey(bc) ? rd.WellsByPlate[bc].Count : 0;
            string sH = HDL_SOURCE + ix, qH = HDL_LUNATIC + ix, oH = HDL_OUTPUT + ix, tH = HDL_SAMPTIP + ix;
            h.Append("<tr><td>").Append(i + 1).Append("</td><td class='mono'>").Append(E(bc));
            h.Append("</td><td>").Append(wc).Append(" of 96</td>");
            h.Append("<td class='mono'>").Append(E(sH)).Append(" @ ").Append(E(Loc(sH)));
            h.Append("</td><td class='mono'>").Append(E(qH)).Append(" @ ").Append(E(Loc(qH)));
            h.Append("</td><td class='mono'>").Append(E(oH)).Append(" @ ").Append(E(Loc(oH)));
            h.Append("</td><td class='mono'>").Append(E(tH)).Append(" @ ").Append(E(Loc(tH))).Append("</td></tr>\n");
        }
        h.Append("</table>\n");
    }

    private string Loc(string handle) { return deck.ContainsKey(handle) ? deck[handle] : "not loaded"; }

    // ======================================================================================
    //  BARCODE HANDOFF - the values to paste into MM4, and what the alert did
    // ======================================================================================
    //  Jim's brief: validating barcodes by simulation is labour-heavy, so use a small worklist and
    //  copy the expected values out of this report into the MM4 logic (MM4 prompts for manual entry
    //  when a scan fails). These are therefore printed in MM4's OWN list form - a LEADING delimiter,
    //  per the KB d2-barcode-scanning convention - so a Begin Loop whose counter starts at 1 indexes
    //  the first real value. They paste in verbatim, with no editing.
    // ======================================================================================
    private void EmitBarcodeHandoff(StringBuilder h)
    {
        h.Append("<h2>Barcode validation - values to paste into MM4</h2>\n");

        h.Append("<h3>Alert sound</h3>\n<table class='kv'>\n");
        Kv(h, "What the alert did", alertLog);
        h.Append("</table>\n");

        if (!bridgeWritten)
        {
            h.Append("<p class='muted'>The run stopped before the bridge was written, so there are no ")
             .Append("expected barcode values for this run.</p>\n");
            return;
        }

        h.Append("<h3>Where to load, and which plates the run expects</h3>\n");
        h.Append("<div class='placeholder'><strong>Load the source plates into the positions listed below - ")
         .Append("IN ANY ORDER.</strong><br>The barcode column is the SET of plates this run expects, not an ")
         .Append("instruction about which plate goes where. Which barcode ends up in which position is your ")
         .Append("choice and is discovered by the barcode scan; the run is re-pointed to match what is ")
         .Append("actually found. Verify the positions with Show Worktable after loading.</div>\n");
        h.Append("<p class='muted'>One row per PLATE, not per sample - the arm visits each plate position once. ")
         .Append("Plate sets are contiguous from set 1.</p>\n");
        h.Append("<table><tr><th>Set</th><th>A source barcode this run expects</th><th>Source Loc</th>")
         .Append("<th>Quantification Loc</th><th>Output Loc</th></tr>\n");
        for (int i = 0; i < srcOrder.Count && i < MAX_SOURCE_PLATES; i++)
        {
            string ix = (i + 1).ToString("D2");
            h.Append("<tr><td>").Append(i + 1).Append("</td><td class='mono'><strong>").Append(E(srcOrder[i]))
             .Append("</strong></td><td class='mono'>").Append(E(Loc(HDL_SOURCE + ix)))
             .Append("</td><td class='mono'>").Append(E(Loc(HDL_LUNATIC + ix)))
             .Append("</td><td class='mono'>").Append(E(Loc(HDL_OUTPUT + ix))).Append("</td></tr>\n");
        }
        h.Append("</table>\n");

        h.Append("<h3>Paste-ready values</h3>\n");
        h.Append("<p class='muted'>Exactly as MM4 expects them, leading delimiter included. The variable ")
         .Append("names are what the validation script reads.</p>\n");
        h.Append("<table><tr><th>MM4 variable</th><th>Value to paste</th></tr>\n");
        var expBc = new List<string>(); var expSl = new List<string>();
        var expQl = new List<string>(); var expOl = new List<string>();
        var pSp = new List<string>(); var pQp = new List<string>();
        var pOp = new List<string>(); var pTb = new List<string>();
        for (int i = 0; i < srcOrder.Count && i < MAX_SOURCE_PLATES; i++)
        {
            string ix = (i + 1).ToString("D2");
            expBc.Add(srcOrder[i]); expSl.Add(Loc(HDL_SOURCE + ix));
            expQl.Add(Loc(HDL_LUNATIC + ix)); expOl.Add(Loc(HDL_OUTPUT + ix));
            pSp.Add(HDL_SOURCE + ix); pQp.Add(HDL_LUNATIC + ix);
            pOp.Add(HDL_OUTPUT + ix); pTb.Add(HDL_SAMPTIP + ix);
        }
        PasteRow(h, P_EXPSRCBC, LeadingList(expBc));
        PasteRow(h, P_SRCLOC,   LeadingList(expSl));
        PasteRow(h, P_QLOC,     LeadingList(expQl));
        PasteRow(h, P_OLOC,     LeadingList(expOl));
        PasteRow(h, P_COUNT,    expBc.Count.ToString());
        // v0.8.4 — the plate-major handle lists the method's own loops read. One element per plate
        // set, so a base-1 counter reads plate k at index k with no adjustment.
        PasteRow(h, L_SRCPLATE, LeadingList(pSp));
        PasteRow(h, L_QPLATE,   LeadingList(pQp));
        PasteRow(h, L_OPLATE,   LeadingList(pOp));
        PasteRow(h, L_TIPBOX,   LeadingList(pTb));
        // The stamp VI is shown here too, because it is the one value worth checking by eye: the
        // count of non-empty fields on a plate must equal the number of samples on that plate.
        // Rebuilt here from `samples` rather than read back from MM4 — this method has no app handle,
        // and rebuilding keeps the table honest if the write ever fails.
        var stampShowA = new List<string>(); var stampShowD = new List<string>();
        for (int i = 0; i < srcOrder.Count && i < MAX_SOURCE_PLATES; i++)
        {
            string handle = HDL_SOURCE + (i + 1).ToString("D2");
            var rp = new List<Sample>();
            for (int j = 0; j < samples.Count; j++) if (samples[j].SrcPlate == handle) rp.Add(samples[j]);
            stampShowA.Add(StampVI(rp, STAMP_ASPIRATE_UL, true));
            stampShowD.Add(StampVI(rp, STAMP_DISPENSE_UL));
        }
        PasteRow(h, L_QVI_ASP,  LeadingDashList(stampShowA));
        PasteRow(h, L_QVI_DISP, LeadingDashList(stampShowD));
        var qdShowA = new List<string>(); var qdShowD = new List<string>(); var qmShow = new List<string>();
        for (int i = 0; i < srcOrder.Count && i < MAX_SOURCE_PLATES; i++)
        {
            string handle = HDL_SOURCE + (i + 1).ToString("D2");
            var rp = new List<Sample>();
            for (int j = 0; j < samples.Count; j++) if (samples[j].SrcPlate == handle) rp.Add(samples[j]);
            qdShowA.Add(StampVI(rp, QDIL_UL, true)); qdShowD.Add(StampVI(rp, QDIL_UL)); qmShow.Add(StampVI(rp, QUANT_MIX_UL));
        }
        PasteRow(h, L_QDIL_ASP,  LeadingDashList(qdShowA));
        PasteRow(h, L_QDIL_DISP, LeadingDashList(qdShowD));
        PasteRow(h, L_QMIX,      LeadingDashList(qmShow));
        h.Append("</table>\n");
        h.Append("<p class='muted'>These are already written to MM4 by this script - the table is here so the ");
        h.Append("same values can be typed into a manual-entry prompt when a scan is simulated. <strong>The ORDER ");
        h.Append("of the barcode list carries no meaning</strong> - it is a set. The location lists DO carry ");
        h.Append("order: they are the order the arm visits the positions.</p>\n");
    }

    private static void PasteRow(StringBuilder h, string name, string val)
    {
        h.Append("<tr><td class='mono'>").Append(E(name)).Append("</td><td class='mono'><strong>")
         .Append(val.Length == 0 ? "<span class='muted'>(empty)</span>" : E(val)).Append("</strong></td></tr>\n");
    }

    // ======================================================================================
    //  WORKTABLE REBUILD  (reference workflow v28 D105 model, adapted to an authored deck)
    // ======================================================================================
    //  REMOVE ONLY. Every run inherits the authored deck - MM4 reverts any runtime worktable change
    //  when the method exits (KB mm4-worktable-reference.md v1.1.0: "Runtime worktable modifications
    //  revert on method exit ... programmatic worktable mutation from a script ... do not persist").
    //  So this takes off what the worklist does not use, and never puts anything on. If a required
    //  plate is genuinely absent, that is a real deck problem and must surface as DECK_MISMATCH
    //  rather than being silently replaced.
    //
    //  Only the four INDEXED families are managed. Diluent and Diluent_Tips_01 are single fixed
    //  items this method always needs and are never touched.
    // ======================================================================================
    private static readonly string[] INDEXED_FAMILIES = new string[] { HDL_SOURCE, HDL_LUNATIC, HDL_OUTPUT, HDL_SAMPTIP };

    private void RebuildWorktable(IMMApp app, int platesNeeded)
    {
        // The deck this run inherits is always the authored one - MM4 reverts any runtime worktable
        // change when the method exits (KB: mm4-worktable-reference.md, "Runtime worktable
        // modifications revert on method exit"). So this only ever needs to REMOVE what the worklist
        // does not use. Nothing is ever added: if a required plate is genuinely absent, that is a real
        // deck problem and must surface as DECK_MISMATCH rather than being papered over.
        var want = new HashSet<string>();
        for (int i = 1; i <= platesNeeded; i++)
            foreach (string fam in INDEXED_FAMILIES) want.Add(fam + i.ToString("D2"));

        foreach (DeckPos d in deckPos)
        {
            if (!d.Occupied || d.Plate.Length == 0) continue;
            if (!IsIndexed(d.Plate)) continue;          // Diluent + Diluent_Tips are always needed
            if (want.Contains(d.Plate)) { rebuildKept.Add(d.Plate); continue; }
            try { app.RemovePlateFromWorktable(wtDevice, wtName, d.Plate); rebuildRemoved.Add(d.Plate); }
            catch (Exception ex) { rebuildErrors.Add("remove " + d.Plate + ": " + ex.Message); }
        }
    }

    static bool IsIndexed(string plate)
    {
        foreach (string fam in INDEXED_FAMILIES) if (plate.StartsWith(fam)) return true;
        return false;
    }



    private void EmitRebuild(StringBuilder h)
    {
        h.Append("<h3>Worktable rebuilt for this worklist</h3>\n");
        h.Append("<p>The worklist needs <strong>").Append(platesRequired).Append(" source plate");
        h.Append(platesRequired == 1 ? "" : "s").Append("</strong>, so the deck was rebuilt to carry exactly that. ");
        h.Append("Unused plates are taken off for the run. Nothing is ever added: MM4 restores the authored deck ");
        h.Append("when the method exits, so a plate that is genuinely missing is a real deck problem and is reported ");
        h.Append("as such rather than quietly replaced.</p>\n");
        h.Append("<table><tr><th>Action</th><th>Labware</th></tr>\n");
        Row2(h, "Kept", rebuildKept);
        Row2(h, "Removed - not needed by this worklist", rebuildRemoved);
        if (rebuildErrors.Count > 0) Row2(h, "PROBLEMS", rebuildErrors);
        h.Append("</table>\n");
        if (rebuildErrors.Count == 0)
            h.Append("<p class='pass'>Deck matches the worklist: ").Append(platesRequired)
             .Append(" source / quantification / output set").Append(platesRequired == 1 ? "" : "s")
             .Append(" plus the diluent reservoir and diluent tips.</p>\n");
    }

    private static void Row2(StringBuilder h, string label, List<string> items)
    {
        h.Append("<tr><td>").Append(E(label)).Append("</td><td class='mono'>");
        h.Append(items.Count == 0 ? "<span class='muted'>none</span>" : E(string.Join(", ", items.ToArray())));
        h.Append("</td></tr>\n");
    }

    // ======================================================================================
    //  RE-DERIVE THE DECK FROM THE INSTRUMENT (not from the method's snapshot)
    // ======================================================================================
    //  User.OutputWorktable_01 is written once, by the method's "Output Worktable" command, before
    //  this script runs. Script-side Add/RemovePlateFromWorktable calls change MM4's worktable but
    //  NOT that variable - so after a rebuild the variable is stale by definition.
    //
    //  Positions + coordinates : machine worktable config (all locations, including empty ones)
    //  Occupancy               : QueryLocationStack, live, per location
    //  Labware type            : the preserved authored template
    //
    //  If the live query yields nothing at all, the snapshot is used instead and deckSource records
    //  that, so the report can never present a stale picture as a live one.
    // ======================================================================================
    private Dictionary<string, string> RefreshDeckFromInstrument(IMMApp app, string workspaceDir)
    {
        var map = new Dictionary<string, string>();
        var fresh = new List<DeckPos>();
        int found = 0;

        // every location the machine has, with its real coordinates
        var allLocs = new List<DeckPos>();
        try
        {
            string cfgDir = Path.Combine(workspaceDir, "Configuration");
            string path = null;
            if (Directory.Exists(cfgDir))
            {
                string preferred = Path.Combine(cfgDir, wtDevice + "." + wtName + ".Worktable.config");
                if (File.Exists(preferred)) path = preferred;
                else foreach (string cnd in Directory.GetFiles(cfgDir, "*.Worktable.config"))
                    if (Path.GetFileName(cnd).IndexOf(".ToolFilter.", StringComparison.OrdinalIgnoreCase) < 0) { path = cnd; break; }
            }
            if (path != null)
            {
                string raw = File.ReadAllText(path);
                foreach (Match m in Regex.Matches(raw, @"<MMLocation>(.*?)</MMLocation>", RegexOptions.Singleline))
                {
                    string b = m.Groups[1].Value, nm = One(b, "Name");
                    if (!nm.StartsWith("Loc_")) continue;
                    allLocs.Add(new DeckPos { Loc = nm, Occupied = false,
                        X = Num(One(b, "XPos")), Y = Num(One(b, "YPos")), Z = Num(One(b, "ZPos")) });
                }
            }
        }
        catch (Exception) { }

        foreach (DeckPos d in allLocs)
        {
            string plate = "";
            try
            {
                string[] stack = app.QueryLocationStack(wtDevice, wtName, d.Loc);
                if (stack != null)
                    foreach (string entry in stack)
                        if (entry != null && entry.Trim().Length > 0) { plate = entry.Trim(); break; }
            }
            catch (Exception) { }

            if (plate.Length > 0)
            {
                d.Occupied = true; d.Plate = plate; found++;
                // labware type: carried over from the pre-rebuild read of the same plate
                foreach (DeckPos prev in deckPos)
                    if (prev.Plate == plate && prev.Labware.Length > 0) { d.Labware = prev.Labware; break; }
                if (!map.ContainsKey(plate)) map[plate] = d.Loc;
            }
            fresh.Add(d);
        }

        if (found > 0 && allLocs.Count > 0)
        {
            deckPos = fresh;
            deckSource = "live instrument query (QueryLocationStack) after the worktable rebuild";
            return map;
        }

        // fall back to the pre-rebuild snapshot, and say so
        deckSource = "method snapshot (User.OutputWorktable_01) - LIVE QUERY RETURNED NOTHING, so this "
                   + "picture predates the rebuild";
        var fallback = ParseWorktable(SafeGet(app, V_WORKTBL));
        LoadEmptyPositions(workspaceDir);
        return fallback;
    }

    // One problem, rendered so the reader never has to hunt: what, where (every row involved),
    // where physically, why it matters, and the exact edit to make. Survives print-to-PDF.
    private void EmitProblem(StringBuilder h, RowIssue ri, int n, int total)
    {
        h.Append("<div class='prob'><div class='prob-hd'><span>PROBLEM ").Append(n).Append(" of ").Append(total)
         .Append(" &mdash; ").Append(E(ri.What)).Append("</span><span>");
        if (ri.Rows.Count > 0)
        {
            h.Append("sample row").Append(ri.Rows.Count > 1 ? "s " : " ");
            for (int i = 0; i < ri.Rows.Count; i++)
            { if (i > 0) h.Append(i == ri.Rows.Count - 1 ? " and " : ", "); h.Append("<span class='ping'>").Append(ri.Rows[i]).Append("</span>"); }
        }
        h.Append("</span></div><div class='prob-bd'><div class='prob-txt'><dl>");

        h.Append("<dt>WHERE IN THE WORKLIST</dt><dd>");
        if (ri.Rows.Count > 1)
        {
            h.Append("Sample rows <strong>");
            for (int i = 0; i < ri.Rows.Count; i++) { if (i > 0) h.Append("</strong> and <strong>"); h.Append(ri.Rows[i]); }
            h.Append("</strong> &mdash; <em>both</em> need looking at.");
        }
        else h.Append("Sample row <strong>").Append(ri.RowNo).Append("</strong>.");
        if (ri.Column.Length > 0)
        {
            h.Append(" Column <span class='mono'>").Append(E(ri.Column)).Append("</span>");
            if (ri.Value.Length > 0) h.Append(", value <span class='mono'><strong>").Append(E(ri.Value)).Append("</strong></span>");
            h.Append(".");
        }
        h.Append("</dd>");

        if (ri.Plate.Length > 0)
        {
            h.Append("<dt>WHERE TO FIND IT PHYSICALLY</dt><dd>Plate <span class='mono'>").Append(E(ri.Plate)).Append("</span>");
            if (ri.Handle.Length > 0)
            {
                h.Append(" sits at <span class='mono'>").Append(E(ri.Handle)).Append("</span>");
                if (ri.Loc.Length > 0)
                {
                    h.Append(", deck position <span class='mono'>").Append(E(ri.Loc)).Append("</span>");
                    int cno, rno;
                    if (LocRC(ri.Loc, out cno, out rno))
                        h.Append(" &mdash; column ").Append(cno).Append(", row ").Append(rno).Append(" counting from the front of the deck");
                }
            }
            else h.Append(" is not currently on the deck");
            if (ri.Well.Length > 0) h.Append(". Well <span class='mono'><strong>").Append(E(ri.Well)).Append("</strong></span> is ringed on the map.");
            else h.Append(".");
            h.Append("</dd>");
        }

        if (ri.Why.Length > 0) h.Append("<dt>WHY THIS STOPS THE RUN</dt><dd>").Append(E(ri.Why)).Append("</dd>");
        if (ri.Fix.Length > 0) h.Append("<dt>HOW TO CORRECT IT</dt><dd>").Append(E(ri.Fix)).Append("</dd>");
        h.Append("</dl></div>");

        if (ri.Well.Length > 0) h.Append(WellMap(ri.Well));
        h.Append("</div></div>\n");
    }

    // 96-well map (8 x 12, A1 top-left) with the offending well ringed. Static, no script, prints.
    private static string WellMap(string well)
    {
        string target = (well ?? "").Trim().ToUpperInvariant();
        var sb = new StringBuilder();
        sb.Append("<div><table class='wellmap'><tr><td></td>");
        for (int c = 1; c <= 12; c++) sb.Append("<td class='lbl'>").Append(c).Append("</td>");
        sb.Append("</tr>");
        string rows = "ABCDEFGH";
        for (int r = 0; r < 8; r++)
        {
            sb.Append("<tr><td class='lbl'>").Append(rows[r]).Append("</td>");
            for (int c = 1; c <= 12; c++)
            {
                string id = rows[r].ToString() + c.ToString();
                bool hit = id == target;
                sb.Append("<td><i class='").Append(hit ? "hit" : "").Append("'></i></td>");
            }
            sb.Append("</tr>");
        }
        sb.Append("</table><div class='lbl' style='text-align:center;margin-top:3px'>");
        sb.Append(E(target)).Append(" on the source plate</div></div>");
        return sb.ToString();
    }

    // ======================================================================================
    //  THE WORKLIST, RECREATED FROM THE FILE
    // ======================================================================================
    //  Re-read from disk at report time and reproduced as it is. Nothing is inferred: the column
    //  names and their order come from the file's own header row, cells are printed exactly as
    //  written (no trimming, no reformatting, no reordering), and the comment / header-block lines
    //  above the table are shown verbatim.
    //
    //  Both numbering schemes are shown because they differ and confusing them causes a hunt:
    //    FILE LINE  - what Excel or a text editor shows
    //    SAMPLE ROW - what the problem panels count (data rows only)
    // ======================================================================================
    private void EmitWorklistAsRead(StringBuilder h)
    {
        h.Append("<h2>The worklist, as it is in the file</h2>\n");
        if (wlFile.Length == 0) { h.Append("<p class='muted'>No worklist was selected.</p>\n"); return; }

        string[] raw;
        long bytes = 0;
        try { raw = Qn.ReadRecords(wlFile).ToArray(); bytes = new FileInfo(wlFile).Length; }
        catch (Exception ex) { h.Append("<p class='fail'>Could not re-read the worklist: ").Append(E(ex.Message)).Append("</p>\n"); return; }

        var preamble = new List<string>();   // "fileLine\ttext"
        List<string> cols = null;
        int colHeaderLine = -1;
        var data = new List<string>();       // "fileLine\tsampleRow\tcells..."
        int sampleRow = 0;

        int physicalLine = 1;
        for (int i = 0; i < raw.Length; i++)
        {
            string line = raw[i];
            int fileLine = physicalLine;
            physicalLine += line.Replace("\r\n", "\n").Replace("\r", "\n").Count(ch => ch == '\n') + 1;
            string t = line.TrimEnd();
            if (t.Length == 0) continue;
            if (cols == null)
            {
                bool isHeader = false;
                foreach (string c in Qn.Fields(t, ','))
                { string k = Key(c); if (k == "sourceplatebarcode" || k == "sourcewell") { isHeader = true; break; } }
                if (isHeader && !t.TrimStart().StartsWith("#"))
                { cols = new List<string>(Qn.Fields(t, ',')); colHeaderLine = fileLine; continue; }
                preamble.Add(fileLine + "\t" + t);
                continue;
            }
            sampleRow++;
            data.Add(fileLine + "\t" + sampleRow + "\t" + t);
        }

        h.Append("<table class='kv'>\n");
        Kv(h, "File", wlFile);
        Kv(h, "Size", bytes + " bytes");
        Kv(h, "Lines in file", File.ReadAllLines(wlFile).Length.ToString());
        Kv(h, "Header / comment lines", preamble.Count.ToString());
        Kv(h, "Column header row", colHeaderLine > 0 ? "file line " + colHeaderLine : "not found");
        Kv(h, "Columns", cols == null ? "-" : cols.Count.ToString());
        Kv(h, "Sample rows", data.Count.ToString());
        h.Append("</table>\n");

        if (preamble.Count > 0)
        {
            h.Append("<h3>Header block and comments, verbatim</h3>\n<table><tr><th style='width:70px'>File line</th><th>Text</th></tr>\n");
            foreach (string p in preamble)
            {
                int tab = p.IndexOf('\t');
                h.Append("<tr><td class='mono'>").Append(p.Substring(0, tab)).Append("</td><td class='mono'>")
                 .Append(E(p.Substring(tab + 1))).Append("</td></tr>\n");
            }
            h.Append("</table>\n");
        }

        if (cols == null) { h.Append("<p class='fail'>No column header row was found, so there is no table to show.</p>\n"); return; }

        h.Append("<h3>Sample rows</h3>\n");
        h.Append("<p class='muted'>Column names and order are the file's own. Cells are printed exactly as written - "
               + "nothing trimmed, reformatted or reordered. <strong>File line</strong> is what a text editor shows; "
               + "<strong>sample row</strong> is what the problem panels count.</p>\n");
        h.Append("<div class='wl-wrap'><table class='wl'>\n<tr><th>File line</th><th>Sample row</th>");
        foreach (string c in cols) h.Append("<th>").Append(E(c)).Append("</th>");
        h.Append("</tr>\n");

        foreach (string d in data)
        {
            string[] bits = d.Split(new char[] { '\t' }, 3);
            int fl = int.Parse(bits[0]), sr = int.Parse(bits[1]);
            string[] cells = Qn.Fields(bits[2], ',');
            bool flagged = problemRowIndex.ContainsKey(sr);
            h.Append(flagged ? "<tr class='wl-bad'>" : "<tr>");
            h.Append("<td class='mono'>").Append(fl).Append("</td><td class='mono'>");
            if (flagged)
            {
                var ps = problemRowIndex[sr];
                var tipTxt = new StringBuilder();
                for (int i = 0; i < ps.Count; i++)
                {
                    if (i > 0) tipTxt.Append("\n\n----------------\n\n");
                    if (problemTip.ContainsKey(ps[i])) tipTxt.Append(problemTip[ps[i]]);
                }
                string tt = Attr(tipTxt.ToString());
                h.Append("<span class='ping hint' title=\"").Append(tt).Append("\">").Append(sr).Append("</span> ");
                h.Append("<span class='wl-tag hint' title=\"").Append(tt).Append("\">problem ");
                for (int i = 0; i < ps.Count; i++) { if (i > 0) h.Append(", "); h.Append(ps[i]); }
                h.Append("</span>");
            }
            else h.Append(sr);
            h.Append("</td>");
            for (int i = 0; i < cols.Count; i++)
            {
                string v = i < cells.Length ? cells[i] : "";
                h.Append("<td>").Append(v.Length == 0 ? "" : E(v)).Append("</td>");
            }
            h.Append("</tr>\n");
        }
        h.Append("</table></div>\n");
        if (data.Count > 0 && problemRowIndex.Count > 0)
            h.Append("<p class='muted'>Highlighted rows are the ones named in the problem panels above. "
                   + "<strong>Hover the row number or the problem tag</strong> to see what is wrong and how to fix it "
                   + "without scrolling back up.</p>\n");
    }

    // Plain-text tooltip for a flagged worklist row: what, where, why, how to fix.
    // Kept to the same wording as the panel so the two never drift apart.
    private static string BuildTip(int n, RowIssue ri)
    {
        var t = new StringBuilder();
        t.Append("PROBLEM ").Append(n).Append(" - ").Append(ri.What);
        if (ri.Rows.Count > 1)
        {
            t.Append("\n\nWHERE: sample rows ");
            for (int i = 0; i < ri.Rows.Count; i++)
            { if (i > 0) t.Append(i == ri.Rows.Count - 1 ? " and " : ", "); t.Append(ri.Rows[i]); }
            t.Append(" (both)");
        }
        else t.Append("\n\nWHERE: sample row ").Append(ri.RowNo);
        if (ri.Column.Length > 0)
        {
            t.Append(", column ").Append(ri.Column);
            if (ri.Value.Length > 0) t.Append(" = ").Append(ri.Value);
        }
        if (ri.Plate.Length > 0)
        {
            t.Append("\n\nON THE DECK: plate ").Append(ri.Plate);
            if (ri.Handle.Length > 0)
            {
                t.Append(" at ").Append(ri.Handle);
                if (ri.Loc.Length > 0) t.Append(" (").Append(ri.Loc).Append(")");
            }
            else t.Append(" - not currently loaded");
            if (ri.Well.Length > 0) t.Append(", well ").Append(ri.Well);
        }
        if (ri.Why.Length > 0) t.Append("\n\nWHY: ").Append(ri.Why);
        if (ri.Fix.Length > 0) t.Append("\n\nFIX: ").Append(ri.Fix);
        return t.ToString();
    }

    // Escape for use inside an HTML attribute: quotes must go, and newlines become &#10; so the
    // browser renders a multi-line tooltip.
    private static string Attr(string v)
    {
        return (v ?? "").Replace("&", "&amp;").Replace("<", "&lt;").Replace(">", "&gt;")
                        .Replace("\"", "&quot;").Replace("'", "&#39;")
                        .Replace("\r\n", "&#10;").Replace("\n", "&#10;");
    }

    // Group near-identical coordinates into axis lines, ordered DESCENDING (left..right / front..back).
    static List<double> Cluster(List<double> vals, double tol)
    {
        var outp = new List<double>();
        var srt = vals.Distinct().OrderByDescending(z => z).ToList();
        foreach (double v in srt)
            if (outp.Count == 0 || Math.Abs(v - outp[outp.Count - 1]) > tol) outp.Add(v);
        return outp;
    }
    static int Nearest(List<double> axis, double v)
    {
        int best = -1; double bd = double.MaxValue;
        for (int i = 0; i < axis.Count; i++) { double dd = Math.Abs(axis[i] - v); if (dd < bd) { bd = dd; best = i; } }
        return best;
    }

    static string F(double v) { return v.ToString("0.##", System.Globalization.CultureInfo.InvariantCulture); }
    static string Clip(string t, int n) { return (t ?? "").Length <= n ? (t ?? "") : t.Substring(0, n - 1) + "…"; }


    private static readonly string[] REPAIR_RESET = new string[] {
        "User.Site_01", "User.DiluentIdentity_01", "User.OperatorID_01", "User.WorklistVersion_01",
        "User.SourceWorklistHash_01", "User.InputSnapshotFile_01", "User.RunStartTimestamp_01",
        "User.RunRecordFile_01", "User.NormalizationCheck_01", "User.AllNormalizationCheck_01",
        "User.NormalizationPlateStatus_List_01", "User.NormalizationPlateRun_List_01",
        "User.RowDisposition_List_01", "User.RowCalculationTimestamp_List_01", "User.RowCalculationNote_List_01",
        "User.CurrentPlateIndex_01", "User.ReaderPreparedRun_01", "User.ReaderPreparedPlate_01",
        "User.ReaderPreparedUtc_01", "User.ReaderExpectedPlateID_01", "User.ReaderDataSource_01",
        "User.ReaderPayloadHash_List_01", "User.GuardStage_01", "User.OutputReportCheck_01",
        "User.ReaderDataSource_List_01", "User.SyntheticApprovedRun_01", "User.GuardHasLiquid_01", "User.Quant_Return_VI_01",
        "User.BarcodeAuditFile_01", "User.OutputWellCapacity_01", "User.TipWorkingCapacity_01",
        "User.Sample_Aspirate_VI_01", "User.Sample_Dispense_VI_01",
        "User.Diluent_Aspirate_VI_01", "User.Diluent_Dispense_VI_01",
        "User.Sample_Aspirate_VI_List_01", "User.Sample_Dispense_VI_List_01",
        "User.Diluent_Aspirate_VI_List_01", "User.Diluent_Dispense_VI_List_01",
        "User.QuantAsp_VO_List_01", "User.QuantDisp_VO_List_01",
        "User.Sample_Aspirate_VO_List_01", "User.Sample_Dispense_VO_List_01",
        "User.Diluent_Aspirate_VO_List_01", "User.Diluent_Dispense_VO_List_01",
        "ReadPlateResult", "User.ReadPlateResult", "User.ReadPlateResult_01",
        "ReadPlateResultPath", "User.ReadPlateResultPath", "User.ReadPlateResultPath_01"
    };
    private void ResetRepairState(IMMApp app)
    {
        samples.Clear(); srcOrder.Clear(); issues.Clear(); badLocs.Clear(); fileHeader.Clear();
        colNames.Clear(); deckPos.Clear(); rebuildKept.Clear(); rebuildRemoved.Clear(); rebuildErrors.Clear();
        problemRowIndex.Clear(); problemTip.Clear(); paramsWritten = false; bridgeWritten = false;
        failCode = ""; failMsg = ""; wlFile = "";
        foreach (string name in REPAIR_RESET) Qn.Write(app, name, "");
    }
    private void SeedRepairLists(IMMApp app, int rows, int plates)
    {
        Qn.Write(app, "User.RowDisposition_List_01", "," + string.Join(",", Enumerable.Repeat("PENDING", rows).ToArray()));
        Qn.Write(app, "User.RowCalculationTimestamp_List_01", new string(',', rows));
        Qn.Write(app, "User.RowCalculationNote_List_01", new string(',', rows));
        foreach (string name in new string[] { "User.NormalizationPlateStatus_List_01", "User.NormalizationPlateRun_List_01", "User.ReaderPayloadHash_List_01", "User.ReaderDataSource_List_01" })
            Qn.Write(app, name, new string(',', plates));
        foreach (string name in new string[] { "User.Sample_Aspirate_VI_List_01", "User.Sample_Dispense_VI_List_01", "User.Diluent_Aspirate_VI_List_01", "User.Diluent_Dispense_VI_List_01" })
            Qn.Write(app, name, new string('-', plates));
        Qn.Write(app, "User.BarcodeAuditFile_01", Path.Combine(reportDir, "QuantNorm_barcode_audit_" + runId + ".txt"));
    }
    // v0.8.9 — SpectraMax quant plate and reader configuration. Header keys are optional; a missing key
    // takes the documented default EXCEPT ReaderPathlengthCm, which has none on purpose: an invented
    // pathlength would scale every concentration on the run. ReaderNormVI requires either this value or
    // a per-well pathlength column in the export (PathCheck), and stops if it has neither.
    private void ApplyQuantAndReaderConfig(IMMApp app, Dictionary<string, string> fileHeader)
    {
        var ci = System.Globalization.CultureInfo.InvariantCulture;
        double s = QUANT_SAMPLE_DEFAULT_UL, d = QUANT_DILUENT_DEFAULT_UL, v;
        string rs = Hdr(fileHeader, "QuantSampleVolume(uL)"); if (rs.Length == 0) rs = Hdr(fileHeader, "QuantSampleVolume");
        string rd = Hdr(fileHeader, "QuantDiluentVolume(uL)"); if (rd.Length == 0) rd = Hdr(fileHeader, "QuantDiluentVolume");
        if (rs.Length > 0) { Qn.Require(Qn.TryNumber(rs, out v) && v > 0, "Invalid QuantSampleVolume: " + rs); s = v; }
        if (rd.Length > 0) { Qn.Require(Qn.TryNumber(rd, out v) && v > 0, "Invalid QuantDiluentVolume: " + rd); d = v; }
        Qn.Require(s >= 2.0 && d >= 2.0, "Quant sample and diluent volumes must each be at least the 2 uL VVP96 floor.");
        Qn.Require(s + d <= QUANT_WELL_MAX_UL, "Quant sample + diluent exceeds the quant-plate well capacity ("
            + QUANT_WELL_MAX_UL.ToString("0", ci) + " uL).");
        STAMP_ASPIRATE_UL = s; STAMP_DISPENSE_UL = s; QDIL_UL = d;
        app.SetVariable("User.QuantSampleVolume_01", s.ToString("0.##", ci));
        app.SetVariable("User.QuantDiluentVolume_01", d.ToString("0.##", ci));
        app.SetVariable("User.QuantDilutionFactor_01", ((s + d) / s).ToString("0.####", ci));

        string model = Hdr(fileHeader, "ReaderModel");
        app.SetVariable("User.ReaderModel_01", model.Length > 0 ? model : "SpectraMax");
        string path = Hdr(fileHeader, "ReaderPathlengthCm");
        if (path.Length > 0) Qn.Require(Qn.TryNumber(path, out v) && v > 0 && v <= 1.0, "ReaderPathlengthCm must be in (0, 1] cm: " + path);
        app.SetVariable("User.ReaderPathlengthCm_01", path);
        string low = Hdr(fileHeader, "ReaderLowSignalOD");
        if (low.Length > 0) Qn.Require(Qn.TryNumber(low, out v) && v >= 0, "Invalid ReaderLowSignalOD: " + low);
        app.SetVariable("User.ReaderLowSignalOD_01", low.Length > 0 ? low : "0.01");
        app.SetVariable("User.BlankMethod_01", "PerWellPreRead");
        string ptype = Hdr(fileHeader, "QuantPlateType");
        app.SetVariable("User.QuantPlateType_01", ptype.Length > 0 ? ptype : "96-well half-area UV plate (part number TBD)");
    }

    private void ValidateHeaderNumbers(IMMApp app)
    {
        foreach (string variable in new string[] { V_EXTCOEF, V_TARGET, V_OUTVOL, "User.OutputWellCapacity_01", "User.TipWorkingCapacity_01" })
        {
            string raw = SafeGet(app, variable); double number;
            if (raw.Length == 0 && variable != V_OUTVOL) continue;
            Qn.Require(Qn.TryNumber(raw, out number) && number > 0, "Invalid positive finite value for " + variable + ": " + raw);
        }
        double output, capacity;
        string accept = SafeGet(app, V_ACCEPT).Replace(" ", "").Replace("_", "").Replace("-", "").ToLowerInvariant();
        Qn.Require(accept.Length == 0 || accept == "average" || accept == "flagondisagreement",
            "A260AcceptanceLogic must be Average or FlagOnDisagreement. BestOfTwo has no defined rule in the supplied specification.");
        Qn.TryNumber(SafeGet(app, V_OUTVOL), out output);
        Qn.TryNumber(SafeGet(app, "User.OutputWellCapacity_01"), out capacity);
        Qn.Require(output <= capacity, "RequestedOutputVolume exceeds the configured output-well capacity.");
    }


    // Shared, self-contained helpers. Kept in each script: no extra runtime DLL is required.
    private static class Qn
    {
        public static string Get(IMMApp app, string name)
        { try { return app.GetVariableValue(name) ?? ""; } catch (Exception) { return ""; } }
        public static void Write(IMMApp app, string name, string value)
        {
            app.SetVariable(name, value ?? "");
            if (!string.Equals(app.GetVariableValue(name) ?? "", value ?? "", StringComparison.Ordinal))
                throw new InvalidOperationException("MM4 variable did not retain its assigned value: " + name);
        }
        public static void Require(bool condition, string message)
        { if (!condition) throw new InvalidOperationException(message); }
        public static bool Finite(double value)
        { return !double.IsNaN(value) && !double.IsInfinity(value); }
        public static bool TryNumber(string text, out double value)
        {
            return double.TryParse((text ?? "").Trim(), System.Globalization.NumberStyles.Float,
                System.Globalization.CultureInfo.InvariantCulture, out value) && Finite(value);
        }
        public static string Number(double value)
        { return value.ToString("0.################", System.Globalization.CultureInfo.InvariantCulture); }
        public static string Well(string text)
        {
            string s = (text ?? "").Trim().ToUpperInvariant();
            int c;
            if (s.Length < 2 || s.Length > 3 || s[0] < 'A' || s[0] > 'H') return "";
            for (int i = 1; i < s.Length; i++) if (s[i] < '0' || s[i] > '9') return "";
            if (!int.TryParse(s.Substring(1), out c) || c < 1 || c > 12) return "";
            return s.Substring(0, 1) + c.ToString("00");
        }
        public static int Channel(string well)
        {
            string w = Well(well);
            return w.Length == 0 ? -1 : (w[0] - 'A') * 12 + int.Parse(w.Substring(1));
        }
        public static List<string> List(string raw, char separator)
        {
            var result = new List<string>();
            if (string.IsNullOrEmpty(raw)) return result;
            string[] parts = raw.Split(separator);
            int start = parts[0].Length == 0 ? 1 : 0;
            for (int i = start; i < parts.Length; i++) result.Add(parts[i]);
            return result;
        }
        public static string At(List<string> values, int index)
        { return index >= 0 && index < values.Count ? values[index] : ""; }
        public static void PlateValue(IMMApp app, string variable, int index, int count, string value, char separator)
        {
            Require(index >= 1 && index <= count && count <= 4, "Invalid plate index for " + variable);
            var prior = List(Get(app, variable), separator);
            Require(prior.Count <= count, "Too many plate entries in " + variable + ". Start from ingestion.");
            while (prior.Count < count) prior.Add("");
            prior[index - 1] = value ?? "";
            Write(app, variable, separator.ToString() + string.Join(separator.ToString(), prior.ToArray()));
        }
        public static void SafeToken(string value, string description)
        {
            Require(!string.IsNullOrEmpty(value) && value.IndexOfAny(new char[] { ',', '|', '&', '\r', '\n', '\t' }) < 0,
                description + " is empty or contains a reserved MM4 list delimiter.");
        }
        public static string HashBytes(byte[] data)
        {
            using (var sha = System.Security.Cryptography.SHA256.Create())
                return BitConverter.ToString(sha.ComputeHash(data)).Replace("-", "").ToLowerInvariant();
        }
        public static string HashFile(string path) { return HashBytes(File.ReadAllBytes(path)); }
        public static void CheckWorklist(IMMApp app)
        {
            string p = Get(app, "User.WorklistFile_01"), h = Get(app, "User.SourceWorklistHash_01");
            Require(h.Length > 0 && File.Exists(p) && HashFile(p) == h,
                "The worklist is missing or changed after ingestion. Start a new run; current results must not be paired with changed input.");
        }
        public static List<string> ReadRecords(string path) { return Records(File.ReadAllText(path)); }
        public static List<string> Records(string text)
        {
            var result = new List<string>();
            var b = new StringBuilder();
            bool quoted = false;
            string s = (text ?? "").TrimStart('\uFEFF');
            for (int i = 0; i < s.Length; i++)
            {
                char c = s[i];
                if (c == '"')
                {
                    b.Append(c);
                    if (quoted && i + 1 < s.Length && s[i + 1] == '"') { b.Append(s[++i]); continue; }
                    // Comments and header preambles are plain text, not CSV records.
                    if (!b.ToString().TrimStart().StartsWith("#")) quoted = !quoted;
                }
                else if ((c == '\r' || c == '\n') && !quoted)
                {
                    result.Add(b.ToString()); b.Length = 0;
                    if (c == '\r' && i + 1 < s.Length && s[i + 1] == '\n') i++;
                }
                else b.Append(c);
            }
            Require(!quoted, "Unterminated quoted field in the input file.");
            if (b.Length > 0) result.Add(b.ToString());
            return result;
        }
        public static string[] Fields(string record, char separator)
        {
            var result = new List<string>(); var cell = new StringBuilder();
            bool quoted = false, closed = false;
            string s = record ?? "";
            // Preambles/comments are not CSV: callers retain them verbatim.
            if (s.TrimStart().StartsWith("#") || (s.IndexOf(separator) < 0 && s.IndexOf(':') > 0)) return new string[] { s };
            for (int i = 0; i < s.Length; i++)
            {
                char c = s[i];
                if (quoted)
                {
                    if (c == '"')
                    {
                        if (i + 1 < s.Length && s[i + 1] == '"') { cell.Append('"'); i++; }
                        else { quoted = false; closed = true; }
                    }
                    else cell.Append(c);
                }
                else if (c == separator) { result.Add(cell.ToString()); cell.Length = 0; closed = false; }
                else if (c == '"')
                {
                    Require(!closed && cell.ToString().Trim().Length == 0, "Unexpected quote in a delimited field.");
                    cell.Length = 0; quoted = true;
                }
                else if (closed) Require(char.IsWhiteSpace(c), "Unexpected text following a quoted field.");
                else cell.Append(c);
            }
            Require(!quoted, "Unterminated quoted field."); result.Add(cell.ToString());
            return result.ToArray();
        }
    }

}
