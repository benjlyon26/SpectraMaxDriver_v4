﻿using System;
using System.Linq;
using System.Text;
using System.IO;
using System.Diagnostics;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;
using MethodManager.Core;
using MMScriptObjects;

// ============================================================================
// QuantNorm_ReaderNormVI — Track B (LM900) In-Vivo RNA Quant/Norm, script 3 of the spine
// ============================================================================
// WHAT IT DOES, IN ONE LINE: reads the Lunatic's Get Results payload for ONE plate, computes the
// per-well normalization volumes the spec defines, and writes them out as VI strings the VVP96
// Aspirate/Dispense commands can consume.
//
// ---------------------------------------------------------------------------------------------
// VERSION BAND — WHY THIS STARTS AT v0.20.0 AND NOT v0.1.0
// ---------------------------------------------------------------------------------------------
//   D-S18-23: the spine scripts must NEVER share a version number. That decision has a cause — on
//   2026-07-29 step [75] was pointed at QuantNorm_WorklistIngestion_v0.8.3.cs instead of
//   QuantNorm_BarcodeValidation_v0.8.3.cs, because TEN version numbers existed as both scripts and
//   in a file picker the eye anchors on the version, not the prefix.
//   Ingestion holds 0.1.0-0.8.3. Barcode validation holds 0.1.0-0.9.2. Starting this script at
//   0.1.0 would recreate the exact collision; starting it at 0.10.0 would collide the moment
//   barcode validation bumps past 0.9.x. So the spine now uses BANDS:
//       ingestion 0.0.x-0.8.x  ·  barcode validation 0.9.x-0.19.x  ·  THIS 0.20.x-0.29.x
//   and the output-report script (4) takes 0.30.x. One glance at a version says which script it is.
//
// ---------------------------------------------------------------------------------------------
// VERSION HISTORY (why-first)
// ---------------------------------------------------------------------------------------------
//   v0.20.0  2026-07-30  First build. Designed in S19
//                        (planning/apps-dev-workflow/reader-ingest-norm-vi-design-2026-07-29.md),
//                        built S20 after Jim deferred the SR-710 / read-height questions to the
//                        on-site visit and said he would wire the reader with PLACEHOLDERS so the
//                        basic logic could still be tested.
//
//   ONE PLATE PER INVOCATION, AND THAT IS NOT AN ARBITRARY CHOICE. The MM4 plug-in command is
//   Get Result [ResultParams, PlateID, ReadPlateResult, ReadPlateResultPath] — PlateID is an
//   IN-parameter (knowledge-base/references/mm4-lunatic-plugin-reference.md:171). The reader call
//   is therefore per plate by construction, which also matches NORM-006 ("normalization for each
//   Source Plate as a one-pass operation per plate ... serial across the run"). Handling one plate
//   per call means this script never has to solve "which reader plate is which quant plate" across
//   a multi-plate run — a problem that has no answer in any document we hold.
//
//   POSITION-INDEPENDENT. It reads variables and writes variables. It does not care where in the
//   method it sits, so Jim's resequence cannot break it, and no [n] step index appears anywhere
//   below. (S19 recorded this deliberately: any index written down now goes stale.)
//
//   IT NEVER GUESSES A FILE PATH. Get Results is DUAL OUTPUT — the full delimited text lands in a
//   variable AND the plug-in writes a file whose path is handed back in a second variable
//   [VERIFIED — vendor Lunatic API Guide 2022 §4.2.12 + code example, Cory (DD) field confirmation
//   2026-07-20, two real output files held as KB assets]. This script consumes EITHER channel,
//   preferring the variable text, and hardcodes nothing. History worth not repeating: Cardinal S11
//   flagged the KB's "emits into variables" as probably wrong because Jim expected the standard
//   reader pattern (instrument writes a file, script ingests it). The verified answer is BOTH;
//   neither single framing is complete.
//
//   IT KEYS ON HEADER NAMES, NEVER ON COLUMN POSITIONS. The column set and the separator are both
//   configurable through the Results Definition String (results_parameters, an in-param on Get
//   Results). The real output asset we hold is a PROTEIN/turbidity application and carries no A260
//   and no A230 at all — so our RNA column set will differ from it, and it is a DD configuration
//   choice rather than a fact about the instrument. Reading position 6 of a reconfigured export is
//   the failure mode this rule exists to prevent, so a missing expected column STOPS the run with
//   the column named.
//
//   "-" IS NOT ZERO. It is the no_result_value default and it appears live in the KB asset. A well
//   with no result cannot be normalized, so it is flagged and left UNTOUCHED (see the disposition
//   note below) rather than being silently treated as a 0.00 reading.
//
//   THE DUPLICATE-READ ACCEPTANCE MODE IS DATA-DRIVEN, NOT HARDCODED. A260AcceptanceLogic is a
//   worklist HEADER field the ingestion script already parses into User.A260AcceptanceLogic_01,
//   and the spec fixes its enum at line 618: Average | BestOfTwo | FlagOnDisagreement (per
//   TBD-003). So this script reads the mode instead of assuming one. BestOfTwo is accepted as a
//   value and then FAILS LOUD, because "best" is defined nowhere in the spec — higher? lower?
//   closer to the plate median? — and picking one silently would change which wells get flagged.
//   Naming TBD-003 in the failure is the correct output; a guess is not.
//
//   THE 10% AGREEMENT BASIS IS AN INTERPRETATION AND IS PRINTED AS ONE. QUANT-004 says the two
//   reads "SHALL agree within 10%" and does not say 10% of what. AGREEMENT_BASIS below is the
//   single place that decision lives, the report states which basis was used in words, and the
//   open question is named. This is deliberately NOT a silent choice.
//
//   VI ORDER IS ROW-MAJOR AND PLACEMENT IS BY WELL LABEL. Channel index = 12*row + col + 1
//   (A01=1, A02=2, B01=13, H12=96) — mm4-data-formats-reference.md § VI String Format → Well Order,
//   which is itself a v1.4.0 CORRECTION of an earlier column-major claim, confirmed against four
//   independent sources including two production scripts. Placing by label rather than by
//   worklist-row order is what makes this safe no matter what order the worklist arrives in.
//
//   THE VI SHAPE FOLLOWS DD'S OWN PRODUCTION PRECEDENT, not an invention:
//   IFF_Norming_Demo/Scripts/Norm_DaughterPlate.cs builds string[97] with index 0 = "VI;12;8",
//   joins with commas, leaves untouched wells EMPTY (Array.Clear -> null -> empty between commas,
//   NOT "0"), and accumulates per-plate VI strings into a *_List variable using a LEADING DASH as
//   the separator. The dash is not a style choice — a VI string is itself comma-delimited, so it
//   CANNOT be an element of a comma-delimited MM4 list. This script writes both forms: a scalar
//   for the current plate and a dash-accumulating list across plates, exactly as the precedent does.
//
//   UN-NORMALIZABLE WELLS ARE LEFT UNTOUCHED — SAMPLE *AND* DILUENT BOTH 0. This is the one place
//   a disposition had to be chosen, so the reasoning is on the record. TBD-011 (what to do with an
//   out-of-range well: skip / clamp with annotation / pause) is UNANSWERED by the customer, and NORM-004
//   only instructs us to flag and alert. But a VI string has no way to say "nothing decided here" —
//   every one of the 96 entries either carries a volume or is empty, and empty means the channel
//   does nothing. So the only available encoding is 0/empty, and the choice that remains is whether
//   such a well still receives DILUENT. It does not: a well left dry can still be handled by hand,
//   whereas a well that has had water put in it is spoiled for re-work. That is the conservative,
//   reversible option. It is flagged, alerted, and stated in the report — not silently applied.
//
//   NORM-004 IS WRITTEN ABOUT TransferVolume ONLY, AND THE SAME PHYSICAL LIMIT APPLIES TO THE
//   DILUENT CHANNEL. The VVP96 range is 2-1250 uL per channel. DiluentVolume =
//   RequestedOutputVolume - TransferVolume, so a nearly-neat sample yields a small non-zero
//   diluent volume — e.g. transfer 49.0 of a requested 50.0 leaves 1.0 uL of water, which is BELOW
//   the 2 uL floor. Zero is fine (the channel simply does nothing); the 0 < v < 2 band is not. The
//   spec does not flag this case, so this script does, as its own named check.
// ============================================================================

// v0.20.7: customer-neutral presentation release; execution logic is unchanged.
public class MMScriptExecutor : IMMScriptExecutor
{
    // v0.20.1  2026-07-30  MATCHES THE NEW LIST CONTRACT (Jim, D-S20-05 + D-S20-06). No arithmetic
    //                      change; every assertion in the offline suite is unchanged.
    //                        - the row-grouping list moved to User.Row_QuantPlate_List_01, because the
    //                          un-prefixed name now holds ONE ELEMENT PER PLATE SET for the method's
    //                          loops. Reading the plate-major list to group ROWS would have matched
    //                          3 elements against 168 rows and grouped nothing.
    //                        - reads strip the one leading phantom; writes emit it.
    // v0.20.2  2026-07-30  SEPARATE ASPIRATE AND DISPENSE VI PER LIQUID. v0.20.1 published one string
    //                      per liquid on the reasoning that "the same string feeds both commands" —
    //                      true for a full transfer, but it gave SYMMETRY as the reason when the real
    //                      reason to wire two is PARTIAL TRANSFERS (Jim, D-S20-08: the aspirate VI
    //                      caps what can be dispensed, so a dispense VI only matters when you intend
    //                      to put out less than you drew). Jim then wired the method for two, and the
    //                      method's names are the contract. Now emits, per liquid:
    //                          User.<Liquid>_Aspirate_VI_01  / _VI_List_01
    //                          User.<Liquid>_Dispense_VI_01  / _VI_List_01
    //                      The two carry IDENTICAL content today because this workflow draws exactly
    //                      what it dispenses. Separate names so an overage, an air gap or a partial
    //                      dispense can be introduced on one side without re-wiring the method.
    //                      NEW NUMBER, NOT A FOLD-IN: v0.20.1 RAN on MM4 at 12:03 (it failed for want
    //                      of reader data, but it ran), so it is released and must not drift — D-S18-25.
    //                      Created by COPY, not rename: renaming v0.8.4 out from under the method's
    //                      [4] earlier today broke it, and that lesson applies here.
    // v0.20.3  2026-07-30  TWO REAL DEFECTS, both found by Jim asking "what happens when we run a
    //                      different worklist?"
    //
    //   (1) A PAYLOAD WITH MORE WELLS THAN THE PLATE PASSED SILENTLY. Up to v0.20.2 the script
    //       checked only that every WORKLIST well had a payload row; payload rows nobody claimed were
    //       ignored. So any worklist whose wells are a SUBSET of the payload's — every single-plate
    //       test worklist against a full-plate fixture — matched COMPLETELY and produced confident
    //       normalization volumes from another worklist's invented numbers, with no error at all.
    //       Now checked, with two standards: a TEST FIXTURE must match exactly (hard fail, it is
    //       generated from this worklist); a real instrument payload may legitimately differ, so that
    //       is surfaced and the run continues, because inventing a rule about Lunatic behaviour
    //       nobody has observed would be a guess.
    //
    //   (2) MM4's ListParser sentinel was treated as data. "INDEX OUT OF RANGE" is what the parser
    //       writes into its OUTPUT variable when the index is past the end of the list
    //       [mm4-method-building-reference.md:499]. v0.20.2 took it for a file path and reported "no
    //       file is there" — true, useless. It is now recognised on both channels and explained.
    //
    //   ALSO: a worklist-DERIVED test payload fallback, DEFAULT OFF. It exists because the obvious
    //   shortcut — hardcoding fixture paths in the method — is what makes defect (1) reachable.
    // v0.20.4  2026-07-30  THE SENTINEL NO LONGER BLOCKS A RUN. v0.20.3 treated MM4's
    //                      "INDEX OUT OF RANGE" as a hard stop. That was wrong twice over: the
    //                      sentinel means the channel supplied NOTHING, not that anything is corrupt;
    //                      and it PERSISTS, so a value left by a run an hour earlier is
    //                      indistinguishable from one written now and blocked every later run until
    //                      someone cleared the variable by hand. Observed exactly that: the payload
    //                      ListParser had been deleted and the stale sentinel it left behind would
    //                      still have stopped the next run.
    //                      Now: recorded, reported, and the search continues to the remaining
    //                      channels and the fixture. If NOTHING supplies data, the failure names the
    //                      sentinel and says both what to check and that it may simply be stale.
    //                      ⚠ A MISSING FILE is deliberately still a hard fail — a path means
    //                      something CLAIMED to write a file, and falling through would hide that.
    // v0.20.6  2026-10-07  Coordinated repair release; see CHANGELOG.md and README.md.
    // v0.20.8  2026-11-18  SPECTRAMAX READER (Quant_Norm_SpectraMax_v0_3_0.met).
    //   TWO PHASES per plate, selected by User.ReaderPhase_01:
    //     BLANK  — after the quant plate is pre-filled with diluent and read (SoftMax section "Blank"),
    //              parse User.SpectraMaxBlankFile_01 and store the raw per-well OD230/260/280 in
    //              User.BlankPlate<k>_01, tagged with the RunID. Computes nothing else.
    //     SAMPLE — after the 5 uL stamp + mix and the two read sections, parse
    //              User.SpectraMaxRead1File_01 / Read2File_01 and CONVERT every reading to the
    //              equivalent neat 1 cm absorbance the Lunatic used to report:
    //                  A_eq = (A_raw - A_blank) x DF / L
    //              DF = User.QuantDilutionFactor_01 (ingestion, from sample/diluent volumes);
    //              L  = per-well pathlength column if the export has one (PathCheck), else
    //                   User.ReaderPathlengthCm_01; neither -> the run STOPS (no invented pathlength).
    //              The converted values are handed to the UNCHANGED Lunatic-era pipeline as a
    //              synthesized payload, so duplicate agreement, c = A260/e, purity ratios and the
    //              NORM volumes are byte-for-byte the code that was already validated offline.
    //   A280/A230 come from section Read_1 (the spec defines one A280 and one A230 reading).
    //   low_signal (Appendix B field 25, already in the enum): blank-corrected RAW A260 (mean of the
    //   two reads) below User.ReaderLowSignalOD_01. Flag only — it does not block (GEN-007).
    //   Raw, blank, DF and L per well are written to QuantNorm_spectramax_<run>_plate<k>.txt.
    //   The SoftMax export carries no plate barcode, so the synthesized payload's Plate ID is the
    //   expected ID; plate identity rests on the per-plate file path + the prepared-timestamp check.
    //   Test fixtures (Lunatic-format, already converted) still work when no SpectraMax file is bound.
    private const string SCRIPT_VERSION = "v0.20.8";

    const string V_PHASE      = "User.ReaderPhase_01";
    const string V_MODEL      = "User.ReaderModel_01";
    const string V_SMX_BLANK  = "User.SpectraMaxBlankFile_01";
    const string V_SMX_READ1  = "User.SpectraMaxRead1File_01";
    const string V_SMX_READ2  = "User.SpectraMaxRead2File_01";
    const string V_DF         = "User.QuantDilutionFactor_01";
    const string V_PATHCM     = "User.ReaderPathlengthCm_01";
    const string V_LOWOD      = "User.ReaderLowSignalOD_01";
    const string PF_LOW       = "low_signal";
    private HashSet<string> lowSignalWells = new HashSet<string>();
    private const int    MAX_SOURCE_PLATES = 4;

    // 96-well geometry. FORMAT-002 fixes quantification and output plates at 96-well.
    private const int GRID_ROWS = 8;
    private const int GRID_COLS = 12;
    private const int GRID_WELLS = GRID_ROWS * GRID_COLS;   // 96

    // VVP96 per-channel operating range, 2-1250 uL
    // [VERIFIED — mm4-vvp96-aspirate-dispense-reference.md §0, three independent sources.]
    // The 2 uL floor is DD's validated figure: it CAN go lower with validation (customer-run or
    // bought from DD as fee-for-service), which is a commercial answer, not a number this script
    // may quietly widen.
    private const double VVP96_MIN_UL = 2.0;
    private const double VVP96_MAX_UL = 1250.0;

    // QUANT-004's "agree within 10%".
    private const double DUP_TOLERANCE = 0.10;

    // ---- v0.20.5: THE ASPIRATE CARRIES AN AIR GAP, THE DISPENSE OVER-DISPENSES ----------------
    // Jim, 2026-07-31, two instructions and one rule that ties them together.
    //   THE RULE: "the vi will override all asp/disp parameters for fields that are available in the
    //   vi deconvolution." A VI field is <Volume>;<LeadingGap>;<TrailingGap>, so a BARE volume does
    //   not leave the command's air gap alone — it sets it to ZERO. Up to v0.20.4 this script emitted
    //   bare volumes, which means it was silently removing the leading air gap from the diluent and
    //   sample aspirates.
    //   ASPIRATE: "use calculated volume + 5uL leading airgap" — the gap normalizes the interior tip
    //   pressure before aspiration, which is what makes a small-volume aspirate accurate.
    //   DISPENSE: "i want to overdispense into the norm output plate, so let's set the final dispense
    //   volume = #+20uL and we can adjust if needed. the quant cannot over dispense because of
    //   labware requirements."
    // OVER-DISPENSE IS A STROKE, NOT LIQUID. You cannot dispense what is not in the tip, so commanding
    // calc+20 empties the tip rather than delivering 20 uL more. The output plate is a 150 uL twin.tec
    // and can take the air that follows; the Lunatic's optical wells cannot, which is why the QUANT
    // stamp is an exact 3 uL and is not touched here.
    // ⚠ THE OVERAGE MUST NEVER REACH THE RECORDED VOLUMES. TransferVolume and DiluentVolume in the
    // completed worklist are what LANDS IN THE WELL, and NORM-004's range check judges the same
    // number. Only the VI string carries +20. Getting this wrong would overstate every row of the customer's
    // completed worklist by 20 uL.
    private const double ASP_LEAD_GAP_UL   = 5.0;
    private const double ASP_TRAIL_GAP_UL  = 0.0;
    private const double DISPENSE_OVERAGE_UL = 20.0;

    // WHICH VALUE THE 10% IS TAKEN OF. The spec does not say. "MEAN" reads |a-b| against the mean of
    // the two, which is the ordinary laboratory reading of "duplicates agree within 10%". "LOWER"
    // reads it against the smaller of the two, which is STRICTER and flags more wells. One constant,
    // one line to change, and the report prints which one was used in plain words.
    // OPEN: design Q3 — not asked of the customer yet.
    //
    // static readonly, NOT const, and the compiler is the reason: as a const the "LOWER" comparison
    // folds away at compile time and every use of the other branch becomes unreachable code, which
    // /warnaserror rejects (CS0429). It also means the unused branch would be compiled OUT rather
    // than merely unused — so switching the basis would silently be a no-op in an already-built
    // assembly. static readonly keeps both branches real.
    private static readonly string AGREEMENT_BASIS = "MEAN";

    // ---- INPUTS the method must supply ------------------------------------------------------
    // THE READER PAYLOAD. These are the names the Get Result command's two OUT parameters are bound
    // to. The KB documents the command's parameter slots as ReadPlateResult / ReadPlateResultPath;
    // what the METHOD calls them is Jim's binding, so several plausible spellings are tried and the
    // report says which one actually carried the payload.
    // This follows a lesson that cost real time (barcode validation v0.3.0): a script constant
    // pointed at a method variable is a CONTRACT, and it goes stale the moment the method changes
    // shape. Reading the method beats trusting the constant — and while the reader is placeholder-
    // wired, accepting either spelling costs nothing and removes a whole class of "the script saw
    // an empty payload" false alarm.
    static readonly string[] V_PAYLOAD_TEXT = new string[] {
        "ReadPlateResult", "User.ReadPlateResult", "User.ReadPlateResult_01"
    };
    static readonly string[] V_PAYLOAD_PATH = new string[] {
        "ReadPlateResultPath", "User.ReadPlateResultPath", "User.ReadPlateResultPath_01"
    };

    // Which plate set this invocation is for, 1-based. Blank is tolerated ONLY on a single-plate
    // run, where there is exactly one answer; on a multi-plate run a blank is a wiring fault and
    // guessing "1" would normalize the wrong plate's wells with this plate's readings.
    // TEST-ONLY, DEFAULT OFF. Set to a profile name ("clean", "faults", "spread", "lowconc") to let
    // the script fall back to a fixture DERIVED FROM THE LOADED WORKLIST when no reader payload
    // arrived. Blank — its normal state — and the fallback cannot fire at all.
    const string V_TESTPROFILE = "User.TestPayloadProfile_01";
    const string V_PLATEIX = "User.CurrentPlateIndex_01";
    // The method's plate-loop counter, accepted as a fallback (see section 2). Base-1, counting
    // plates, so inside a plate loop it IS the plate number.
    const string V_LOOPCTR = "User.Loop_Counter_01";

    // ---- run context, all written by ingestion ----------------------------------------------
    const string V_COUNT    = "User.TransferCount_01";
    const string V_RUNID    = "User.RunID_01";
    const string V_WLFILE   = "User.WorklistFile_01";
    const string V_REPORTDIR = "User.ReportPath_01";
    const string V_EXTCOEF  = "User.ExtinctionCoefficient_01";
    const string V_TARGET   = "User.TargetConcentration_01";
    const string V_OUTVOL   = "User.RequestedOutputVolume_01";
    const string V_ACCEPT   = "User.A260AcceptanceLogic_01";
    const string V_TESTMODE = "User.RunIsTestMode_01";
    const string V_PLATECNT = "User.ScanPlateCount_01";

    // NORM-007 default. Used ONLY when the worklist header carried no TargetConcentration, and the
    // report says so when it is used.
    private const double TARGET_DEFAULT_NG_UL = 50.0;

    // QUANT-005 / QUANT-TBD-002: the generic ssRNA extinction coefficient, inherited from the reference RNA
    // workflow, 0.025 (ug/mL)^-1 cm^-1 == ~40 ug/mL per A260 unit. Used ONLY as a fallback when the
    // worklist header omitted ExtinctionCoefficientUsed.
    private const double EXTCOEF_DEFAULT = 0.025;

    // ---- per-sample bridge lists, written by ingestion, corrected by barcode validation --------
    const string L_SRCBC    = "User.SourcePlateBarcode_List_01";
    const string L_SRCWELL  = "User.SourceWell_List_01";
    const string L_QWELL    = "User.QuantWell_List_01";
    const string L_OWELL    = "User.OutputWell_List_01";
    // v0.20.1 — ROW-LEVEL name. The un-prefixed User.QuantPlate_List_01 now belongs to the METHOD and
    // holds ONE ELEMENT PER PLATE SET (commands are plate/labware major, D-S20-06). Reading it here to
    // group ROWS would find 3 elements against 168 rows and match nothing. What this script needs is
    // the row-level assignment barcode validation writes from the actual scan.
    const string L_QPLATE   = "User.Row_QuantPlate_List_01";
    const string L_QBC      = "User.QuantBarcode_List_01";

    // ---- per-sample lists THIS script fills. Ingestion seeds all ten EMPTY (v0.8.3), which is the
    //      contract: they exist, they are the right length, and they are this script's to populate.
    const string L_A260_1   = "User.A260_1_List_01";
    const string L_A260_2   = "User.A260_2_List_01";
    const string L_ACCA260  = "User.AcceptedA260_List_01";
    const string L_A280     = "User.A280_List_01";
    const string L_A230     = "User.A230_List_01";
    const string L_CALCCONC = "User.CalculatedConcentration_List_01";
    const string L_XFERVOL  = "User.TransferVolume_List_01";
    const string L_DILVOL   = "User.DiluentVolume_List_01";
    const string L_PURITY   = "User.PurityFlag_List_01";
    const string L_XFERSTAT = "User.TransferStatus_List_01";

    // ---- the VI outputs -----------------------------------------------------------------------
    // Scalar = THIS plate. List = accumulating across plates, dash-separated, per the production
    // precedent. Both are written because the precedent writes both and because which one the
    // method consumes is Jim's wiring decision, not this script's.
    // v0.20.2 — TWO VI STRINGS PER LIQUID, aspirate and dispense, because Jim wired the method that
    // way and the METHOD's names are the contract; the scripts adapt to it, not the other way round.
    //
    // WHY TWO, in his words: "the vi for the aspirate drives the amount that is dispensed. technically
    // we don't need a dispense VI since we can just over dispense or dispense + blowout. the only
    // reason i am thinking we use it is for partial transfers." So the aspirate VI CAPS what can come
    // out; a dispense VI only earns its place when you intend to put out LESS than you drew.
    //
    // TODAY THE TWO STRINGS ARE IDENTICAL for both liquids, and that is correct rather than lazy:
    // this workflow draws exactly what it dispenses, with no overage and no partial dispense. They are
    // separate NAMES so that an aspirate overage, an air gap, or a partial dispense can be introduced
    // on one side later without re-wiring the method. If they ever diverge, they diverge here.
    const string V_VI_SAMPLE_ASP   = "User.Sample_Aspirate_VI_01";
    const string V_VI_SAMPLE_DISP  = "User.Sample_Dispense_VI_01";
    const string V_VI_DILUENT_ASP  = "User.Diluent_Aspirate_VI_01";
    const string V_VI_DILUENT_DISP = "User.Diluent_Dispense_VI_01";
    const string L_VI_SAMPLE_ASP   = "User.Sample_Aspirate_VI_List_01";
    const string L_VI_SAMPLE_DISP  = "User.Sample_Dispense_VI_List_01";
    const string L_VI_DILUENT_ASP  = "User.Diluent_Aspirate_VI_List_01";
    const string L_VI_DILUENT_DISP = "User.Diluent_Dispense_VI_List_01";

    // ---- control surface, same names the other two spine scripts use --------------------------
    const string V_MESSAGE  = "User.ScriptMessage_01";
    const string V_ABORT    = "User.AbortMethod_01";
    const string V_NORMOK   = "User.NormalizationCheck_01";

    // deck handle prefix for the quantification (Lunatic) plate
    const string HDL_LUNATIC = "Lunatic_";

    // PurityFlag values. The enum is the spec's (Appendix B field 25) and is not ours to extend —
    // a completed worklist carrying a value outside it would break the customer's schema.
    const string PF_PASS  = "pass";
    const string PF_A280  = "A260_A280_low";
    const string PF_A230  = "A260_A230_low";
    const string PF_OTHER = "other";

    // TransferStatus values (Appendix B field 26): Success | NA | failure code. At this point in the
    // run nothing has been dispensed, so "Success" is not ours to write — the output-report script
    // (4) owns run-completion status. What this script can say is which wells are NOT going to be
    // attempted.
    const string TS_NA = "NA";

    private class Problem
    {
        public string What = "", Where = "", Detail = "", Fix = "";
    }
    private List<Problem> problems = new List<Problem>();
    private List<string> notes = new List<string>();     // non-fault observations worth printing

    // report state
    private string rpRunId = "", rpPayloadSource = "", rpPayloadVar = "", rpSeparator = "";
    private string rpAcceptMode = "", rpPlateId = "";
    private int rpPlateIx = 0, rpRows = 0, rpRowsThisPlate = 0, rpMatched = 0, rpPayloadRows = 0;
    private string rpPlateIxSource = "";     // WHICH variable told us the plate number
    private double rpTarget = 0, rpOutVol = 0, rpExtCoef = 0;
    private bool rpTargetDefaulted = false, rpExtCoefDefaulted = false;
    private bool rpPayloadIsFixture = false;   // true => came from the default-OFF test fallback
    private string rpSentinelOn = "";          // variable(s) found holding MM4's out-of-range marker
    private void NoteSentinel(string varName)
    {
        rpSentinelOn = rpSentinelOn.Length == 0 ? varName : rpSentinelOn + ", " + varName;
        notes.Add(varName + " held \"" + LISTPARSER_OOR + "\" — MM4's marker for a ListParser index "
            + "past the end of its list. It was treated as \"this channel supplied nothing\" and the "
            + "search continued. Worth resolving even though this run got its data elsewhere: either a "
            + "ListParser is misconfigured, or it is a stale value from an earlier run, and MM4 "
            + "variables persist until something overwrites them.");
    }
    private bool reportWritten = false, reportInWorkspace = true;
    private string reportPath = "";
    private bool computeReached = false;
    private string rpViSample = "", rpViDiluent = "";
    // v0.20.5 — the four distinct strings. Aspirate and dispense are no longer the same content.
    private string rpViSampleAsp = "", rpViSampleDisp = "", rpViDiluentAsp = "", rpViDiluentDisp = "";
    private List<WellResult> rpWells = new List<WellResult>();

    // One row of the worklist, after this script has done its work to it.
    private class WellResult
    {
        public int Row;                        // 0-based index into the per-sample lists
        public string SrcWell = "", QWell = "", OWell = "", SrcBc = "";
        public string A260_1 = "", A260_2 = "", Accepted = "", A280 = "", A230 = "";
        public string CalcConc = "", Xfer = "", Dil = "", Purity = "", Status = "";
        public string R260_280 = "", R260_230 = "";
        public bool Flagged = false;
        public string FlagWhy = "";
        public bool Untouched = false;         // true => this well gets neither sample nor diluent
        public bool Clamped = false;           // NORM-003a raised the transfer volume to the cap
    }

    public void Execute(IMMApp app)
    {
        try
        {
            ResetInvocation();
            Run(app);
        }
        catch (Exception ex)
        {
            // A crash must never look like a pass. Same fail-closed shape as the other two spine
            // scripts: verdict false, message set, abort raised, report written anyway — a crash is
            // exactly when a record matters most, because it is the only account of what the run
            // held at the moment it failed.
            Set(app, V_NORMOK, "False");
            Set(app, V_MESSAGE, "The normalization calculation could not run:\n\n" + ex.Message
                + "\n\nThe run has been stopped because no per-well volumes were produced.");
            Set(app, V_ABORT, "True");
            try { app.OutputMsg("[QuantNorm readernorm " + SCRIPT_VERSION + "] EXCEPTION: "
                + ex.ToString(), true); } catch (Exception) { }
            WriteReport(app);
        }
    }

    private void Run(IMMApp app)
    {
        // ---------- 0. THIS INVOCATION STARTS WITH NO VERDICT ----------
        // The method calls this script once per plate, so like the barcode re-scan loop it can be
        // re-entered inside a single run. A verdict left standing from plate 1 must not describe
        // plate 2. (Barcode validation learned this the hard way: a stale True aborted a run that
        // had just passed.)
        Qn.Require(!Get(app, V_ABORT).Equals("True", StringComparison.OrdinalIgnoreCase),
            "An earlier step failed. Restart from ingestion after correcting that failure.");
        Qn.CheckWorklist(app);
        Set(app, V_NORMOK, "False");
        problems.Clear();
        notes.Clear();

        rpRunId = Get(app, V_RUNID).Trim();

        // ---------- 1. HOW MANY ROWS, AND HOW MANY PLATES ----------
        int n;
        if (!int.TryParse(Get(app, V_COUNT).Trim(), out n) || n <= 0)
        {
            Fail(app, "The number of worklist rows could not be read from " + V_COUNT + ", so there is "
                + "nothing to calculate.\n\nRun the worklist ingestion step first, then try again.");
            return;
        }
        rpRows = n;

        int plateCount;
        if (!int.TryParse(Get(app, V_PLATECNT).Trim(), out plateCount) || plateCount <= 0) plateCount = 0;

        // ---------- 2. WHICH PLATE IS THIS? ----------
        // Three sources, in order of how explicit they are. The report always states which one was
        // used, because "which plate did these readings belong to" is the single question that, got
        // wrong, normalises one plate's wells against another plate's numbers.
        string rawIx = Get(app, V_PLATEIX).Trim();
        rpPlateIxSource = V_PLATEIX;

        if (rawIx.Length == 0)
        {
            // FALLBACK: the enclosing plate loop's own counter. This is not a guess — the method's
            // plate loops are base-1 and count plates ("we use base 1 for index to match the COUNT of
            // labware", Jim, S20), and this script is called from inside one, so the counter IS the
            // plate number at the moment of the call. Accepting it means the method needs no extra
            // step wired in before the Run Script.
            // It is a FALLBACK and not the primary on purpose: a loop counter is a shared, reused
            // variable, so if the script is ever called outside a plate loop it could carry a stale
            // value. CurrentPlateIndex_01 is the explicit answer and always wins when it is set.
            string rawLoop = Get(app, V_LOOPCTR).Trim();
            if (rawLoop.Length > 0)
            {
                rawIx = rawLoop;
                rpPlateIxSource = V_LOOPCTR + " (fallback)";
            }
        }

        if (rawIx.Length == 0)
        {
            if (plateCount == 1)
            {
                rpPlateIx = 1;
                rpPlateIxSource = "assumed";
                notes.Add(V_PLATEIX + " and " + V_LOOPCTR + " were both blank and this run uses a "
                    + "single plate, so plate 1 was assumed — the only value it could have been.");
            }
            else
            {
                Fail(app, "This run uses " + (plateCount > 0 ? plateCount.ToString() : "more than one")
                    + " plates, but neither " + V_PLATEIX + " nor " + V_LOOPCTR + " holds a value, so "
                    + "the script cannot tell which plate these reader results belong to.\n\nSet "
                    + V_PLATEIX + " to the 1-based plate number before this script runs, or call it "
                    + "from inside the plate loop so its counter is available.\n\nIt refuses rather "
                    + "than assume: guessing here would normalise one plate's wells against another "
                    + "plate's readings, and nothing downstream would report it.");
                return;
            }
        }
        else if (!int.TryParse(rawIx, out rpPlateIx) || rpPlateIx < 1 || rpPlateIx > MAX_SOURCE_PLATES)
        {
            Fail(app, V_PLATEIX + " holds \"" + rawIx + "\", which is not a plate number between 1 and "
                + MAX_SOURCE_PLATES + ".\n\nThe method must set it to the 1-based plate number.");
            return;
        }

        Qn.Require(plateCount >= 1 && plateCount <= MAX_SOURCE_PLATES && rpPlateIx <= plateCount,
            "Current plate index exceeds this run's plate count.");
        Qn.Require(Get(app, "User.ReaderPreparedRun_01") == rpRunId &&
            Get(app, "User.ReaderPreparedPlate_01") == rpPlateIx.ToString(),
            "Reader inputs were not prepared for this run and plate. Use the revised method's PREPARE_READER guard.");
        string phase = Get(app, V_PHASE).Trim().ToUpperInvariant();
        Qn.Require(phase == "BLANK" || phase == "SAMPLE" || (phase.Length == 0 && !IsSpectraMax(app)),
            "User.ReaderPhase_01 must be BLANK or SAMPLE for a SpectraMax run (set by the RunGuard PREPARE_BLANK / PREPARE_READER stages).");
        bool blankPhase = phase == "BLANK";
        if (!blankPhase) ClearPlateCalculation(app, rpPlateIx, plateCount);
        // ---------- 3. THE RUN'S CONFIGURED VALUES ----------
        // Each comes from the worklist header block via ingestion. Where the header omitted one, the
        // spec's own default is used AND the report says a default was used — a run that silently
        // normalized to a number nobody chose would be the worst possible outcome here.
        rpTarget = PositiveParameter(app, V_TARGET, TARGET_DEFAULT_NG_UL, true, out rpTargetDefaulted);
        rpExtCoef = PositiveParameter(app, V_EXTCOEF, EXTCOEF_DEFAULT, true, out rpExtCoefDefaulted);
        bool ignoredDefault;
        rpOutVol = PositiveParameter(app, V_OUTVOL, 0, false, out ignoredDefault);
        double capacity = PositiveParameter(app, "User.OutputWellCapacity_01", 0, false, out ignoredDefault);
        double tipCapacity = PositiveParameter(app, "User.TipWorkingCapacity_01", 0, false, out ignoredDefault);
        Qn.Require(rpOutVol <= capacity, "RequestedOutputVolume exceeds the configured output well capacity.");
        double aspirationLimit = Math.Min(VVP96_MAX_UL, tipCapacity - ASP_LEAD_GAP_UL - ASP_TRAIL_GAP_UL);
        Qn.Require(aspirationLimit >= VVP96_MIN_UL, "Configured tip capacity leaves no valid liquid capacity after air gaps.");

        // Purity thresholds must be read HERE, before the per-well loop that consumes them. (First
        // draft of this script read them only in WriteReport, which runs after the loop — every well
        // would have been flagged "thresholds not configured" even on a machine where they were set.)
        purityTh280 = Get(app, V_TH_280).Trim();
        purityTh230 = Get(app, V_TH_230).Trim();
        foreach (string threshold in new string[] { purityTh280, purityTh230 })
        {
            double value;
            Qn.Require(threshold.Length == 0 || (Qn.TryNumber(threshold, out value) && value > 0),
                "Purity thresholds must be blank or positive finite numbers.");
        }

        // Duplicate-read acceptance mode — data-driven, per spec line 618.
        string acc = Get(app, V_ACCEPT).Trim();
        rpAcceptMode = acc;
        string accKey = Key(acc);
        if (accKey.Length == 0)
        {
            rpAcceptMode = "Average (defaulted)";
            accKey = "average";
            notes.Add("A260AcceptanceLogic was not supplied in the worklist header, so QUANT-004's "
                + "stated behaviour was used: where the two reads agree, Accepted_A260 is their average.");
        }
        else if (accKey == "bestoftwo")
        {
            // Deliberate hard stop. "Best" is defined nowhere — higher reading? lower? closer to the
            // plate median? Each answer changes which wells get flagged and what volume goes in.
            Fail(app, "The worklist asks for A260AcceptanceLogic = \"" + acc + "\", and that mode is not "
                + "implemented because the specification does not define it.\n\nTBD-003 leaves \"best of "
                + "two\" unstated — it does not say whether the better read is the higher one, the lower "
                + "one, or the one closer to the rest of the plate, and each choice changes both the "
                + "flagged wells and the volumes dispensed.\n\nUse Average or FlagOnDisagreement, or get "
                + "TBD-003 answered by the customer.");
            return;
        }
        else if (accKey != "average" && accKey != "flagondisagreement")
        {
            Fail(app, "A260AcceptanceLogic holds \"" + acc + "\", which is not one of the three values the "
                + "specification allows: Average, BestOfTwo or FlagOnDisagreement.\n\nThe run has been "
                + "stopped rather than fall back to a mode nobody selected.");
            return;
        }

        // ---------- 4. THE PER-SAMPLE BRIDGE ----------
        // NOTE ON LIST PARSING, because getting this wrong is silent: ingestion writes PER-SAMPLE
        // lists with Pick() — a plain "a,b,c" with NO leading delimiter — and PER-PLATE lists with
        // LeadingList() — ",a,b,c" WITH one. Barcode validation's ParseList drops a leading empty
        // element, which is right for the per-plate lists it reads and WRONG here: it would silently
        // discard row 1 on any run whose first row had an empty value. So these are split strictly
        // and the length is checked against TransferCount instead.
        List<string> srcWell = SplitStrict(Get(app, L_SRCWELL));
        List<string> qWell   = SplitStrict(Get(app, L_QWELL));
        List<string> oWell   = SplitStrict(Get(app, L_OWELL));
        List<string> qPlate  = SplitStrict(Get(app, L_QPLATE));
        List<string> srcBc   = SplitStrict(Get(app, L_SRCBC));

        string lenErr = CheckLen(n, "SourceWell", srcWell);
        if (lenErr.Length == 0) lenErr = CheckLen(n, "QuantWell", qWell);
        if (lenErr.Length == 0) lenErr = CheckLen(n, "OutputWell", oWell);
        if (lenErr.Length == 0) lenErr = CheckLen(n, "QuantPlate", qPlate);
        if (lenErr.Length > 0)
        {
            Fail(app, "The per-sample bridge lists do not agree with the row count.\n\n" + lenErr
                + "\n\nRe-run the worklist ingestion step; the lists and " + V_COUNT + " must be "
                + "written by the same parse.");
            return;
        }

        // ---------- 5. WHICH ROWS BELONG TO THIS PLATE ----------
        // The quant plate HANDLE carries the plate set: Lunatic_01, Lunatic_02, ... Barcode
        // validation re-points these from the actual scan, so by the time this script runs they
        // describe where the plates really are — not ingestion's provisional guess.
        string wantHandle = HDL_LUNATIC + rpPlateIx.ToString("D2");
        var rows = new List<int>();
        for (int i = 0; i < n; i++)
            if (string.Equals(qPlate[i].Trim(), wantHandle, StringComparison.OrdinalIgnoreCase))
                rows.Add(i);
        rpRowsThisPlate = rows.Count;

        if (rows.Count == 0)
        {
            Fail(app, "No worklist rows are assigned to " + wantHandle + ", so there is nothing to "
                + "normalize for plate " + rpPlateIx + ".\n\nEither " + V_PLATEIX + " names a plate this "
                + "run does not use, or the deck mapping was not written. " + L_QPLATE + " holds: "
                + Preview(qPlate));
            return;
        }

        // ---------- 5b. BLANK PHASE (v0.20.8) — store the per-well blank and stop here ----------
        if (blankPhase) { RunBlankPhase(app, rows, qWell); return; }

        // ---------- 6. THE READER PAYLOAD ----------
        string payload = AcquirePayload(app);
        if (payload == null) return;          // AcquirePayload has already failed the run

        ReaderTable table;
        string parseErr = ParsePayload(payload, out table);
        if (parseErr.Length > 0)
        {
            Fail(app, "The reader results could not be read.\n\n" + parseErr);
            return;
        }
        rpSeparator = table.SeparatorName;
        rpPayloadRows = table.Rows.Count;

        // One plate per invocation — see the header note. More than one Plate ID in a single payload
        // means this call was handed a multi-plate export, and quietly taking the first one would
        // normalize this plate's wells against another plate's readings.
        if (table.PlateIds.Count > 1)
        {
            Fail(app, "The reader results contain " + table.PlateIds.Count + " different plate IDs ("
                + Join(table.PlateIds) + "), but this script processes ONE plate per call — Get Results "
                + "takes the plate ID as an input, so each call returns one plate.\n\nCall the script "
                + "once per plate inside the plate loop, or narrow the results definition.");
            return;
        }
        rpPlateId = table.PlateIds.Count == 1 ? table.PlateIds[0] : "";

        if (!rpPayloadIsFixture)
        {
            string expectedPlateID = Get(app, "User.ReaderExpectedPlateID_01");
            Qn.Require(expectedPlateID.Length > 0 && rpPlateId == expectedPlateID,
                "Reader Plate ID does not match this read's expected ID. Expected '" + expectedPlateID + "', received '" + rpPlateId + "'.");
        }
        // Cross-check the payload's plate ID against the captured quant-plate barcode when both are
        // present. This is a NOTE, not a fault: what the method passes as PlateID is its own choice
        // and may legitimately be a handle rather than a barcode. Recording the pair is what lets
        // someone reconstruct later which physical plate these numbers came from.
        List<string> qbc = SplitStrict(Get(app, L_QBC));
        string thisQbc = (rows.Count > 0 && rows[0] < qbc.Count) ? qbc[rows[0]].Trim() : "";
        if (rpPlateId.Length > 0 && thisQbc.Length > 0
            && !string.Equals(rpPlateId, thisQbc, StringComparison.Ordinal))
            notes.Add("The reader reported plate ID \"" + rpPlateId + "\" while the captured "
                + "quantification-plate barcode for these rows is \"" + thisQbc + "\". These are not "
                + "required to match — the plate ID is whatever the method passed into Get Results — "
                + "but both are recorded so the readings can be tied back to a physical plate.");

        // ---------- 6b. DOES THIS PAYLOAD BELONG TO THIS PLATE? ----------
        // Up to v0.20.2 this script checked only that every WORKLIST well had a payload row. It never
        // objected to payload rows nobody claimed — so a payload holding MORE wells than the plate
        // matched completely and produced confident volumes from data that may not belong to this run
        // at all. That is the failure mode worth catching, because it does not error.
        //
        // TWO DIFFERENT STANDARDS, and the difference is not arbitrary:
        //
        //   FIXTURE (test fallback): the fixture is generated FROM this worklist and this plate, so
        //   the counts must match EXACTLY. Any difference means the fixture and the worklist have
        //   drifted apart, and continuing would compute real-looking numbers from the wrong source.
        //   HARD FAIL.
        //
        //   INSTRUMENT (either real Get Results channel): a count difference is NOT necessarily
        //   wrong. A Lunatic asked to read a whole plate may legitimately return 96 rows for a plate
        //   holding 37 samples. Cardinal has NOT established which it does, and inventing a rule
        //   about instrument behaviour that has never been observed would be a guess. So this is
        //   surfaced prominently and the run continues — the operator sees both numbers and can
        //   judge. When the Lunatic is wired and its actual behaviour is known, this becomes a hard
        //   rule one way or the other.
        if (table.Rows.Count != rows.Count)
        {
            string both = "The reader results hold " + table.Rows.Count + " well row(s), but plate "
                + rpPlateIx + " has " + rows.Count + " sample row(s) in the worklist.";
            if (rpPayloadIsFixture)
            {
                Fail(app, both + "\n\nThis payload came from the TEST fixture fallback, and a fixture "
                    + "is generated from this exact worklist and plate — so the two must agree "
                    + "exactly. They do not, which means the fixture is stale or belongs to a "
                    + "different worklist.\n\nRegenerate it with "
                    + "tools/offline-harness/gen_placeholder_reader_results.py against the worklist "
                    + "actually loaded:\n\n" + Get(app, V_WLFILE));
                return;
            }
            notes.Add(both + " That is not necessarily wrong — a reader asked to read the whole plate "
                + "returns a row per position regardless of how many hold sample — but it is worth "
                + "seeing. Every worklist well was still matched to its own row by well label; extra "
                + "reader rows were ignored.");
        }

        // ---------- 7. PER-WELL: PAIR, ACCEPT, CALCULATE, RANGE-CHECK ----------
        computeReached = true;
        var xfer = new string[n]; var dil = new string[n];
        var dispositions = new string[n]; var calcTimes = new string[n]; var reasons = new string[n];
        CarryForward(app, "User.RowDisposition_List_01", dispositions, n);
        CarryForward(app, "User.RowCalculationTimestamp_List_01", calcTimes, n);
        CarryForward(app, "User.RowCalculationNote_List_01", reasons, n);
        var a1 = new string[n]; var a2 = new string[n]; var acceptedL = new string[n];
        var a280L = new string[n]; var a230L = new string[n]; var concL = new string[n];
        var purityL = new string[n]; var statusL = new string[n];

        // Preserve anything already written for OTHER plates — this script is called per plate, so a
        // blind overwrite of all ten lists would wipe plate 1's results when plate 2 runs.
        CarryForward(app, L_A260_1, a1, n);       CarryForward(app, L_A260_2, a2, n);
        CarryForward(app, L_ACCA260, acceptedL, n); CarryForward(app, L_A280, a280L, n);
        CarryForward(app, L_A230, a230L, n);      CarryForward(app, L_CALCCONC, concL, n);
        CarryForward(app, L_XFERVOL, xfer, n);    CarryForward(app, L_DILVOL, dil, n);
        CarryForward(app, L_PURITY, purityL, n);  CarryForward(app, L_XFERSTAT, statusL, n);

        // The VI grids. Index 0 holds the header; 1..96 hold per-well data; untouched entries stay
        // empty, exactly as the production precedent leaves them.
        // v0.20.5 — FOUR grids. Aspirate and dispense differ now, so they can no longer share a
        // string: the aspirate carries the air gap, the dispense carries the over-dispense stroke.
        string[] viSampleAsp   = NewViGrid();
        string[] viSampleDisp  = NewViGrid();
        string[] viDiluentAsp  = NewViGrid();
        string[] viDiluentDisp = NewViGrid();

        for (int k = 0; k < rows.Count; k++)
        {
            int i = rows[k];
            var w = new WellResult();
            w.Row = i;
            w.SrcWell = srcWell[i].Trim();
            w.QWell = qWell[i].Trim();
            w.OWell = oWell[i].Trim();
            w.SrcBc = i < srcBc.Count ? srcBc[i].Trim() : "";

            // NORM-001 fixes source-to-destination mapping at 1:1 (A1 -> A1), and D-S19-12 says the
            // VI-versus-VMDI question is decided by whether the WELLS MOVE. If a row's source and
            // output wells differ, that is a rearray, VI is the wrong format for it, and a VI built
            // from it would put the volume on the wrong channel. Stop rather than mis-address.
            if (Qn.Well(w.SrcWell).Length == 0 || Qn.Well(w.QWell).Length == 0 || Qn.Well(w.OWell).Length == 0 ||
                !SameWell(w.SrcWell, w.OWell) || !SameWell(w.SrcWell, w.QWell))
            {
                Fail(app, "Worklist row " + (i + 1) + " must use the same valid source, quantification and output well. This method does not re-array wells.");
                return;
            }

            int ch = ChannelOf(w.SrcWell);
            if (ch < 1)
            {
                Fail(app, "Worklist row " + (i + 1) + " has source well \"" + w.SrcWell + "\", which is not "
                    + "a 96-well position between A1 and H12.\n\nThe VI channel is derived from the well "
                    + "label, so an unreadable label has no channel and the volume would have nowhere to go.");
                return;
            }

            // ---- find this well in the reader payload ----
            // IDENTITY MAPPING, ASSERTED AND CHECKED, NOT ASSUMED. Whether quantification well A1
            // reads at Lunatic position A1 is design question Q2 and is not established — the KB
            // lists column_source_position and column_Plate_position as separate declared fields,
            // which implies the mapping is configured somewhere. So this matches on the well label
            // and STOPS LOUDLY when a label is absent, naming the well. A wrong assumption here
            // cannot pass silently: it produces a named failure on the first unmatched well.
            ReaderRow rr = table.Find(w.QWell);
            if (rr == null)
            {
                Fail(app, "The reader results contain no row for quantification well " + w.QWell
                    + " (worklist row " + (i + 1) + ").\n\nWells present in the results: "
                    + Join(table.WellsPresent()) + "\n\nThis script matches the worklist's "
                    + "quantification well to the reader's plate position by LABEL. If the Lunatic is "
                    + "configured to report positions differently, that mapping has to be established "
                    + "before these volumes can be trusted (design question Q2).");
                return;
            }
            rpMatched++;

            w.A260_1 = rr.A260_1; w.A260_2 = rr.A260_2;
            w.A280 = rr.A280; w.A230 = rr.A230;

            // ---- QUANT-004: duplicate agreement ----
            double v1, v2;
            bool has1 = TryNum(rr.A260_1, out v1);
            bool has2 = TryNum(rr.A260_2, out v2);
            double accepted = 0;
            bool haveAccepted = false;

            if ((has1 && v1 <= 0) || (has2 && v2 <= 0))
            {
                Flag(w, "nonpositive A260 result; no valid positive concentration");
                Add("Invalid A260", w.QWell, "A260 readings must be finite and positive.", "Re-read or review this sample.");
            }
            else if (has1 && has2)
            {
                double diff = Math.Abs(v1 - v2);
                double basis = AGREEMENT_BASIS == "LOWER" ? Math.Min(v1, v2) : (v1 + v2) / 2.0;
                bool agree = basis > 0 ? (diff / basis) <= DUP_TOLERANCE : diff == 0;

                if (agree)
                {
                    accepted = (v1 + v2) / 2.0; haveAccepted = true;
                }
                else
                {
                    // Both acceptance modes we implement flag a disagreement. Neither of them
                    // silently picks a winner, which is the whole reason BestOfTwo is refused above.
                    Flag(w, "the two A260 reads disagree by more than " + Pct(DUP_TOLERANCE)
                        + " (" + Num(v1) + " and " + Num(v2) + ")");
                    Add("Duplicate A260 reads disagree", "well " + w.QWell + " (worklist row " + (i + 1) + ")",
                        "A260_1 = " + Num(v1) + ", A260_2 = " + Num(v2) + " — a difference of " + Num(diff)
                        + ", which is " + Pct(basis > 0 ? diff / basis : 0) + " of the "
                        + (AGREEMENT_BASIS == "LOWER" ? "lower reading" : "mean of the two")
                        + ". QUANT-004 requires agreement within " + Pct(DUP_TOLERANCE) + ".",
                        "Re-read the plate, or accept the well manually once TBD-003 defines what "
                        + "should happen to a disagreeing duplicate.");
                }
            }
            else if (has1 || has2)
            {
                // ONE read only. QUANT-004 requires a duplicate, so this is not a well we can
                // silently normalize off a single number — but it is also not nothing, so the value
                // is recorded and the well flagged.
                Flag(w, "only one of the two required A260 reads has a result");
                Add("A duplicate A260 read is missing", "well " + w.QWell + " (worklist row " + (i + 1) + ")",
                    "A260_1 = " + Show(rr.A260_1) + ", A260_2 = " + Show(rr.A260_2)
                    + ". QUANT-004 requires the sample to be read in duplicate.",
                    "Re-read the plate. A single reading is not an accepted value under QUANT-004, so "
                    + "this well has not been given a volume.");
            }
            else
            {
                // NO result at all — the "-" case, or an empty position.
                Flag(w, "the reader returned no A260 result");
                Add("No reader result", "well " + w.QWell + " (worklist row " + (i + 1) + ")",
                    "The reader reported " + Show(rr.A260_1) + " / " + Show(rr.A260_2) + " for this well. "
                    + "\"-\" is the reader's no-result marker; it is not a reading of zero.",
                    "Check the well was filled and the plate seated, then re-read. This well has been "
                    + "left untouched — it will receive neither sample nor diluent.");
            }

            // ---- QUANT-005: concentration ----
            if (haveAccepted)
            {
                w.Accepted = Qn.Number(accepted);
                // c = A260 / extinction coefficient. With the configured 0.025 (ug/mL)^-1 cm^-1 this
                // is A260 x 40 ug/mL, which is the "~40 ug/mL per A260 unit" equivalence the spec
                // itself states — a 1 cm equivalent pathlength is inherent in that equivalence.
                // 1 ug/mL == 1 ng/uL, and NORM-002 fixes the basis at ng/uL, so no unit conversion
                // is applied and none is hidden.
                double conc = accepted / rpExtCoef;
                Qn.Require(Qn.Finite(conc) && conc > 0, "Calculated concentration is not finite and positive at " + w.QWell);
                w.CalcConc = Qn.Number(conc);

                // ---- QUANT-007: purity ratios ----
                Purity(w, rr, accepted);

                // ---- NORM-002 / 003 / 003a: the volumes ----
                w.Clamped = conc < rpTarget;
                double t = (rpTarget / conc) * rpOutVol;
                if (double.IsPositiveInfinity(t) && conc < rpTarget) t = rpOutVol;
                Qn.Require(Qn.Finite(t) && t > 0, "Invalid calculated sample volume at " + w.QWell);

                // NORM-003a: at or below target, RAISE the transfer volume rather than dispense the
                // sample neat — up to the whole requested output volume. Note this is a clamp on the
                // formula's output, not a different formula.
                if (t >= rpOutVol)
                {
                    if (t > rpOutVol) { w.Clamped = true; }
                    t = rpOutVol;
                }

                // NORM-003 is an EQUALITY: TransferVolume + DiluentVolume = RequestedOutputVolume.
                // So the transfer volume is rounded FIRST and the diluent is derived from the rounded
                // value — never rounded independently. Rounding both separately breaks the equality
                // by a hundredth of a microlitre in the general case (t = 24.865 of 100 gives
                // 24.87 + 75.14 = 100.01), which is small, silent, and still a spec violation in a
                // number that goes into the customer's completed worklist. Caught by the offline suite.
                double rawTransfer = t;
                double rawDiluent = rpOutVol - t;
                t = Round2(t);
                double d = Round2(rpOutVol - t);               // spec line 569
                if (d < 0) d = 0;                              // cannot happen after the clamp; belt

                // ---- NORM-004: transfer volume against the validated VVP96 range ----
                if (rawTransfer < VVP96_MIN_UL || t < VVP96_MIN_UL)
                {
                    Flag(w, "the calculated transfer volume " + Num(t) + " uL is below the validated "
                        + "VVP96 minimum of " + Num(VVP96_MIN_UL) + " uL");
                    Add("Transfer volume below the validated range",
                        "well " + w.SrcWell + " -> " + w.OWell + " (worklist row " + (i + 1) + ")",
                        "The sample measured " + Num(conc) + " ng/uL, so reaching " + Num(rpTarget)
                        + " ng/uL in " + Num(rpOutVol) + " uL needs only " + Num(t) + " uL of it. The "
                        + "validated VVP96 range is " + Num(VVP96_MIN_UL) + "-" + Num(VVP96_MAX_UL)
                        + " uL per channel.",
                        "NORM-004 requires this to be flagged and the operator alerted before "
                        + "dispensing. What SHOULD happen to it — skip, dispense at the minimum with an "
                        + "annotation, or pause for a decision — is TBD-011 and is unanswered by the customer, "
                        + "so this script does not choose: the well has been left untouched.");
                }
                else if (rawTransfer > aspirationLimit || t > aspirationLimit)
                {
                    Flag(w, "the calculated transfer volume " + Num(t) + " uL is above the validated "
                        + "VVP96 maximum of " + Num(VVP96_MAX_UL) + " uL");
                    Add("Transfer volume above the validated range",
                        "well " + w.SrcWell + " -> " + w.OWell + " (worklist row " + (i + 1) + ")",
                        "Reaching " + Num(rpTarget) + " ng/uL in " + Num(rpOutVol) + " uL would need "
                        + Num(t) + " uL of a " + Num(conc) + " ng/uL sample, and the validated VVP96 "
                        + "range tops out at " + Num(VVP96_MAX_UL) + " uL per channel.",
                        "Flagged per NORM-004; disposition is TBD-011. The well has been left untouched.");
                }
                // ---- the same physical limit, applied to the DILUENT channel ----
                // Check both liquid channels against the configured channel/tip limits. The diluent goes through the same
                // VVP96 channels, so a small non-zero water volume is equally undispensable. Zero is
                // fine — the channel simply does nothing. It is the 0 < v < 2 band that is not.
                else if (rawDiluent > aspirationLimit || d > aspirationLimit)
                {
                    Flag(w, "diluent volume exceeds configured channel/tip capacity");
                    Add("Diluent volume above capacity", w.OWell, "Diluent " + Num(d) + " uL exceeds " + Num(aspirationLimit) + " uL.", "Reduce output volume or use a validated configuration.");
                }
                else if ((rawDiluent > 0 && rawDiluent < VVP96_MIN_UL) || (d > 0 && d < VVP96_MIN_UL))
                {
                    Flag(w, "the calculated diluent volume " + Num(d) + " uL is below the validated "
                        + "VVP96 minimum of " + Num(VVP96_MIN_UL) + " uL");
                    Add("Diluent volume below the validated range",
                        "well " + w.OWell + " (worklist row " + (i + 1) + ")",
                        "The sample is concentrated enough that " + Num(t) + " uL of it fills most of the "
                        + Num(rpOutVol) + " uL requested, leaving only " + Num(d) + " uL of diluent — "
                        + "below the " + Num(VVP96_MIN_UL) + " uL floor. NORM-004 names only the transfer "
                        + "volume, but the diluent goes through the same channels and the same limit "
                        + "applies to it.",
                        "Either accept a slightly different output volume for this well, or raise "
                        + "RequestedOutputVolume so the diluent share clears " + Num(VVP96_MIN_UL)
                        + " uL. The well has been left untouched.");
                }
                else
                {
                    // In range. This is the only path that puts a volume on a channel.
                    w.Xfer = Num(t); w.Dil = Num(d);
                    // ASPIRATE: the calculated volume plus the leading air gap, explicitly, because
                    // an omitted sub-field is not "inherit" — it is zero, and would delete the gap.
                    Qn.Require(viSampleAsp[ch] == null, "Two worklist rows resolve to the same normalization channel.");
                    viSampleAsp[ch]  = AspField(t);
                    // DISPENSE: calc + overage, so the tip goes out empty. Clamped to the validated
                    // VVP96 maximum — a stroke larger than the channel can command is not a stroke.
                    viSampleDisp[ch] = Num(Overage(t));
                    if (d > 0)
                    {
                        viDiluentAsp[ch]  = AspField(d);
                        viDiluentDisp[ch] = Num(Overage(d));
                    }
                    if (w.Clamped)
                        notes.Add("Well " + w.SrcWell + " measured " + Num(conc) + " ng/uL, at or below "
                            + "the " + Num(rpTarget) + " ng/uL target, so per NORM-003a its transfer "
                            + "volume was raised to the full " + Num(rpOutVol) + " uL as an undiluted transfer. "
                            + "It will not reach the target concentration; "
                            + "it gets as close as the measured concentration allows.");
                }
            }

            // Anything still without a volume is untouched, and says so in the completed worklist.
            if (w.Xfer.Length == 0)
            {
                w.Untouched = true;
                w.Status = TS_NA;
                if (w.Purity.Length == 0) w.Purity = PF_OTHER;
            }

            // ---- write this row into the output arrays ----
            a1[i] = w.A260_1; a2[i] = w.A260_2; acceptedL[i] = w.Accepted;
            a280L[i] = w.A280; a230L[i] = w.A230; concL[i] = w.CalcConc;
            xfer[i] = w.Xfer; dil[i] = w.Dil;
            purityL[i] = w.Purity; statusL[i] = w.Status;

            dispositions[i] = w.Untouched ? "SKIPPED" : (w.Clamped ? "CALCULATED_BELOW_TARGET" : "CALCULATED");
            calcTimes[i] = DateTime.Now.ToString("o");
            reasons[i] = (w.Untouched ? w.FlagWhy : (w.Clamped ? "Source below target; full-volume undiluted transfer; target not achieved." : ""))
                .Replace(",", ";").Replace("\r", " ").Replace("\n", " ");
            rpWells.Add(w);
        }

        // ---------- 8. SERIALISE THE VI STRINGS ----------
        rpViSampleAsp   = string.Join(",", viSampleAsp);
        rpViSampleDisp  = string.Join(",", viSampleDisp);
        rpViDiluentAsp  = string.Join(",", viDiluentAsp);
        rpViDiluentDisp = string.Join(",", viDiluentDisp);
        rpViSample = rpViSampleAsp; rpViDiluent = rpViDiluentAsp;   // report display

        // ---------- 9. WRITE THE BRIDGE ----------
        Set(app, L_A260_1, Join2(a1));       Set(app, L_A260_2, Join2(a2));
        Set(app, L_ACCA260, Join2(acceptedL)); Set(app, L_A280, Join2(a280L));
        Set(app, L_A230, Join2(a230L));      Set(app, L_CALCCONC, Join2(concL));
        Set(app, L_XFERVOL, Join2(xfer));    Set(app, L_DILVOL, Join2(dil));
        Set(app, L_PURITY, Join2(purityL));  Set(app, L_XFERSTAT, Join2(statusL));
        Set(app, "User.RowDisposition_List_01", Join2(dispositions));
        Set(app, "User.RowCalculationTimestamp_List_01", Join2(calcTimes));
        Set(app, "User.RowCalculationNote_List_01", Join2(reasons));

        Set(app, V_VI_SAMPLE_ASP,   rpViSampleAsp);
        Set(app, V_VI_SAMPLE_DISP,  rpViSampleDisp);
        Set(app, V_VI_DILUENT_ASP,  rpViDiluentAsp);
        Set(app, V_VI_DILUENT_DISP, rpViDiluentDisp);
        // Store by physical quantification slot. Reprocessing a slot replaces it; it never appends or shifts another plate.
        Qn.PlateValue(app, L_VI_SAMPLE_ASP, rpPlateIx, plateCount, rpViSampleAsp, '-');
        Qn.PlateValue(app, L_VI_SAMPLE_DISP, rpPlateIx, plateCount, rpViSampleDisp, '-');
        Qn.PlateValue(app, L_VI_DILUENT_ASP, rpPlateIx, plateCount, rpViDiluentAsp, '-');
        Qn.PlateValue(app, L_VI_DILUENT_DISP, rpPlateIx, plateCount, rpViDiluentDisp, '-');
        Qn.PlateValue(app, "User.ReaderPayloadHash_List_01", rpPlateIx, plateCount,
            Qn.HashBytes(Encoding.UTF8.GetBytes(payload)), ',');
        bool anyTransfer = rpWells.Any(x => !x.Untouched);
        Qn.PlateValue(app, "User.NormalizationPlateStatus_List_01", rpPlateIx, plateCount, anyTransfer ? "READY" : "FAILED", ',');
        Qn.PlateValue(app, "User.NormalizationPlateRun_List_01", rpPlateIx, plateCount, rpRunId, ',');
        Qn.PlateValue(app, "User.ReaderDataSource_List_01", rpPlateIx, plateCount, rpPayloadIsFixture ? "SYNTHETIC" : "READER", ',');
        WriteCalculationCheckpoint(app);
        Set(app, "User.ReaderPreparedRun_01", "");

        // ---------- 10. VERDICT, ALERT, REPORT ----------
        WriteReport(app);

        int flagged = rpWells.Count(x => x.Flagged);
        if (flagged > 0)
        {
            // NORM-004: "alert the operator BEFORE dispensing." The script owns this surface rather
            // than the method's Show Message, because only a script can write the acknowledgement to
            // the run log — which is what VERIFY-003 and DATA-004 require (D-S18-04).
            string msg = flagged + " of " + rpRowsThisPlate + " wells on plate " + rpPlateIx
                + " could not be given a volume and will be left untouched — they will receive neither "
                + "sample nor diluent.\n\n" + FirstFew(3)
                + "\n\nThe full detail is in the report:\n" + reportPath;
            Alert(app, msg);
            try { app.OutputMsg("[QuantNorm readernorm " + SCRIPT_VERSION + "] " + flagged
                + " flagged well(s) on plate " + rpPlateIx + "; operator alerted before dispensing.",
                true); } catch (Exception) { }
        }

        // A flagged well is NOT a failed run — GEN-007 and NORM-004 both keep the run going, and the
        // untouched wells are recorded rather than fatal. The verdict is about whether volumes were
        // produced at all.
        bool ok = rpWells.Any(x => x.Xfer.Length > 0);
        Set(app, V_NORMOK, ok ? "True" : "False");
        Set(app, "User.ReaderDataSource_01", rpPayloadIsFixture ? "SYNTHETIC" : "READER");
        if (!ok)
        {
            Set(app, V_MESSAGE, "No well on plate " + rpPlateIx + " could be given a transfer volume, so "
                + "there is nothing to dispense.\n\nSee the report: " + reportPath);
            Set(app, V_ABORT, "True");
        }
        else
        {
            Set(app, V_MESSAGE, rpMatched + " of " + rpRowsThisPlate + " wells on plate " + rpPlateIx
                + " were calculated"
                + (flagged > 0 ? "; " + flagged + " flagged and left untouched." : " with no problems found."));
        }
    }

    // =====================================================================================
    //  PAYLOAD ACQUISITION — variable text first, then the file. Never a guessed path.
    // =====================================================================================
    // MM4's ListParser does NOT fail on an out-of-range index — it writes the literal text
    // "INDEX OUT OF RANGE" into its OUTPUT variable and carries on
    // [VERIFIED — mm4-method-building-reference.md:499, and observed live twice on 2026-07-30].
    // That sentinel then travels downstream and detonates somewhere else: on the 14:28 run it reached
    // a VVP96 Aspirate two commands later and surfaced as "Unable to parse the column and row size",
    // ninety seconds and three commands away from the empty list that caused it.
    // Recognising it here turns a confusing downstream parameter error into a statement of what is
    // actually wrong. The parser's "Fail method on error" checkbox does the same thing at source and
    // is the better fix — this is the safety net for when it is not ticked.
    private const string LISTPARSER_OOR = "INDEX OUT OF RANGE";
    private static bool IsListParserError(string v)
    { return v != null && v.Trim().Equals(LISTPARSER_OOR, StringComparison.OrdinalIgnoreCase); }

    private string AcquirePayload(IMMApp app)
    {
        // v0.20.8 — SpectraMax: two section exports + the stored blank, converted to the payload shape
        // the rest of this script already understands. Falls through to the fixture path when no
        // SpectraMax file is bound (offline testing).
        if (IsSpectraMax(app) && (Get(app, V_SMX_READ1).Trim().Length > 0 || Get(app, V_SMX_READ2).Trim().Length > 0))
            return BuildSpectraMaxPayload(app);
        var texts = new List<string>(); var paths = new List<string>();
        foreach (string name in V_PAYLOAD_TEXT)
        {
            string value = Get(app, name);
            if (IsListParserError(value)) { NoteSentinel(name); continue; }
            if (value.Trim().Length > 0 && !texts.Contains(value)) texts.Add(value);
        }
        foreach (string name in V_PAYLOAD_PATH)
        {
            string value = Get(app, name).Trim();
            if (IsListParserError(value)) { NoteSentinel(name); continue; }
            if (value.Length > 0 && !paths.Contains(value)) paths.Add(value);
        }
        Qn.Require(texts.Count <= 1 && paths.Count <= 1,
            "Conflicting reader aliases contain different text or file paths. Bind one output pair and clear other aliases.");
        string fromFile = "";
        if (paths.Count == 1)
        {
            Qn.Require(File.Exists(paths[0]), "Reader result file is missing: " + paths[0]);
            DateTime prepared;
            Qn.Require(DateTime.TryParse(Get(app, "User.ReaderPreparedUtc_01"), null,
                System.Globalization.DateTimeStyles.RoundtripKind, out prepared), "Reader preparation timestamp is missing.");
            Qn.Require(File.GetLastWriteTimeUtc(paths[0]) >= prepared.ToUniversalTime().AddSeconds(-2),
                "The reader result file predates this plate's read. Refresh the results; use the explicit test-fixture mode for synthetic input.");
            fromFile = File.ReadAllText(paths[0]);
            Qn.Require(fromFile.Trim().Length > 0, "The reader result file is empty.");
        }
        if (texts.Count == 1 && paths.Count == 1)
            Qn.Require(texts[0].Replace("\r\n", "\n").Trim() == fromFile.Replace("\r\n", "\n").Trim(),
                "Reader text and file contents disagree. The script will not silently choose one.");
        if (texts.Count == 1 || paths.Count == 1)
        {
            rpPayloadSource = texts.Count == 1 ? "the results variable (fresh per-plate handshake)" : "the current results file";
            rpPayloadVar = paths.Count == 1 ? paths[0] : "ReadPlateResult output alias";
            return texts.Count == 1 ? texts[0] : fromFile;
        }
        string profile = Get(app, V_TESTPROFILE).Trim();
        if (profile.Length > 0)
        {
            Qn.Require(profile.IndexOfAny(Path.GetInvalidFileNameChars()) < 0 && profile.IndexOfAny(new char[] { '/', '\\' }) < 0,
                "Invalid test profile name.");
            bool hardware = app.IsExecuteMode;
            Qn.Require(!hardware || Get(app, "User.SyntheticApprovedRun_01") == rpRunId,
                "Synthetic reader data are not authorized for this hardware run.");
            string wl = Get(app, V_WLFILE), root = Directory.GetParent(Path.GetDirectoryName(wl)).FullName;
            var rowHandles = SplitStrict(Get(app, L_QPLATE));
            var sourceBarcodes = SplitStrict(Get(app, L_SRCBC));
            var originalOrder = SplitStrict(Get(app, "User.ExpectedSourceBarcode_List_01"));
            int firstRow = rowHandles.IndexOf(HDL_LUNATIC + rpPlateIx.ToString("00"));
            Qn.Require(firstRow >= 0 && firstRow < sourceBarcodes.Count, "Cannot associate a fixture with the current source plate.");
            int fixtureIndex = originalOrder.IndexOf(sourceBarcodes[firstRow]) + 1;
            Qn.Require(fixtureIndex > 0, "Fixture source barcode is absent from the original worklist order.");
            string path = Path.Combine(Path.Combine(root, "TestReaderResults"), "PLACEHOLDER_"
                + Path.GetFileNameWithoutExtension(wl) + "_plate" + fixtureIndex + "_" + profile + ".txt");
            Qn.Require(File.Exists(path), "Test reader fixture not found: " + path);
            rpPayloadSource = "SYNTHETIC TEST FIXTURE - not an instrument measurement";
            rpPayloadVar = path; rpPayloadIsFixture = true;
            return File.ReadAllText(path);
        }
        Fail(app, "No reader results arrived after the per-plate preparation step. Connect Get Results at the method placeholder or explicitly configure a test fixture.");
        return null;
    }

    // =====================================================================================
    //  v0.20.8 — SPECTRAMAX: blank store, SoftMax column-format parser, conversion to payload
    // =====================================================================================
    private bool IsSpectraMax(IMMApp app)
    { return Get(app, V_MODEL).Trim().IndexOf("spectramax", StringComparison.OrdinalIgnoreCase) >= 0; }

    private static string BlankVar(int plate) { return "User.BlankPlate" + plate + "_01"; }
    private static string BlankNum(double v) { return double.IsNaN(v) ? "" : Qn.Number(v); }
    private static double SmxNum(string s) { double v; return Qn.TryNumber(s, out v) ? v : double.NaN; }
    private static string SmxCell(string[] row, int i) { return (i >= 0 && i < row.Length) ? row[i].Trim() : ""; }
    private static string SmxKey(string s)
    { return new string((s ?? "").Where(char.IsLetterOrDigit).ToArray()).ToLowerInvariant(); }

    private class SmxTable
    {
        // WellKey -> raw OD at { 230, 260, 280 }; NaN = no value (blank cell, "Range?", "#Sat", ...)
        public Dictionary<string, double[]> Od = new Dictionary<string, double[]>();
        public List<string> Order = new List<string>();
        public Dictionary<string, double> Path = new Dictionary<string, double>();
    }

    static readonly string[] SMX_WELL = new string[] { "well", "wells", "wellposition", "position", "plateposition", "wellid", "wellname" };

    // A header cell names a wavelength when it holds exactly one number and that number is 230, 260 or
    // 280: "260", "A260", "OD260", "260nm", "Abs @ 260" all qualify. Ratios and pathlength do not.
    private static int WaveOf(string cell)
    {
        string c = (cell ?? "").ToLowerInvariant();
        if (c.IndexOf("ratio", StringComparison.Ordinal) >= 0 || c.IndexOf('/') >= 0 || c.IndexOf("path", StringComparison.Ordinal) >= 0) return 0;
        var m = System.Text.RegularExpressions.Regex.Matches(c, "\\d+");
        if (m.Count != 1) return 0;
        int v; if (!int.TryParse(m[0].Value, out v)) return 0;
        return (v == 230 || v == 260 || v == 280) ? v : 0;
    }

    // SoftMax Pro COLUMN (list) export: a header row holding a well column and wavelength columns,
    // then one row per well, ended by a blank line, "~End" or the next "##BLOCKS"/"Plate:" block.
    // Separator detected per header candidate (tab, comma, semicolon). PLATE-format (grid) exports
    // are NOT parsed — the failure says so and shows the first lines, rather than guessing a grid.
    private string ParseSoftMax(string text, string what, out SmxTable t)
    {
        t = new SmxTable();
        string[] lines = text.Replace("\r\n", "\n").Replace('\r', '\n').Split('\n');
        int hdr = -1; char sep = '\t'; int iWell = -1, i230 = -1, i260 = -1, i280 = -1, iPath = -1;
        for (int li = 0; li < lines.Length && hdr < 0; li++)
        {
            foreach (char s in new char[] { '\t', ',', ';' })
            {
                string[] f = lines[li].Split(s);
                if (f.Length < 2) continue;
                int w = -1, a = -1, b = -1, c = -1, p = -1;
                for (int k = 0; k < f.Length; k++)
                {
                    string key = SmxKey(f[k]);
                    if (w < 0 && Array.IndexOf(SMX_WELL, key) >= 0) { w = k; continue; }
                    int wave = WaveOf(f[k]);
                    if (wave == 230) { if (a < 0) a = k; }
                    else if (wave == 260) { if (b < 0) b = k; }
                    else if (wave == 280) { if (c < 0) c = k; }
                    else if (p < 0 && key.IndexOf("path", StringComparison.Ordinal) >= 0) p = k;
                }
                if (w >= 0 && b >= 0)
                { hdr = li; sep = s; iWell = w; i230 = a; i260 = b; i280 = c; iPath = p; break; }
            }
        }
        if (hdr < 0)
            return what + ": no header row with a well column and a 260 nm column was found. Set the SoftMax "
                + "export to COLUMN (list) format, one row per well, with 230/260/280 columns. First lines of the file:\n\n"
                + string.Join("\n", lines.Take(6).ToArray());
        for (int li = hdr + 1; li < lines.Length; li++)
        {
            string line = lines[li];
            if (line.Trim().Length == 0) { if (t.Od.Count > 0) break; continue; }
            if (line.StartsWith("~End", StringComparison.Ordinal) || line.StartsWith("##", StringComparison.Ordinal)
                || line.StartsWith("Plate:", StringComparison.Ordinal)) break;
            string[] f = line.Split(sep);
            string well = Qn.Well(SmxCell(f, iWell));
            if (well.Length == 0) continue;
            string k = WellKey(well);
            if (t.Od.ContainsKey(k))
                return what + ": well " + well + " appears more than once. Export ONE section per file (Export Section As).";
            t.Od[k] = new double[] { SmxNum(SmxCell(f, i230)), SmxNum(SmxCell(f, i260)), SmxNum(SmxCell(f, i280)) };
            t.Order.Add(k);
            double pl = SmxNum(SmxCell(f, iPath));
            if (iPath >= 0 && !double.IsNaN(pl) && pl > 0) t.Path[k] = pl;
        }
        if (t.Od.Count == 0) return what + ": the header row was found but no well rows followed it.";
        return "";
    }

    private string ReadFreshFile(IMMApp app, string variable, string what)
    {
        string p = Get(app, variable).Trim();
        Qn.Require(p.Length > 0 && !IsListParserError(p),
            what + " export path is not set (" + variable + "). Bind it to the file name used by Export Section As.");
        Qn.Require(File.Exists(p), what + " export file is missing: " + p);
        DateTime prepared;
        Qn.Require(DateTime.TryParse(Get(app, "User.ReaderPreparedUtc_01"), null,
            System.Globalization.DateTimeStyles.RoundtripKind, out prepared), "Reader preparation timestamp is missing.");
        Qn.Require(File.GetLastWriteTimeUtc(p) >= prepared.ToUniversalTime().AddSeconds(-2),
            what + " export predates this plate's read - it is a stale file, not this read: " + p);
        string text = File.ReadAllText(p);      // honours a UTF-8/UTF-16 BOM; SoftMax may write either
        Qn.Require(text.Trim().Length > 0, what + " export is empty: " + p);
        return text;
    }

    private void RunBlankPhase(IMMApp app, List<int> rows, List<string> qWell)
    {
        Qn.Require(IsSpectraMax(app), "A BLANK phase is only defined for the SpectraMax reader.");
        string text = ReadFreshFile(app, V_SMX_BLANK, "Blank read");
        SmxTable t; string err = ParseSoftMax(text, "Blank read", out t);
        if (err.Length > 0) { Fail(app, "The blank read could not be used.\n\n" + err); return; }
        var sb = new StringBuilder(); sb.Append("RUN=").Append(rpRunId);
        var missing = new List<string>();
        foreach (int i in rows)
        {
            string k = WellKey(qWell[i]); double[] od;
            if (!t.Od.TryGetValue(k, out od) || double.IsNaN(od[1])) { missing.Add(qWell[i]); continue; }
            sb.Append(';').Append(k).Append('=').Append(BlankNum(od[0])).Append('|')
              .Append(BlankNum(od[1])).Append('|').Append(BlankNum(od[2]));
        }
        if (missing.Count > 0)
        {
            Fail(app, "The blank read has no 260 nm value for " + missing.Count + " sample well(s): " + Join(missing)
                + "\n\nEvery sample well needs its own blank (per-well pre-read). Check the quant-plate diluent "
                + "fill and the SoftMax \"Blank\" section, then re-run.");
            return;
        }
        Set(app, BlankVar(rpPlateIx), sb.ToString());
        try
        {
            File.WriteAllText(Path.Combine(Get(app, V_REPORTDIR), "QuantNorm_blank_" + rpRunId + "_plate" + rpPlateIx + ".txt"),
                "Blank (raw OD 230|260|280) for plate " + rpPlateIx + "\r\nSource: " + Get(app, V_SMX_BLANK) + "\r\n"
                + sb.ToString().Replace(";", "\r\n"));
        }
        catch (Exception ex) { notes.Add("Blank trace file not written: " + ex.Message); }
        Set(app, V_PHASE, "");
        try { app.OutputMsg("[QuantNorm readernorm " + SCRIPT_VERSION + "] blank stored for plate " + rpPlateIx
            + " (" + rows.Count + " sample wells).", false); } catch (Exception) { }
    }

    private static string Conv(double raw, double[] blank, int ix, double df, double cm)
    {
        if (double.IsNaN(raw) || blank == null || double.IsNaN(blank[ix])) return "";
        return Qn.Number((raw - blank[ix]) * df / cm);
    }

    private string BuildSpectraMaxPayload(IMMApp app)
    {
        string p1 = Get(app, V_SMX_READ1).Trim(), p2 = Get(app, V_SMX_READ2).Trim();
        string r1 = ReadFreshFile(app, V_SMX_READ1, "Read_1");
        string r2 = ReadFreshFile(app, V_SMX_READ2, "Read_2");
        SmxTable t1, t2;
        string e = ParseSoftMax(r1, "Read_1", out t1);
        string e2 = ParseSoftMax(r2, "Read_2", out t2);
        Qn.Require(e.Length == 0 && e2.Length == 0, "The SpectraMax results could not be read.\n\n" + e + (e.Length > 0 && e2.Length > 0 ? "\n\n" : "") + e2);

        string stored = Get(app, BlankVar(rpPlateIx));
        Qn.Require(stored.StartsWith("RUN=" + rpRunId + ";", StringComparison.Ordinal),
            "No blank is stored for plate " + rpPlateIx + " of this run. The per-well pre-read (BLANK phase) must run "
            + "after the quant diluent fill and before the sample stamp.");
        var blank = new Dictionary<string, double[]>();
        foreach (string part in stored.Split(';').Skip(1))
        {
            int eq = part.IndexOf('='); if (eq < 1) continue;
            string[] v = part.Substring(eq + 1).Split('|');
            blank[part.Substring(0, eq)] = new double[] { SmxNum(SmxCell(v, 0)), SmxNum(SmxCell(v, 1)), SmxNum(SmxCell(v, 2)) };
        }

        double df;
        Qn.Require(Qn.TryNumber(Get(app, V_DF), out df) && df >= 1,
            "QuantDilutionFactor_01 is missing or below 1. Re-run worklist ingestion (v0.8.9 or later).");
        double pathCfg; bool haveCfg = Qn.TryNumber(Get(app, V_PATHCM), out pathCfg) && pathCfg > 0 && pathCfg <= 1;
        double lowOd; if (!Qn.TryNumber(Get(app, V_LOWOD), out lowOd) || lowOd < 0) lowOd = 0.01;
        string plateId = Get(app, "User.ReaderExpectedPlateID_01").Replace(",", " ");

        var payload = new StringBuilder("Plate ID,Well,A260_1,A260_2,A280,A230\n");
        var trace = new StringBuilder("Well\tRaw260_1\tRaw260_2\tRaw280\tRaw230\tBlank260\tBlank280\tBlank230\tDF\tPathCm\tPathSource\tA260_1eq\tA260_2eq\tA280eq\tA230eq\tLowSignal\r\n");
        var noPath = new List<string>();
        foreach (string k in t1.Order)
        {
            double[] a = t1.Od[k]; double[] b; t2.Od.TryGetValue(k, out b);
            double[] bl; blank.TryGetValue(k, out bl);
            if (bl == null) continue;                    // not a sample well on this plate: no blank, no row
            double cm; string src = "PathCheck";
            if (!t1.Path.TryGetValue(k, out cm)) { if (haveCfg) { cm = pathCfg; src = "configured"; } else { noPath.Add(k); continue; } }
            string e1 = Conv(a[1], bl, 1, df, cm), e2v = b == null ? "" : Conv(b[1], bl, 1, df, cm);
            string e280 = Conv(a[2], bl, 2, df, cm), e230 = Conv(a[0], bl, 0, df, cm);

            // low_signal on the blank-corrected RAW A260 (what the reader actually resolved)
            var corr = new List<double>();
            if (!double.IsNaN(a[1]) && !double.IsNaN(bl[1])) corr.Add(a[1] - bl[1]);
            if (b != null && !double.IsNaN(b[1]) && !double.IsNaN(bl[1])) corr.Add(b[1] - bl[1]);
            bool low = corr.Count > 0 && corr.Average() < lowOd;
            if (low) lowSignalWells.Add(k);

            payload.Append(plateId).Append(',').Append(k).Append(',').Append(e1).Append(',').Append(e2v)
                   .Append(',').Append(e280).Append(',').Append(e230).Append('\n');
            trace.Append(k).Append('\t').Append(BlankNum(a[1])).Append('\t').Append(b == null ? "" : BlankNum(b[1]))
                 .Append('\t').Append(BlankNum(a[2])).Append('\t').Append(BlankNum(a[0]))
                 .Append('\t').Append(BlankNum(bl[1])).Append('\t').Append(BlankNum(bl[2])).Append('\t').Append(BlankNum(bl[0]))
                 .Append('\t').Append(Qn.Number(df)).Append('\t').Append(Qn.Number(cm)).Append('\t').Append(src)
                 .Append('\t').Append(e1).Append('\t').Append(e2v).Append('\t').Append(e280).Append('\t').Append(e230)
                 .Append('\t').Append(low ? "yes" : "").Append("\r\n");
        }
        Qn.Require(noPath.Count == 0, "No pathlength for " + noPath.Count + " well(s) (" + Join(noPath) + "). Either export a "
            + "per-well PathCheck pathlength column, or set ReaderPathlengthCm in the worklist header (calibrated for this plate type and fill volume).");
        try
        {
            File.WriteAllText(Path.Combine(Get(app, V_REPORTDIR), "QuantNorm_spectramax_" + rpRunId + "_plate" + rpPlateIx + ".txt"),
                "SpectraMax conversion, plate " + rpPlateIx + ": A_eq = (A_raw - A_blank) x DF / PathCm\r\nRead_1: " + p1
                + "\r\nRead_2: " + p2 + "\r\nLowSignalOD: " + Qn.Number(lowOd) + "\r\n\r\n" + trace.ToString());
        }
        catch (Exception ex) { notes.Add("SpectraMax trace file not written: " + ex.Message); }
        if (lowSignalWells.Count > 0)
            notes.Add(lowSignalWells.Count + " well(s) read below the low-signal limit (blank-corrected raw A260 < "
                + Qn.Number(lowOd) + " OD) and are flagged low_signal: " + Join(lowSignalWells.ToList()));
        rpPayloadSource = "SpectraMax section exports Read_1 + Read_2, per-well blank-corrected, x" + Qn.Number(df)
            + " dilution, normalized to 1 cm";
        rpPayloadVar = p1 + " | " + p2;
        return payload.ToString();
    }

    // =====================================================================================
    //  THE PARSER — header-keyed, separator-detected, "-" respected, fail-loud on a missing column
    // =====================================================================================
    private class ReaderRow
    {
        public string Well = "", PlateId = "";
        public string A260_1 = "", A260_2 = "", A280 = "", A230 = "";
    }

    private class ReaderTable
    {
        public List<ReaderRow> Rows = new List<ReaderRow>();
        public List<string> PlateIds = new List<string>();
        public string SeparatorName = "";
        public List<string> Headers = new List<string>();

        public ReaderRow Find(string well)
        {
            string k = WellKey(well);
            for (int i = 0; i < Rows.Count; i++)
                if (WellKey(Rows[i].Well) == k) return Rows[i];
            return null;
        }
        public List<string> WellsPresent()
        {
            var l = new List<string>();
            for (int i = 0; i < Rows.Count; i++) if (Rows[i].Well.Length > 0) l.Add(Rows[i].Well);
            return l;
        }
    }

    // The column names we need, each with the spellings seen or plausibly configured. Keyed by
    // NAME because the Results Definition String can reorder and rename them — never by position.
    static readonly string[] H_WELL   = new string[] { "Plate Position", "Position", "Well", "Well Position" };
    static readonly string[] H_PLATE  = new string[] { "Plate ID", "PlateID", "Plate" };
    static readonly string[] H_A260_1 = new string[] { "A260_1", "A260 1", "A260" };
    static readonly string[] H_A260_2 = new string[] { "A260_2", "A260 2" };
    // "Background (A280)" is deliberately NOT accepted as an A280 synonym. It appears in the KB's
    // reference output, but that is a protein/turbidity application and the column is a BACKGROUND
    // reading, not the sample's A280 absorbance. Treating them as the same column would compute a
    // 260/280 purity ratio out of the wrong number and print it as if it meant something.
    static readonly string[] H_A280   = new string[] { "A280" };
    static readonly string[] H_A230   = new string[] { "A230" };

    private string ParsePayload(string payload, out ReaderTable table)
    {
        table = new ReaderTable();

        string[] lines = Qn.Records(payload).ToArray();
        int hdr = -1;
        for (int i = 0; i < lines.Length; i++)
            if (lines[i].Trim().Length > 0) { hdr = i; break; }
        if (hdr < 0) return "The results are empty — there is not even a header row.";

        // SEPARATOR DETECTION. The Results Definition String can set it to ";", "," or tab, so it is
        // detected from the header line rather than assumed. Whichever candidate splits the header
        // into the most fields wins; a tie goes to the one the KB asset actually uses.
        char sep = ';'; string sepName = "semicolon";
        int best = lines[hdr].Split(';').Length;
        int cComma = lines[hdr].Split(',').Length;
        int cTab = lines[hdr].Split('\t').Length;
        if (cTab > best) { sep = '\t'; sepName = "tab"; best = cTab; }
        if (cComma > best) { sep = ','; sepName = "comma"; best = cComma; }
        if (best < 2) return "The header row could not be split into columns by semicolon, comma or "
            + "tab, so the results format was not recognised. The first line was:\n\n" + lines[hdr].Trim();
        table.SeparatorName = sepName;

        string[] head = Qn.Fields(lines[hdr], sep);
        for (int i = 0; i < head.Length; i++) table.Headers.Add(head[i].Trim());

        if (table.Headers.Select(Key).Distinct().Count() != table.Headers.Count) return "Duplicate reader column headings.";
        int iWell = Col(table.Headers, H_WELL);
        int iPlate = Col(table.Headers, H_PLATE);
        int i260a = Col(table.Headers, H_A260_1);
        int i260b = Col(table.Headers, H_A260_2);
        int i280 = Col(table.Headers, H_A280);
        int i230 = Col(table.Headers, H_A230);

        // FAIL LOUD, WITH THE COLUMN NAMED. The two that are structurally required are the well
        // position and at least one A260 column — without them there is nothing to normalize from.
        if (iWell < 0)
            return "The results have no well-position column. Looked for: " + string.Join(", ", H_WELL)
                 + "\n\nColumns actually present: " + Join(table.Headers)
                 + "\n\nThe column set is configurable through the Results Definition String, so this "
                 + "is a configuration to correct rather than a reader fault.";
        if (i260a < 0)
            return "The results have no A260 column. Looked for: " + string.Join(", ", H_A260_1)
                 + "\n\nColumns actually present: " + Join(table.Headers)
                 + "\n\nEvery volume on the plate is derived from A260, so nothing can be calculated. "
                 + "Note the reference output we hold is a PROTEIN application and carries no A260 at "
                 + "all — the RNA column set has to be configured in the Results Definition String.";

        // A230 and the duplicate A260 are reported as missing rather than fatal: A230 only feeds a
        // purity ratio that does not block normalization (GEN-007), and a missing A260_2 is caught
        // per-well by the QUANT-004 duplicate check, where it can name the specific well.
        if (i260b < 0)
            notes.Add("The results carry no second A260 column (looked for " + string.Join(", ", H_A260_2)
                + "), so QUANT-004's duplicate agreement cannot be evaluated and every well is treated "
                + "as having a single read. If the duplicate arrives as a second Get Results call "
                + "rather than a second column, that is design question Q1 and the pairing has to be "
                + "built to match.");
        if (i230 < 0)
            notes.Add("The results carry no A230 column, so the A260/A230 purity ratio (QUANT-007) was "
                + "not computed. It does not block normalization (GEN-007).");
        if (i280 < 0)
            notes.Add("The results carry no A280 column, so the A260/A280 purity ratio (QUANT-007) was "
                + "not computed. It does not block normalization (GEN-007).");

        for (int i = hdr + 1; i < lines.Length; i++)
        {
            string line = lines[i];
            if (line.Trim().Length == 0) continue;
            string[] f = Qn.Fields(line, sep);

            if (f.Length != table.Headers.Count) return "Reader record has a different field count than its header.";
            var r = new ReaderRow();
            r.Well = Cell(f, iWell);
            r.PlateId = Cell(f, iPlate);
            r.A260_1 = NoResult(Cell(f, i260a));
            r.A260_2 = NoResult(Cell(f, i260b));
            r.A280 = NoResult(Cell(f, i280));
            r.A230 = NoResult(Cell(f, i230));

            if (r.Well.Length == 0) continue;    // a trailing/summary line, not a well

            if (Qn.Well(r.Well).Length == 0) return "Invalid reader well label: " + r.Well;
            // Duplicate well positions in one payload would make Find() ambiguous, and picking the
            // first would silently discard a reading.
            if (table.Find(r.Well) != null)
                return "The results list well " + r.Well + " more than once. This script matches one "
                     + "reader row per well, so it cannot tell which reading applies.\n\nIf the "
                     + "duplicate read arrives as two ROWS per well rather than two columns, that is "
                     + "design question Q1 and the pairing step has to be built for it.";

            table.Rows.Add(r);
            if (r.PlateId.Length > 0 && !table.PlateIds.Contains(r.PlateId)) table.PlateIds.Add(r.PlateId);
        }

        if (table.Rows.Count == 0)
            return "The results carry a header row but no well rows.";

        lastHeaders = table.Headers;    // so the report can print the columns it actually saw
        return "";
    }

    // "-" is the reader's no_result_value default and appears live in the KB asset. It is NOT zero
    // and NOT a parse error — it means this position produced no measurement, so it is normalised to
    // an empty string and handled as absence everywhere downstream.
    private static string NoResult(string v)
    {
        string t = (v ?? "").Trim();
        if (t == "-" || t == "N/A" || t == "NA") return "";
        return t;
    }

    // =====================================================================================
    //  QUANT-007 — purity ratios, and an honest PurityFlag
    // =====================================================================================
    // The ratios are always computed when the inputs exist. The FLAG is where care is needed:
    // QUANT-TBD-003 and QUANT-TBD-004 leave both thresholds unanswered, offering <1.70 only as a
    // "reference" and noting tissue-derived samples often run lower. Writing "pass" against a
    // threshold nobody has set would be a false pass in a field the customer reads, so an unconfigured
    // threshold yields the spec's own catch-all value "other" and the report explains why. The enum
    // is the customer's (Appendix B field 25) and is not ours to extend.
    const string V_TH_280 = "User.PurityThreshold_A260_A280_01";
    const string V_TH_230 = "User.PurityThreshold_A260_A230_01";

    private void Purity(WellResult w, ReaderRow rr, double accepted)
    {
        double a280, a230, t280, t230;
        bool has280 = TryNum(rr.A280, out a280) && a280 > 0;
        bool has230 = TryNum(rr.A230, out a230) && a230 > 0;
        bool threshold280 = TryNum(purityTh280, out t280) && t280 > 0;
        bool threshold230 = TryNum(purityTh230, out t230) && t230 > 0;
        if (has280) w.R260_280 = Num(accepted / a280);
        if (has230) w.R260_230 = Num(accepted / a230);
        // v0.20.8 — a reading too close to the blank makes both ratios noise; say so first.
        if (lowSignalWells.Contains(WellKey(w.QWell))) { w.Purity = PF_LOW; return; }
        if (threshold280 && has280 && accepted / a280 < t280) { w.Purity = PF_A280; return; }
        if (threshold230 && has230 && accepted / a230 < t230) { w.Purity = PF_A230; return; }
        // A pass means BOTH required ratios were actually evaluated against configured thresholds.
        w.Purity = threshold280 && threshold230 && has280 && has230 ? PF_PASS : PF_OTHER;
    }
    private string purityTh280 = "", purityTh230 = "";

    // =====================================================================================
    //  VI SERIALISATION
    // =====================================================================================
    // string[97]: index 0 is the header, 1..96 are the per-well data fields. Untouched entries stay
    // null and render as EMPTY between the commas — which is what the production precedent produces
    // and what "this channel does nothing" looks like in a VI string. A bare volume is equivalent to
    // "<vol>;0;0", so no air-gap sub-fields are written unless they are non-zero
    // [Jim-verified 2026-06-05, mm4-data-formats-reference.md:152].
    // "<vol>;<leadingGap>;<trailingGap>" — the gap has to be written explicitly, because an omitted
    // sub-field defaults to 0 and a VI overrides the command grid (Jim, 2026-07-31).
    private static string AspField(double v)
    {
        return Num(v) + ";" + Num(ASP_LEAD_GAP_UL) + ";" + Num(ASP_TRAIL_GAP_UL);
    }

    // The over-dispense stroke. Clamped at the validated VVP96 maximum: commanding more than the
    // channel supports is not a bigger blow-out, it is an error waiting for a large-volume run.
    private static double Overage(double v)
    {
        double x = v + DISPENSE_OVERAGE_UL;
        return x > VVP96_MAX_UL ? VVP96_MAX_UL : x;
    }

    private static string[] NewViGrid()
    {
        var g = new string[GRID_WELLS + 1];
        g[0] = "VI;" + GRID_COLS + ";" + GRID_ROWS;
        return g;
    }

    // Channel index = 12*row + col + 1. A01=1, A02=2, B01=13, H12=96 — row-major, and this is a
    // CORRECTED fact: the KB said column-major until v1.4.0, checked against four independent
    // sources including two production scripts. Getting it wrong transposes every volume on the
    // plate, so it is derived from the label here and never from the worklist's row order.
    private static int ChannelOf(string well)
    { return Qn.Channel(well); }

    // Well labels are compared through this so A1 and A01 are the same well. The KB asset's
    // Plate Position values are unpadded (B1, not B01) and so are our worklist's wells — but
    // "so are ours" is not a reason to trust either side's padding, so both are normalised.
    private static string WellKey(string well)
    {
        string w = (well ?? "").Trim().ToUpperInvariant();
        if (w.Length < 2) return w;
        int col;
        if (!int.TryParse(w.Substring(1), out col)) return w;
        return w.Substring(0, 1) + col.ToString("D2");
    }
    private static bool SameWell(string a, string b) { return WellKey(a) == WellKey(b); }

    // =====================================================================================
    //  FAILURE + OPERATOR SURFACE
    // =====================================================================================
    private void Fail(IMMApp app, string message)
    {
        Add("The normalization calculation stopped", "plate " + rpPlateIx, Flatten(message), "");
        Set(app, V_NORMOK, "False");
        Set(app, V_MESSAGE, message);
        Set(app, V_ABORT, "True");
        try { app.OutputMsg("[QuantNorm readernorm " + SCRIPT_VERSION + "] FAILED: " + Flatten(message),
            true); } catch (Exception) { }
        WriteReport(app);
    }

    private void Flag(WellResult w, string why)
    {
        w.Flagged = true;
        w.FlagWhy = w.FlagWhy.Length > 0 ? w.FlagWhy + "; " + why : why;
    }

    private void Add(string what, string where, string detail, string fix)
    {
        var p = new Problem();
        p.What = what; p.Where = where; p.Detail = detail; p.Fix = fix;
        problems.Add(p);
    }

    // VIRTUAL for the same reason barcode validation's AskOperator is: the offline harness runs the
    // flagged-well paths dozens of times, and without a seam every one of them would put a modal
    // dialog on the screen. A test-only branch inside the production path would mean the tests
    // exercise a route the instrument never takes (D-S18-24), so the seam goes here instead.
    public virtual void Alert(IMMApp app, string message)
    {
        try
        {
            MessageBox.Show(message, "Normalization — wells flagged before dispensing",
                MessageBoxButtons.OK, MessageBoxIcon.Warning);
        }
        catch (Exception) { }
    }

    public virtual void OpenReport(string path)
    { try { Process.Start(new ProcessStartInfo(path) { UseShellExecute = true }); } catch (Exception) { } }

    // =====================================================================================
    //  THE REPORT
    // =====================================================================================
    private const string PLATE_SENTINEL = "<!--PLATES-->";

    private void WriteReport(IMMApp app)
    {
        if (reportWritten) return;
        reportWritten = true;
        try
        {
            // Read the purity thresholds here as well as in Purity(), so a report written from the
            // failure path still states what they were.
            purityTh280 = Get(app, V_TH_280).Trim();
            purityTh230 = Get(app, V_TH_230).Trim();

            bool inWorkspace;
            string dir = ResolveReportDir(app, out inWorkspace);
            reportInWorkspace = inWorkspace;
            string runId = rpRunId.Length > 0 ? rpRunId : "NORUNID";
            string path = Path.Combine(dir, "QuantNorm_normalization_" + runId + ".html");

            string block = BuildPlateBlock(app);
            string html;
            if (File.Exists(path))
            {
                string prior = File.ReadAllText(path);
                int at = prior.IndexOf(PLATE_SENTINEL, StringComparison.Ordinal);
                html = at >= 0 ? prior.Substring(0, at) + block + prior.Substring(at)
                               : prior + block;
            }
            else html = BuildShell(runId, block);

            File.WriteAllText(path, html, new UTF8Encoding(false));
            reportPath = path;

            if (problems.Count > 0) OpenReport(path);
            try { app.OutputMsg("[QuantNorm readernorm " + SCRIPT_VERSION + "] report: " + path, false); }
            catch (Exception) { }
        }
        catch (Exception ex)
        {
            try { app.OutputMsg("[QuantNorm readernorm " + SCRIPT_VERSION + "] REPORT NOT WRITTEN: "
                + ex.Message, true); } catch (Exception) { }
            throw new IOException("Normalization report could not be saved.", ex);
        }
    }

    // Same rule and the same reasoning as the other two spine scripts (Jim, S18): a report that will
    // be used in production MUST live inside the WORKSPACE. The workspace is the unit that travels;
    // %TEMP% is swept by Windows on its own schedule, and a record that can silently disappear is
    // not a record. DATA-006 requires run summary reports saved to local storage and DATA-003 a
    // defined location reachable from the configured operating sites — a per-user temp path is neither.
    private string ResolveReportDir(IMMApp app, out bool inWorkspace)
    {
        inWorkspace = true;
        try
        {
            string wp = app.WorkspaceOutputPath;
            if (wp != null && wp.Trim().Length > 0)
            {
                wp = wp.Trim();
                if (!Directory.Exists(wp)) { try { Directory.CreateDirectory(wp); } catch (Exception) { } }
                if (Directory.Exists(wp)) return wp;
            }
        }
        catch (Exception) { }

        string raw = Get(app, V_REPORTDIR).Trim();
        if (raw.Length > 0)
        {
            if (Directory.Exists(raw)) return raw;
            try
            {
                string parent = Path.GetDirectoryName(raw);
                if (parent != null && parent.Length > 0 && Directory.Exists(parent)) return parent;
            }
            catch (Exception) { }
        }

        inWorkspace = false;
        try { app.OutputMsg("[QuantNorm readernorm " + SCRIPT_VERSION + "] ⚠ THE WORKSPACE OUTPUT FOLDER "
            + "COULD NOT BE RESOLVED. The report has been written to the temp folder instead, which is "
            + "NOT a production location - temp is swept and does not travel with the workspace.", true); }
        catch (Exception) { }
        return Path.GetTempPath();
    }

    private string BuildShell(string runId, string firstBlock)
    {
        var h = new StringBuilder();
        h.Append("<!DOCTYPE html><html><head><meta charset='utf-8'>");
        h.Append("<title>QuantNorm normalization - ").Append(E(runId)).Append("</title><style>");
        h.Append("body{font-family:Segoe UI,Arial,sans-serif;margin:24px;color:#1a1a1a;background:#fff}");
        h.Append("h1{font-size:20px;margin:0 0 4px}h2{font-size:15px;margin:22px 0 6px;border-bottom:1px solid #ddd;padding-bottom:3px}");
        h.Append("h3{font-size:13px;margin:14px 0 4px;color:#444}");
        h.Append("table{border-collapse:collapse;margin:6px 0 12px;font-size:12px}");
        h.Append("th,td{border:1px solid #ccc;padding:3px 7px;text-align:left;vertical-align:top}");
        h.Append("th{background:#f2f2f2;font-weight:600}");
        h.Append(".mono{font-family:Consolas,monospace}");
        h.Append(".att{border:2px solid #888;border-radius:5px;padding:12px 16px;margin:18px 0;background:#fbfbfb}");
        h.Append(".pass{border-color:#2e7d32}.fail{border-color:#c62828}");
        h.Append(".v-pass{color:#2e7d32;font-weight:700}.v-fail{color:#c62828;font-weight:700}");
        h.Append(".warn{background:#fff8e1;border:1px solid #f0c36d;padding:8px 12px;margin:8px 0;border-radius:4px}");
        h.Append(".sub{color:#666;font-size:12px}.empty{color:#999;font-style:italic}");
        h.Append(".flag{background:#fff3f3}");
        h.Append("td.n{text-align:right}");
        h.Append("@media print{body{margin:8mm}.att{break-inside:avoid}}");
        h.Append("</style></head><body>\n");
        h.Append("<h1>Normalization calculation - run ").Append(E(runId)).Append("</h1>\n");
        h.Append("<div class='sub'>QuantNorm_ReaderNormVI ").Append(SCRIPT_VERSION)
         .Append(" &middot; DEV / TESTING RECORD &middot; one block per plate, newest last</div>\n");
        h.Append(firstBlock);
        h.Append(PLATE_SENTINEL).Append("\n</body></html>");
        return h.ToString();
    }

    private string BuildPlateBlock(IMMApp app)
    {
        int flagged = rpWells.Count(x => x.Flagged);
        bool ok = computeReached && problems.Count == 0;
        var h = new StringBuilder();
        h.Append("<div class='att ").Append(ok ? "pass" : "fail").Append("'>\n");
        h.Append("<h2>Plate ").Append(rpPlateIx).Append(" &mdash; ")
         .Append(ok ? "<span class='v-pass'>CALCULATED</span>"
                    : "<span class='v-fail'>PROBLEMS FOUND</span>").Append("</h2>\n");

        // ---- run context ----
        h.Append("<table><tr><th>Written</th><td class='mono'>").Append(E(Now())).Append("</td></tr>");
        h.Append("<tr><th>Run ID</th><td class='mono'>").Append(E(rpRunId)).Append("</td></tr>");
        h.Append("<tr><th>Script</th><td class='mono'>QuantNorm_ReaderNormVI ").Append(SCRIPT_VERSION).Append("</td></tr>");
        h.Append("<tr><th>Worklist</th><td class='mono'>").Append(E(Get(app, V_WLFILE))).Append("</td></tr>");
        h.Append("<tr><th>Scale</th><td>").Append(rpRowsThisPlate).Append(" row(s) on this plate, ")
         .Append(rpRows).Append(" in the run</td></tr>");
        h.Append("<tr><th>Plate number</th><td>").Append(rpPlateIx)
         .Append(" &mdash; taken from <span class='mono'>").Append(E(rpPlateIxSource))
         .Append("</span><div class='sub'>Stated because getting this wrong would normalise this "
            + "plate's wells against another plate's readings, and nothing downstream would say so."
            + "</div></td></tr>");
        h.Append("<tr><th>Reader plate ID</th><td class='mono'>")
         .Append(rpPlateId.Length > 0 ? E(rpPlateId) : "<span class='empty'>not reported</span>").Append("</td></tr>");
        h.Append("<tr><th>Reader rows</th><td>").Append(rpPayloadRows)
         .Append(" well row(s) in the payload vs ").Append(rpRowsThisPlate)
         .Append(" sample row(s) on this plate")
         .Append(rpPayloadRows == rpRowsThisPlate ? "" :
            " <b class='v-fail'>&mdash; these differ</b>").Append("</td></tr>");
        h.Append("<tr><th>Results came from</th><td>")
         .Append(rpPayloadSource.Length > 0
            ? E(rpPayloadSource) + " (<span class='mono'>" + E(rpPayloadVar) + "</span>), "
              + E(rpSeparator) + "-separated"
            : "<span class='empty'>no payload was read</span>")
         .Append("<div class='sub'>Get Results is dual-output &mdash; delimited text in a variable AND a "
            + "file whose path it hands back. Either is accepted; no path is ever guessed.</div></td></tr>");

        // RUN MODE — read from MM4, not declared. D-S19-01.
        bool execMode; string modeNote;
        try
        {
            execMode = app.IsExecuteMode;
            modeNote = execMode
                ? "<b>Hardware Execute mode</b> &mdash; read from <span class='mono'>IMMApp.IsExecuteMode</span>."
                : "<b>Test mode (simulation)</b> &mdash; read from <span class='mono'>IMMApp.IsExecuteMode</span>. "
                + "Nothing here is evidence about the Lunatic, the reader mapping, or dispensed volumes.";
        }
        catch (Exception ex)
        {
            modeNote = "<b class='v-fail'>COULD NOT BE READ</b> &mdash; <span class='mono'>IsExecuteMode</span> "
                     + "threw: " + E(ex.Message) + ". Treat the run mode as unknown rather than assuming either.";
        }
        h.Append("<tr><th>Run mode</th><td>").Append(modeNote).Append("</td></tr>");

        string tm = Get(app, V_TESTMODE).Trim();
        h.Append("<tr><th>Instrument connection</th><td>")
         .Append(tm.Length == 0
            ? "<span class='empty'>NOT DECLARED</span> &mdash; whether a Lynx is physically connected is not "
              + "exposed to a script, so unlike the run mode above it cannot be read."
            : E(tm))
         .Append("</td></tr>");
        if (!reportInWorkspace)
            h.Append("<tr><th>⚠ Location</th><td class='v-fail'>This report was NOT written inside the "
                + "workspace, so it is not a production record.</td></tr>");
        h.Append("</table>\n");

        // ---- the configured values every volume depends on ----
        h.Append("<h3>Configured values</h3><table>");
        h.Append("<tr><th>TargetConcentration</th><td class='n'>").Append(Num(rpTarget)).Append(" ng/&micro;L</td><td>")
         .Append(rpTargetDefaulted
            ? "<b>DEFAULTED</b> &mdash; the worklist header carried none, so NORM-007's default was used."
            : "from the worklist header block").Append("</td></tr>");
        h.Append("<tr><th>RequestedOutputVolume</th><td class='n'>").Append(Num(rpOutVol)).Append(" &micro;L</td><td>"
            + "from the worklist header block; no default exists (TBD-013)</td></tr>");
        h.Append("<tr><th>ExtinctionCoefficientUsed</th><td class='n'>").Append(Num(rpExtCoef)).Append("</td><td>")
         .Append(rpExtCoefDefaulted
            ? "<b>DEFAULTED</b> &mdash; QUANT-005 / QUANT-TBD-002 generic ssRNA value"
            : "from the worklist header block")
         .Append(" &mdash; (&micro;g/mL)<sup>&minus;1</sup>cm<sup>&minus;1</sup>, i.e. ~"
            + Num(1.0 / rpExtCoef) + " &micro;g/mL per A260 unit</td></tr>");
        h.Append("<tr><th>A260AcceptanceLogic</th><td colspan='2'>").Append(E(rpAcceptMode)).Append("</td></tr>");
        h.Append("<tr><th>Duplicate tolerance</th><td colspan='2'>").Append(Pct(DUP_TOLERANCE))
         .Append(", taken as a fraction of the <b>")
         .Append(AGREEMENT_BASIS == "LOWER" ? "lower of the two reads" : "mean of the two reads")
         .Append("</b>. <span class='sub'>QUANT-004 says the reads must agree within 10% and does not say "
            + "10% of what. This is an interpretation, stated so it can be corrected &mdash; design "
            + "question Q3, not yet asked of the customer.</span></td></tr>");
        h.Append("<tr><th>Purity thresholds</th><td colspan='2'>");
        if (purityTh280.Length == 0 && purityTh230.Length == 0)
            h.Append("<b>NOT CONFIGURED</b> &mdash; QUANT-TBD-003 and QUANT-TBD-004 are unanswered "
                + "(&lt;1.70 is offered only as a reference, and tissue-derived samples often run lower). "
                + "The ratios below are computed and shown, but no well is called pass or fail: PurityFlag "
                + "is written as <span class='mono'>other</span> rather than <span class='mono'>pass</span>, "
                + "because a pass against a threshold nobody has set would be a false pass in a field the customer "
                + "reads. Purity does not block normalization either way (GEN-007).");
        else
            h.Append("A260/A280 &lt; <span class='mono'>" + E(purityTh280) + "</span>, A260/A230 &lt; "
                + "<span class='mono'>" + E(purityTh230) + "</span>");
        h.Append("</td></tr>");
        h.Append("<tr><th>VVP96 range</th><td colspan='2'>").Append(Num(VVP96_MIN_UL)).Append(" &ndash; ")
         .Append(Num(VVP96_MAX_UL)).Append(" &micro;L per channel <span class='sub'>&mdash; DD's validated "
            + "figure. It can go lower with validation; that is a commercial answer, not a number this "
            + "script widens on its own.</span></td></tr>");
        h.Append("</table>\n");

        // ---- problems ----
        if (problems.Count > 0)
        {
            h.Append("<h3>Problems &mdash; ").Append(problems.Count).Append("</h3>");
            h.Append("<table><tr><th>What</th><th>Where</th><th>Why</th><th>How to fix</th></tr>");
            for (int i = 0; i < problems.Count; i++)
                h.Append("<tr><td>").Append(E(problems[i].What)).Append("</td><td>")
                 .Append(E(problems[i].Where)).Append("</td><td>").Append(E(problems[i].Detail))
                 .Append("</td><td>").Append(E(problems[i].Fix)).Append("</td></tr>");
            h.Append("</table>\n");
        }

        // ---- per-well ----
        if (rpWells.Count > 0)
        {
            h.Append("<h3>Per-well calculation &mdash; ").Append(rpMatched).Append(" of ")
             .Append(rpRowsThisPlate).Append(" rows matched a reader result, ").Append(flagged)
             .Append(" flagged</h3>");
            h.Append("<table><tr><th>Row</th><th>Source</th><th>Quant</th><th>Output</th><th>Ch</th>"
                + "<th>A260_1</th><th>A260_2</th><th>Accepted</th><th>A280</th><th>A230</th>"
                + "<th>260/280</th><th>260/230</th><th>Conc<br>ng/&micro;L</th>"
                + "<th>Transfer<br>&micro;L</th><th>Diluent<br>&micro;L</th><th>Purity</th><th>Note</th></tr>");
            for (int i = 0; i < rpWells.Count; i++)
            {
                WellResult w = rpWells[i];
                h.Append("<tr").Append(w.Flagged ? " class='flag'" : "").Append(">");
                h.Append("<td class='n'>").Append(w.Row + 1).Append("</td>");
                h.Append("<td class='mono'>").Append(E(w.SrcWell)).Append("</td>");
                h.Append("<td class='mono'>").Append(E(w.QWell)).Append("</td>");
                h.Append("<td class='mono'>").Append(E(w.OWell)).Append("</td>");
                h.Append("<td class='n'>").Append(ChannelOf(w.SrcWell)).Append("</td>");
                h.Append("<td class='n'>").Append(Show(w.A260_1)).Append("</td>");
                h.Append("<td class='n'>").Append(Show(w.A260_2)).Append("</td>");
                h.Append("<td class='n'>").Append(Show(w.Accepted)).Append("</td>");
                h.Append("<td class='n'>").Append(Show(w.A280)).Append("</td>");
                h.Append("<td class='n'>").Append(Show(w.A230)).Append("</td>");
                h.Append("<td class='n'>").Append(Show(w.R260_280)).Append("</td>");
                h.Append("<td class='n'>").Append(Show(w.R260_230)).Append("</td>");
                h.Append("<td class='n'>").Append(Show(w.CalcConc)).Append("</td>");
                h.Append("<td class='n'>").Append(Show(w.Xfer)).Append("</td>");
                h.Append("<td class='n'>").Append(Show(w.Dil)).Append("</td>");
                h.Append("<td class='mono'>").Append(E(w.Purity)).Append("</td>");
                h.Append("<td>").Append(w.Untouched
                    ? "<b>UNTOUCHED</b> &mdash; " + E(w.FlagWhy.Length > 0 ? w.FlagWhy : "no volume produced")
                    : (w.Clamped ? "transfer raised to the full output volume (NORM-003a)" : "")).Append("</td>");
                h.Append("</tr>");
            }
            h.Append("</table>\n");
        }

        // ---- the VI strings actually written ----
        if (rpViSample.Length > 0)
        {
            h.Append("<h3>VI strings written</h3>");
            h.Append("<div class='sub'>Row-major, placed by well label: channel = 12&times;row + col + 1, "
                + "so A01=1, A02=2, B01=13, H12=96. An EMPTY entry means that channel does nothing. A bare "
                + "volume is equivalent to <span class='mono'>&lt;vol&gt;;0;0</span> &mdash; the leading and "
                + "trailing air-gap sub-fields default to 0, so they are only written when non-zero.</div>");
            h.Append("<table><tr><th>Variable</th><th>Value actually written</th></tr>");
            foreach (string[] pair in new string[][] {
                new string[] { V_VI_SAMPLE_ASP, rpViSampleAsp }, new string[] { V_VI_SAMPLE_DISP, rpViSampleDisp },
                new string[] { V_VI_DILUENT_ASP, rpViDiluentAsp }, new string[] { V_VI_DILUENT_DISP, rpViDiluentDisp } })
                h.Append("<tr><td class='mono'>").Append(E(pair[0])).Append("</td><td class='mono'>")
                    .Append(E(pair[1])).Append("</td></tr>");
            h.Append("</table><div class='sub'>Aspirate VIs include the leading air gap. Dispense VIs include the over-dispense stroke. "
                + "Recorded liquid volumes exclude both. Plate lists are indexed by physical quantification slot.</div>");
        }

        // ---- notes ----
        if (notes.Count > 0)
        {
            h.Append("<h3>Notes</h3><ul>");
            for (int i = 0; i < notes.Count; i++) h.Append("<li>").Append(E(notes[i])).Append("</li>");
            h.Append("</ul>\n");
        }

        // ---- the reader payload, verbatim ----
        h.Append("<h3>Reader columns seen</h3><div class='mono sub'>")
         .Append(E(Join(ReadHeaders()))).Append("</div>\n");

        h.Append("</div>\n");
        return h.ToString();
    }

    private List<string> lastHeaders = new List<string>();
    private List<string> ReadHeaders() { return lastHeaders; }

    // =====================================================================================
    //  SMALL HELPERS
    // =====================================================================================

    // v0.20.1 — EVERY published list now leads with a comma (D-S20-05), so exactly ONE phantom comes
    // off the front. v0.20.0 deliberately did NOT strip, because per-row lists carried no leading
    // delimiter while per-plate lists did; that split convention is gone and this is now uniform.
    //
    // ⚠ ONLY the element at index 0, and only when it is empty. An empty element anywhere else is
    // MEANINGFUL — it is a row that has no value yet, which is the normal state of every result list
    // this script is about to fill. Dropping all empties would collapse a 168-row list to nothing.
    private static List<string> SplitStrict(string raw)
    {
        var outp = new List<string>();
        if (raw == null || raw.Length == 0) return outp;
        string[] parts = raw.Split(',');
        int start = (parts.Length > 0 && parts[0].Length == 0) ? 1 : 0;
        for (int i = start; i < parts.Length; i++) outp.Add(parts[i]);
        return outp;
    }

    private static string CheckLen(int n, string label, List<string> l)
    {
        if (l.Count == n) return "";
        return label + " has " + l.Count + " element(s) but the run has " + n + " row(s).";
    }

    // Carry the existing contents of an output list forward, so a per-plate call cannot wipe another
    // plate's results. Length mismatches are ignored deliberately: the row-count check upstream has
    // already run, and a short carried list simply leaves later slots empty.
    private static void CarryForward(IMMApp app, string name, string[] into, int n)
    {
        List<string> prior = SplitStrict(Get(app, name));
        for (int i = 0; i < n && i < prior.Count; i++) into[i] = prior[i];
        for (int i = 0; i < n; i++) if (into[i] == null) into[i] = "";
    }

    private static int Col(List<string> headers, string[] candidates)
    {
        for (int c = 0; c < candidates.Length; c++)
            for (int i = 0; i < headers.Count; i++)
                if (Key(headers[i]) == Key(candidates[c])) return i;
        return -1;
    }

    private static string Cell(string[] row, int i)
    { return (i >= 0 && i < row.Length) ? row[i].Trim() : ""; }

    private static bool TryNum(string s, out double v)
    { return Qn.TryNumber(s, out v); }

    private static double Round2(double v) { return Math.Round(v, 2, MidpointRounding.AwayFromZero); }

    // InvariantCulture on purpose. A machine set to a comma-decimal locale would otherwise write
    // "37,2" into a VI string, and the comma is the VI's own well separator — one well's volume
    // would become two entries and every channel after it would shift.
    private static string Num(double v)
    { return Qn.Number(v); }

    private static string Pct(double frac)
    { return (frac * 100.0).ToString("0.#", System.Globalization.CultureInfo.InvariantCulture) + "%"; }

    private static string Show(string s)
    { return (s == null || s.Trim().Length == 0) ? "<span class='empty'>&mdash;</span>" : E(s); }

    private string FirstFew(int k)
    {
        var sb = new StringBuilder();
        int shown = 0;
        for (int i = 0; i < rpWells.Count && shown < k; i++)
        {
            if (!rpWells[i].Flagged) continue;
            sb.Append("  • ").Append(rpWells[i].QWell).Append(": ").Append(rpWells[i].FlagWhy).Append("\n");
            shown++;
        }
        int total = rpWells.Count(x => x.Flagged);
        if (total > shown) sb.Append("  • and ").Append(total - shown).Append(" more.\n");
        return sb.ToString();
    }

    private static string Preview(List<string> l)
    {
        if (l.Count == 0) return "(empty)";
        int k = Math.Min(l.Count, 8);
        var sb = new StringBuilder();
        for (int i = 0; i < k; i++) { if (i > 0) sb.Append(", "); sb.Append(l[i]); }
        if (l.Count > k) sb.Append(", … (" + l.Count + " total)");
        return sb.ToString();
    }

    private static string Join(List<string> l)
    { return l.Count == 0 ? "(none)" : string.Join(", ", l.ToArray()); }

    // v0.20.1 — leading comma on write, matching SplitStrict on read (D-S20-05).
    private static string Join2(string[] a)
    {
        for (int i = 0; i < a.Length; i++) if (a[i] == null) a[i] = "";
        return "," + string.Join(",", a);
    }

    private static string Flatten(string s)
    {
        if (s == null) return "";
        string t = s.Replace("\r\n", " ").Replace("\n", " ").Replace("\r", " ");
        while (t.IndexOf("   ", StringComparison.Ordinal) >= 0) t = t.Replace("   ", "  ");
        return t.Trim();
    }

    private static string Now()
    { return DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"); }

    private static string E(string s)
    {
        if (s == null) return "";
        return s.Replace("&", "&amp;").Replace("<", "&lt;").Replace(">", "&gt;");
    }

    private static string Key(string s)
    { return (s ?? "").Trim().Replace("µ", "u").Replace("μ", "u").Replace(" ", "")
        .Replace("_", "").Replace("-", "").ToLowerInvariant(); }

    private static string Get(IMMApp app, string name)
    { try { string v = app.GetVariableValue(name); return v == null ? "" : v; } catch (Exception) { return ""; } }

    private static void Set(IMMApp app, string name, string value)
    { Qn.Write(app, name, value); }

    private void ResetInvocation()
    {
        problems.Clear(); notes.Clear(); rpWells.Clear(); lastHeaders.Clear();
        reportWritten = false; reportPath = ""; computeReached = false;
        rpPayloadIsFixture = false; rpPayloadSource = ""; rpPayloadVar = ""; rpPlateId = "";
        lowSignalWells.Clear();
        rpMatched = 0; rpRows = 0; rpRowsThisPlate = 0; rpPayloadRows = 0; rpPlateIx = 0;
        rpViSample = ""; rpViDiluent = ""; rpViSampleAsp = ""; rpViSampleDisp = "";
        rpViDiluentAsp = ""; rpViDiluentDisp = ""; rpSentinelOn = "";
        rpTargetDefaulted = false; rpExtCoefDefaulted = false;
    }
    private static double PositiveParameter(IMMApp app, string name, double fallback, bool allowDefault, out bool usedDefault)
    {
        string raw = Get(app, name).Trim(); double value;
        usedDefault = raw.Length == 0;
        if (usedDefault)
        {
            Qn.Require(allowDefault, "Required numeric parameter is missing: " + name);
            value = fallback; Set(app, name, Qn.Number(value));
        }
        else Qn.Require(Qn.TryNumber(raw, out value) && value > 0, "Invalid positive finite parameter: " + name + " = " + raw);
        return value;
    }
    private void ClearPlateCalculation(IMMApp app, int slot, int count)
    {
        Qn.PlateValue(app, "User.NormalizationPlateStatus_List_01", slot, count, "PENDING", ',');
        Qn.PlateValue(app, "User.NormalizationPlateRun_List_01", slot, count, "", ',');
        foreach (string name in new string[] { L_VI_SAMPLE_ASP, L_VI_SAMPLE_DISP, L_VI_DILUENT_ASP, L_VI_DILUENT_DISP })
            Qn.PlateValue(app, name, slot, count, "", '-');
        foreach (string name in new string[] { V_VI_SAMPLE_ASP, V_VI_SAMPLE_DISP, V_VI_DILUENT_ASP, V_VI_DILUENT_DISP }) Set(app, name, "");
    }
    private void WriteCalculationCheckpoint(IMMApp app)
    {
        string directory = app.WorkspaceOutputPath;
        Directory.CreateDirectory(directory);
        var text = new StringBuilder();
        text.AppendLine("RunID: " + rpRunId); text.AppendLine("PlateSlot: " + rpPlateIx);
        text.AppendLine("DataSource: " + rpPayloadSource); text.AppendLine("ReaderInput: " + rpPayloadVar);
        text.AppendLine("SourceWell;QuantWell;OutputWell;Concentration;SampleLiquid;DiluentLiquid;Purity;Disposition");
        foreach (WellResult well in rpWells)
            text.AppendLine(well.SrcWell + ";" + well.QWell + ";" + well.OWell + ";" + well.CalcConc + ";"
                + well.Xfer + ";" + well.Dil + ";" + well.Purity + ";" + (well.Untouched ? "SKIPPED" : well.Clamped ? "BELOW_TARGET" : "CALCULATED"));
        File.WriteAllText(Path.Combine(directory, "QuantNorm_calculation_" + rpRunId + "_plate" + rpPlateIx + ".txt"), text.ToString());
    }


    // Shared, self-contained helpers. Kept in each script: no extra runtime DLL is required.
    private static class Qn
    {
        public static string Get(IMMApp app, string name)
        { try { return app.GetVariableValue(name) ?? ""; } catch (Exception) { return ""; } }
        public static void Write(IMMApp app, string name, string value)
        {
            app.SetVariable(name, value ?? "");
            if (!string.Equals(app.GetVariableValue(name) ?? "", value ?? "", StringComparison.Ordinal))
                throw new InvalidOperationException("MM4 variable did not retain its assigned value: " + name);
        }
        public static void Require(bool condition, string message)
        { if (!condition) throw new InvalidOperationException(message); }
        public static bool Finite(double value)
        { return !double.IsNaN(value) && !double.IsInfinity(value); }
        public static bool TryNumber(string text, out double value)
        {
            return double.TryParse((text ?? "").Trim(), System.Globalization.NumberStyles.Float,
                System.Globalization.CultureInfo.InvariantCulture, out value) && Finite(value);
        }
        public static string Number(double value)
        { return value.ToString("0.################", System.Globalization.CultureInfo.InvariantCulture); }
        public static string Well(string text)
        {
            string s = (text ?? "").Trim().ToUpperInvariant();
            int c;
            if (s.Length < 2 || s.Length > 3 || s[0] < 'A' || s[0] > 'H') return "";
            for (int i = 1; i < s.Length; i++) if (s[i] < '0' || s[i] > '9') return "";
            if (!int.TryParse(s.Substring(1), out c) || c < 1 || c > 12) return "";
            return s.Substring(0, 1) + c.ToString("00");
        }
        public static int Channel(string well)
        {
            string w = Well(well);
            return w.Length == 0 ? -1 : (w[0] - 'A') * 12 + int.Parse(w.Substring(1));
        }
        public static List<string> List(string raw, char separator)
        {
            var result = new List<string>();
            if (string.IsNullOrEmpty(raw)) return result;
            string[] parts = raw.Split(separator);
            int start = parts[0].Length == 0 ? 1 : 0;
            for (int i = start; i < parts.Length; i++) result.Add(parts[i]);
            return result;
        }
        public static string At(List<string> values, int index)
        { return index >= 0 && index < values.Count ? values[index] : ""; }
        public static void PlateValue(IMMApp app, string variable, int index, int count, string value, char separator)
        {
            Require(index >= 1 && index <= count && count <= 4, "Invalid plate index for " + variable);
            var prior = List(Get(app, variable), separator);
            Require(prior.Count <= count, "Too many plate entries in " + variable + ". Start from ingestion.");
            while (prior.Count < count) prior.Add("");
            prior[index - 1] = value ?? "";
            Write(app, variable, separator.ToString() + string.Join(separator.ToString(), prior.ToArray()));
        }
        public static void SafeToken(string value, string description)
        {
            Require(!string.IsNullOrEmpty(value) && value.IndexOfAny(new char[] { ',', '|', '&', '\r', '\n', '\t' }) < 0,
                description + " is empty or contains a reserved MM4 list delimiter.");
        }
        public static string HashBytes(byte[] data)
        {
            using (var sha = System.Security.Cryptography.SHA256.Create())
                return BitConverter.ToString(sha.ComputeHash(data)).Replace("-", "").ToLowerInvariant();
        }
        public static string HashFile(string path) { return HashBytes(File.ReadAllBytes(path)); }
        public static void CheckWorklist(IMMApp app)
        {
            string p = Get(app, "User.WorklistFile_01"), h = Get(app, "User.SourceWorklistHash_01");
            Require(h.Length > 0 && File.Exists(p) && HashFile(p) == h,
                "The worklist is missing or changed after ingestion. Start a new run; current results must not be paired with changed input.");
        }
        public static List<string> ReadRecords(string path) { return Records(File.ReadAllText(path)); }
        public static List<string> Records(string text)
        {
            var result = new List<string>();
            var b = new StringBuilder();
            bool quoted = false;
            string s = (text ?? "").TrimStart('\uFEFF');
            for (int i = 0; i < s.Length; i++)
            {
                char c = s[i];
                if (c == '"')
                {
                    b.Append(c);
                    if (quoted && i + 1 < s.Length && s[i + 1] == '"') { b.Append(s[++i]); continue; }
                    // Comments and header preambles are plain text, not CSV records.
                    if (!b.ToString().TrimStart().StartsWith("#")) quoted = !quoted;
                }
                else if ((c == '\r' || c == '\n') && !quoted)
                {
                    result.Add(b.ToString()); b.Length = 0;
                    if (c == '\r' && i + 1 < s.Length && s[i + 1] == '\n') i++;
                }
                else b.Append(c);
            }
            Require(!quoted, "Unterminated quoted field in the input file.");
            if (b.Length > 0) result.Add(b.ToString());
            return result;
        }
        public static string[] Fields(string record, char separator)
        {
            var result = new List<string>(); var cell = new StringBuilder();
            bool quoted = false, closed = false;
            string s = record ?? "";
            // Preambles/comments are not CSV: callers retain them verbatim.
            if (s.TrimStart().StartsWith("#") || (s.IndexOf(separator) < 0 && s.IndexOf(':') > 0)) return new string[] { s };
            for (int i = 0; i < s.Length; i++)
            {
                char c = s[i];
                if (quoted)
                {
                    if (c == '"')
                    {
                        if (i + 1 < s.Length && s[i + 1] == '"') { cell.Append('"'); i++; }
                        else { quoted = false; closed = true; }
                    }
                    else cell.Append(c);
                }
                else if (c == separator) { result.Add(cell.ToString()); cell.Length = 0; closed = false; }
                else if (c == '"')
                {
                    Require(!closed && cell.ToString().Trim().Length == 0, "Unexpected quote in a delimited field.");
                    cell.Length = 0; quoted = true;
                }
                else if (closed) Require(char.IsWhiteSpace(c), "Unexpected text following a quoted field.");
                else cell.Append(c);
            }
            Require(!quoted, "Unterminated quoted field."); result.Add(cell.ToString());
            return result.ToArray();
        }
    }

}
